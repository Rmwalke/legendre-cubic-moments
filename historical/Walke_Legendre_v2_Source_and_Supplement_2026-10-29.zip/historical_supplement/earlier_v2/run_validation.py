"""Run the finite v2 correction suite without rerunning the full H13 dataset.

Usage: python -I run_validation.py [--jobs 3] [--out validation_run]
       python -I run_validation.py --skip-high-precision
All source paths are resolved relative to this file, not the current directory.
"""
from pathlib import Path
import argparse
import concurrent.futures
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import time


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jobs',type=int,default=3)
    parser.add_argument('--out',default='validation_run')
    parser.add_argument('--skip-high-precision',action='store_true')
    args=parser.parse_args()
    if args.jobs<1:
        parser.error('--jobs must be positive')
    root=Path(__file__).resolve().parent
    base=root/'code_and_data'
    log=(root/args.out).resolve()
    log.mkdir(parents=True,exist_ok=True)
    data=next(base.glob('05_*/H13_output_data_laptop*.txt'))
    h13=next(base.glob('05_*/H13_*.py'))
    specs=[
        ('V2_exact_livne','06_*/V2_01_*.py',[str(log/'exact_livne_certificate.json')],
         ['Exact finite comparisons: PASS','bounds 24 / 48']),
        ('V2_normalization','06_*/V2_02_*.py',[],['25 split primes <= 250',': PASS']),
        ('H20_exact_weil','03_*/H20_*.py',[str(data)],['INTEGRITY: PASS']),
        ('H17_descriptive','03_*/H17_*.py',[str(data),str(log)],['KS distance']),
        ('H27_legacy','02_*/H27_*.py',[str(h13)],['PASS']),
        ('H31_legacy','02_*/H31_*.py',[str(h13)],['PASS']),
        ('H33_conventions','02_*/H33_*.py',[],['p=5: True',': PASS']),
        ('H34_sturm','02_*/H34_*.py',[str(h13)],['PASS']),
        ('L1_inert','04_*/L1_*.py',['300'],['(32 primes): PASS']),
        ('L2_candidate','04_*/L2_*.py',[str(data)],['FE search: PASS']),
        ('L3_robustness','04_*/L3_*.py',[str(data)],['ROBUSTNESS: PASS']),
        ('L4_central','04_*/L4_*.py',[str(data)],['2.2413552032','Built-in symmetry']),
        ('V2_regressions','06_*/V2_03_*.py',[str(log/'H13_report_from_historical_data.txt')],
         ['Production Weil validators',': PASS']),
        ('V2_bcm','06_*/exact_bcm_p5.py',[],['a_5=-14; PASS']),
    ]
    if not args.skip_high_precision:
        specs.append(('V2_FE220','06_*/V2_04_*.py',[str(base),'220'],
                      ['3.76045072590436546687E-53','2.2413552032364396']))
    tasks=[(name,next(base.glob(pattern)),arguments,expected)
           for name,pattern,arguments,expected in specs]
    sources=list(base.rglob('*.py'))+[Path(__file__)]
    for path in sources:
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    print(f'{len(sources)} Python source files compile.',flush=True)
    env=os.environ.copy()
    env['MPLBACKEND']='Agg'
    env['PYTHONIOENCODING']='utf-8'
    env['OPENBLAS_NUM_THREADS']='1'

    def run(task):
        name,path,arguments,expected=task
        start=time.monotonic()
        command=[sys.executable,'-I',str(path),*arguments]
        result=subprocess.run(command,cwd=path.parent,env=env,
                              capture_output=True,text=True,encoding='utf-8')
        output=result.stdout+result.stderr
        (log/(name+'.txt')).write_text(output,encoding='utf-8')
        missing=[s for s in expected if s not in output]
        passed=result.returncode==0 and not missing and 'FAIL' not in output
        row=dict(name=name,exit=result.returncode,passed=passed,
                 seconds=round(time.monotonic()-start,2),
                 missing_expected_markers=missing,
                 command=command,cwd=str(path.parent),
                 source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        print(f'{name}: {"PASS" if passed else "FAIL"} ({row["seconds"]} s)',flush=True)
        return row

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        results=list(pool.map(run,tasks))
    manifest=dict(
        python=platform.python_version(),
        packages={name:importlib.metadata.version(name)
                  for name in ('numpy','scipy','matplotlib')},
        dataset_sha256=hashlib.sha256(data.read_bytes()).hexdigest(),
        scripts=[dict(path=str(p.relative_to(root)),
                      sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                 for p in sorted(sources)],
        results=results,
        scope='Finite correction tests. Historical FFT inputs are not fully certified; geometric and analytic hypotheses remain separate.',
    )
    (log/'v2_validation_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    failures=[r['name'] for r in results if not r['passed']]
    if failures:
        print('FAILED:',', '.join(failures))
        raise SystemExit(1)
    print(f'VALIDATION COMPLETE: {len(results)}/{len(results)} jobs passed. Logs: {log}')


if __name__=='__main__':
    main()
