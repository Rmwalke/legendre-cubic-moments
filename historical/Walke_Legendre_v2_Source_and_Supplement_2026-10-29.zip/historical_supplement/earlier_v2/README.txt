WALKE: PROPOSED V2 CORRECTION DRAFT
28 October 2026

This package contains a proposed revised manuscript and corrected computational
supplement. It has not been deposited, submitted to a journal, or peer reviewed.
The original author is Rushikesh Murlidhar Walke. The corrections and additional
verification scripts were prepared with ChatGPT assistance for author review.

START HERE

1. Read manuscript/Walke_Legendre_v2_correction_draft.pdf.
   The matching .tex file is editable and is the source used to build the PDF.
2. Read CHANGELOG.txt for the mathematical and code corrections.
3. Read PROOF_OBLIGATIONS.txt before treating any conditional statement as a
   theorem. These are specific missing mathematical arguments, not numerical
   tests that can be replaced by a larger prime bound.
4. Current correction-run logs are in validation_logs/. Original v1 output
   files under code_and_data/ remain historical records and are not overwritten.

WHAT IS FIXED

- A seven-vector quartic Livne test set now uses the same S (all primes over
  2 and 3) as the stated ramification bound. The exact finite trace and
  determinant comparisons pass for n=3,4,6.
- Section 4's normalized hypergeometric formula now includes its Jacobi-sum
  factor. A proof and the explicit p=7 example are in the manuscript.
- The old floor-square-root Weil false positive is removed. The production
  validator is tested on a synthetic counterexample and a boundary example.
- Square-class comparisons use gcd and integer square roots, without relying
  on incomplete factorization.
- FFT provenance, restricted splitting exclusions, statistical diagnostics,
  bad-prime assumptions, and functional-equation normalization are explicit.

RUN THE CORRECTION CHECKS

Tested environment: Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0,
Matplotlib 3.10.8. Version pins are in requirements.txt.

Optional dependency installation (requires network):
    python -m pip install -r requirements.txt

Run from any directory using the full path to the runner, or from this folder:
    python -I run_validation.py

The runner uses three subprocesses at a time, writes a NEW validation_run/
directory by default, and exits nonzero if a required computation fails. It
does not run the three-hour H13 laptop data-generation job, overwrite the
archived v1 inputs, or publish anything. Allow a few minutes on a laptop.
The high-precision calculation is the slowest default check.

Optional arguments:
    python -I run_validation.py --skip-high-precision
    python -I run_validation.py --jobs 1 --out my_checks

The default suite has 15 jobs. Passing it certifies the stated finite tests,
not all geometric hypotheses, all FFT inputs, analytic continuation, or BSD.
The full-table report is regenerated from the supplied historical values;
this is not an independent exact regeneration of the F_(p^2) table.

MANUSCRIPT BUILD

In a working TeX Live/MiKTeX installation with amsart and the listed packages:
    cd manuscript
    pdflatex -interaction=nonstopmode -halt-on-error Walke_Legendre_v2_correction_draft.tex
    pdflatex -interaction=nonstopmode -halt-on-error Walke_Legendre_v2_correction_draft.tex

The supplied PDF is already built. No external figure files are required.

FILE MAP

manuscript/                    Proposed revised preprint, PDF and LaTeX
code_and_data/                 Original experiment layout, with 11 scripts corrected
code_and_data/06_v2_certificates/
  exact_arithmetic.py          Integer direct character sums and reference helpers
  exact_bcm_p5.py              Exact rational arithmetic in Q(zeta_20)
  V2_01_exact_livne.py          Exact finite comparisons and Sturm coefficients
  V2_02_..._FLOAT.py           Numerical check of the proved normalization formula
  V2_03_regressions.py         Production validator and report regressions
  V2_04_high_precision_FE.py   Independent Decimal Bessel kernel, conditional data
validation_logs/              Logs of the final correction suite
prior_audit_logs/             Selected earlier audit runs, explicitly labelled
code_changes.patch            Changes to pre-existing code/README versus v1
changed_code_files.json        List of the 11 changed pre-existing Python scripts
environment_and_inputs.json   Environment and original-input hashes
SHA256SUMS.txt                 Hashes of package files other than itself

READING THE EVIDENCE

The exact point-count certificates, exact BCM value, and algebraic
normalization proof are stronger evidence than rounded FFT experiments.
The conductor 1296, bad Euler factors at 2 and 3, general descent,
irreducibility, Sato-Tate group, and paramodular realization remain
conjectural/conditional in the precise senses stated in the manuscript.
The central-value digits are observations under the candidate completion;
they are not an interval-certified theorem.

The uploaded v1 PDF was the source for this revision; no original author .tex
was supplied. This is a reconstructed correction draft, not a byte-level
edit of the author's original LaTeX source. The v1 ZIP and PDF are unchanged.
No license or publication status is changed by this package.
