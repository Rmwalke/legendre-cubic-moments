"""Independent integer checks for Walke, preprint v1 (28 October 2026).

Run: python independent_audit.py /path/to/code_and_data
Requires numpy. Does not change the supplied code or data. No network calls.
Finite-field point counts below use direct character sums, not FFT rounding.
The whole p <= 4999 table is checked for a necessary Weil condition; it is
not independently reconstructed. This distinction is intentional.
"""
from pathlib import Path
import importlib.util
import json
import math
import sys
import numpy as np


def chi_table(p):
    out = np.full(p, -1, dtype=np.int64)
    out[0] = 0
    out[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1
    return out


def discrete_logs(p):
    for g in range(2, p):
        seen, a = [], 1
        for e in range(p - 1):
            seen.append(a)
            a = a * g % p
        if len(set(seen)) == p - 1:
            out = np.zeros(p, dtype=np.int64)
            for e, a in enumerate(seen):
                out[a] = e
            return out
    raise ValueError(p)


def direct_moments(p, degree, orders):
    """All Legendre traces over F_p or F_p[sqrt(d)] by exact O(q^2) sums.

    For degree 2 the order-n character is the norm lift of a character on
    F_p, so this function requires n | p-1. Conjugate class sums are equal.
    """
    chi = chi_table(p)
    logs = discrete_logs(p)
    if degree == 1:
        aa = np.arange(p, dtype=np.int64)
        bb = np.zeros(p, dtype=np.int64)
        nr = 0
    else:
        nr = next(i for i in range(2, p) if chi[i] == -1)
        aa = np.repeat(np.arange(p, dtype=np.int64), p)
        bb = np.tile(np.arange(p, dtype=np.int64), p)
    q = p ** degree
    norm = (aa * aa - nr * bb * bb) % p
    if degree == 1:
        cq = chi[aa]
        cc1 = chi[(aa - 1) % p]
    else:
        cq = chi[norm]
        cc1 = chi[((aa - 1) ** 2 - nr * bb * bb) % p]
    base = cq * cc1
    traces = []
    indices = []
    for j, (c, d) in enumerate(zip(aa, bb)):
        if int(d) == 0 and int(c) in (0, 1):
            continue
        if degree == 1:
            shift = chi[(aa - c) % p]
        else:
            shift = chi[((aa - c) ** 2 - nr * (bb - d) ** 2) % p]
        tr = -int(np.dot(base, shift))
        assert tr * tr <= 4 * q
        assert (q + 1 - tr) % 4 == 0  # full rational 2-torsion
        traces.append(tr)
        indices.append(j)
    class_source = logs[aa if degree == 1 else norm]
    ans = {}
    for n in orders:
        assert (p - 1) % n == 0
        for k in (2, 4):
            sums = [0] * n
            for j, tr in zip(indices, traces):
                sums[int(class_source[j]) % n] += tr ** k
            assert all(sums[j] == sums[-j] for j in range(1, n))
            if n == 3:
                val = sums[0] - sums[1]
            elif n == 4:
                val = sums[0] - sums[2]
            elif n == 6:
                val = sums[0] + sums[1] - sums[2] - sums[3]
            else:
                raise ValueError(n)
            ans[(n, k)] = val
    return ans


def exact_weil(p, c1, c2):
    """Exact criterion for the reciprocal quartic with multiplier +p^5.

    y = x + p^5/x gives y^2-c1*y+c2-2*p^5. All four x-roots
    have modulus p^(5/2) iff D >= 0 and |c1|+sqrt(D) <= 4*sqrt(p^5).
    The last inequality is squared with both signs checked, using integers.
    """
    P = p ** 5
    D = c1 * c1 - 4 * (c2 - 2 * P)
    if D < 0:
        return False
    A = 16 * P - c1 * c1 - D
    return A >= 0 and A * A >= 4 * c1 * c1 * D


def old_weil(p, c1, c2):
    D = c1 * c1 - 4 * (c2 - 2 * p ** 5)
    if D < 0:
        return False
    sq = math.isqrt(D)
    return all((z / 2) ** 2 <= 4 * p ** 5 * (1 + 1e-9)
               for z in (c1 + sq, c1 - sq))


def fp2_pow(z, e, p, d):
    def mul(u, v):
        return ((u[0]*v[0]+d*u[1]*v[1]) % p,
                (u[0]*v[1]+u[1]*v[0]) % p)
    a = (1, 0)
    while e:
        if e & 1:
            a = mul(a, z)
        z = mul(z, z)
        e >>= 1
    return a


def direct_inert(p):
    """Exact trace for the conjectural descent formula, not its proof."""
    chi = chi_table(p)
    d = next(i for i in range(2, p) if chi[i] == -1)
    X = np.arange(p, dtype=np.int64)
    tr, classes = [], []
    for x in range(p):
        a = -int(np.dot(chi[X], chi[((X-x)**2-d) % p]))
        assert a*a <= 4*p
        tr.append(a)
        classes.append(fp2_pow((x, 1), (p*p-1)//3, p, d))
    vals = {k: {} for k in (2, 4)}
    for a, cl in zip(tr, classes):
        for k, v in ((2, a*a-p), (4, a**4-3*p*a*a+p*p)):
            vals[k][cl] = vals[k].get(cl, 0) + v
    out = {}
    for k, sums in vals.items():
        nontriv = [sums[c] for c in sums if c != (1, 0)]
        assert len(nontriv) == 2 and nontriv[0] == nontriv[1]
        M = sums.get((1, 0), 0) - nontriv[0]
        out[k] = M + 1  # W=W' tensor chi_-3; inert sign is reversed
    return out


def main(root):
    data_path = root / '05_runner_laptop_p_upto_4999/H13_output_data_laptop_p_upto_4999.txt'
    rows = [l.split() for l in data_path.read_text().splitlines()
            if l.strip() and not l.startswith('#')]
    data = {int(r[0]): r for r in rows}
    failures = []
    for p, r in data.items():
        if r[1] == 'split' and not exact_weil(p, int(r[2]), int(r[3])):
            failures.append(p)
    assert not failures, failures
    print('Exact reciprocal-quartic Weil check: all 330 split rows PASS', flush=True)
    assert old_weil(5, 0, -6251) and not exact_weil(5, 0, -6251)
    print('H20 regression: p=5, c1=0, c2=-6251 passes old check, fails exact check.', flush=True)
    EXPECT = {
        3: {7: 8, 13: -10, 19: -100, 37: -226, 73: 26},
        4: {5: -2, 17: 50},
        6: {7: -24, 13: -74, 19: 92, 37: 30, 73: -998},
    }
    records = []
    for p in (5, 7, 13, 17, 19, 37, 73):
        orders = [n for n in EXPECT if p in EXPECT[n]]
        m1 = direct_moments(p, 1, orders)
        m2 = direct_moments(p, 2, orders)
        for n in orders:
            t1 = -m1[n, 2] - 1 - p
            t2 = -m2[n, 2] - 1 - p*p
            assert (t1*t1-t2) % 2 == 0
            det = (t1*t1-t2)//2
            assert t1 == EXPECT[n][p] and det == p**3
            records.append({'n': n, 'p': p, 'M2_Fp': m1[n, 2],
                            'M2_Fp2': m2[n, 2], 'trace': t1, 'det': det})
        if 3 in orders:
            v1 = -m1[3, 4]-1-3*p*(-m1[3, 2]-1-p)-3*p-2*p*p
            q = p*p
            v2 = -m2[3, 4]-1-3*q*(-m2[3, 2]-1-q)-3*q-2*q*q
            assert (v1*v1-v2) % 2 == 0
            s2 = (v1*v1-v2)//2
            assert (v1, s2) == (int(data[p][2]), int(data[p][3]))
        print(f'Exact direct Fp/Fp2 counts p={p}, orders={orders}: PASS', flush=True)
    # Load the author's inert routine for comparison, without executing its driver.
    src = (root/'04_descent_and_L_function/L1_check_descent_inert_traces_k2_FLOAT_2026-10-28.py').read_text().split('N = PMAX + 2')[0]
    ns = {}
    saved = sys.argv
    try:
        sys.argv = ['audit', '10']
        exec(compile(src, '<author-L1-definitions>', 'exec'), ns)
    finally:
        sys.argv = saved
    inert = []
    for p in (5, 11, 17, 101, 503, 2003, 4973):
        if p not in data or data[p][1] != 'inert':
            continue
        own = direct_inert(p)
        ap, cls = ns['twisted_data'](p)
        theirs = int(ns['re_sum'](ap**4-3*p*ap**2+p*p, cls)) + 1
        assert own[4] == theirs
        u = int(data[p][2])
        assert (own[4]**2-u) % 2 == 0
        c2 = (own[4]**2-u)//2
        assert exact_weil(p, own[4], c2)
        inert.append({'p': p, 'c1': own[4], 'c2': c2, 'k2': own[2]})
        print(f'Exact direct inert descent formula p={p}: c1={own[4]}, PASS', flush=True)
    print(json.dumps({'livne_exact': records, 'inert_spot_checks': inert}, indent=2))


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
