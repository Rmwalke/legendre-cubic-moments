#!/bin/bash
cd "$(dirname "$0")"
echo "H13 runner (offline). 3 tas chalel; parat chalavlyas jithe thambla tithun suru hoil."
if command -v python3 >/dev/null 2>&1; then python3 H13_run_one_click_V_data_LAPTOP_FLOAT_2026-10-27.py "$@"; else python H13_run_one_click_V_data_LAPTOP_FLOAT_2026-10-27.py "$@"; fi
read -p "Purna. Enter daba..."
