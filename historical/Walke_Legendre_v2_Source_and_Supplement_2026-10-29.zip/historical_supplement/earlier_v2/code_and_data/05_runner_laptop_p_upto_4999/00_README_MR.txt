H13 one-click runner — वापर (दादा साठी)
========================================
1. ही संपूर्ण folder laptop वर कुठेही unzip करा.
2. Python 3.8+ आणि numpy लागतात. numpy नसेल तर एकदाच:  python -m pip install numpy
   (runner स्वतः network वापरत नाही, काहीही upload करत नाही. फक्त याच folder मध्ये फाइल्स लिहितो.)
3. चालवा:
   - Windows : RUN_WINDOWS_double_click.bat वर double-click
   - Mac     : RUN_MAC_LINUX_double_click.command वर double-click
               (पहिल्यांदा: right-click > Open; किंवा Terminal मध्ये  bash RUN_MAC_LINUX_double_click.command)
   - Linux   : bash RUN_MAC_LINUX_double_click.command
4. 3 तासांनी तो स्वतः थांबतो. पुढचा prime वेळेत बसणार नसेल तर त्याआधीच थांबतो.
   पुन्हा double-click केलं की जिथे थांबला तिथून पुढे सुरू होतो.
   Ctrl+C, window बंद करणं किंवा वीज गेली तरी पूर्ण झालेले primes सुरक्षित राहतात (H13_checkpoint.jsonl).
   वेळ बदलायची असेल तर Terminal मध्ये:  python H13_run_one_click_V_data_LAPTOP_FLOAT_2026-10-27.py --hours 1.5
5. मला पाठवायच्या फाइल्स: H13_output_summary.txt, H13_output_data.txt (आणि हवं तर H13_log.txt).
   ही पाठवणी तुम्ही स्वतः हाताने करायची; runner काहीही पाठवत नाही.

अंदाज: p ≤ 5000 (कमाल मर्यादा) पर्यंत सुमारे 670 primes. माझ्या cloud machine वर ~45 मिनिटं लागली;
laptop वर बहुधा 1–3 तास. p = 5000 जवळ RAM सुमारे 2 GB लागते. Laptop मध्ये 4 GB पेक्षा कमी RAM असेल तर
script मधली ओळ PMAX_HARD = 5000 बदलून 3000 करा.
PASS/FAIL निकष H11 §5 मध्ये गणनेआधीच ठरवलेले आहेत. summary फाइल ते आपोआप तपासते.
