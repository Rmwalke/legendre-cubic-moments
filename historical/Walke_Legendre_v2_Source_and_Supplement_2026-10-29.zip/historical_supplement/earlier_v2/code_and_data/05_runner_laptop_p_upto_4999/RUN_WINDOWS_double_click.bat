@echo off
cd /d "%~dp0"
echo H13 runner (offline). 3 tas chalel, nantar parat chalavlyas jithe thambla tithun suru hoil.
where py >nul 2>nul && (py -3 H13_run_one_click_V_data_LAPTOP_FLOAT_2026-10-27.py %*) || (python H13_run_one_click_V_data_LAPTOP_FLOAT_2026-10-27.py %*)
pause
