# -*- coding: utf-8 -*-
"""
H13 — One-click, resumable laptop runner (FLOAT) for the 4-dim piece V
(cubic-twisted 4th moment of the Legendre family; see H11 notes §3, §5).

* Runs fully OFFLINE. No network access, no upload. It only reads/writes files in its own folder.
* Time budget: 3 hours by default (change TIME_BUDGET_HOURS below or pass --hours 1.5).
* Resumable: every finished prime goes immediately into H13_checkpoint.jsonl. Re-running continues
  from where it stopped (also after Ctrl+C, closing the window or a power cut).
* Output (rewritten every few primes and at the end):
    H13_output_data.txt     - table of all primes done
    H13_output_summary.txt  - PASS/FAIL criteria (fixed in H11 §5 BEFORE running) + statistics
Requirements: Python 3.8+ and numpy (no other package).

Definitions:
  a_q(l)  = trace of Frobenius of y^2 = x(x-1)(x-l) over F_q, q = p or p^2
  M2, M4  = sum_{l != 0,1} rho(l) a_q(l)^{2,4}  (rho cubic character of F_q; real part = S0 - S1)
  t2(q)   = -M2 - 1 - q ;   TrV(q) = -M4 - 1 - 3q t2(q) - 3q - 2q^2
  split p (p ≡ 1 mod 3):  s1 = TrV(p), s2 = (s1^2 - TrV(p^2))/2 ;  char poly x^4 - s1 x^3 + s2 x^2 - p^5 s1 x + p^10
  inert p (p ≡ 2 mod 3):  u  = TrV(p^2)  (exploratory)
FLOAT: a_q(l) via FFT correlation, rounded to integers; asserted |a| <= 2 sqrt(q) and a == q+1 (mod 4);
       exact cross-check against direct exact values (H9) at p <= 67; moments summed exactly (Python ints).
"""
import sys, os, json, time, math

TIME_BUDGET_HOURS = 3.0
PMAX_HARD = 5000           # never go beyond this prime (peak RAM ~ 2 GB at p = 5000; lower it on small laptops)

HERE = os.path.dirname(os.path.abspath(__file__))
CK = os.path.join(HERE, 'H13_checkpoint.jsonl')
OUT_DATA = os.path.join(HERE, 'H13_output_data.txt')
OUT_SUM = os.path.join(HERE, 'H13_output_summary.txt')
LOG = os.path.join(HERE, 'H13_log.txt')

def log(msg):
    line = time.strftime('%Y-%m-%d %H:%M:%S ') + msg
    print(line, flush=True)
    with open(LOG, 'a', encoding='utf-8') as f: f.write(line + '\n')

try:
    import numpy as np
except ImportError:
    print('\n*** numpy सापडला नाही. एकदाच install करा:  python -m pip install numpy  (हे एकदाच network लागतं;'
          ' runner स्वतः network वापरत नाही) ***\n')
    input('Enter दाबा...'); sys.exit(1)

# ---------------- arithmetic ----------------
def is_prime(n):
    if n < 2: return False
    if n % 2 == 0: return n == 2
    r = math.isqrt(n)
    return all(n % d for d in range(3, r + 1, 2))

def prim_root(p):
    m, fac, d = p - 1, [], 2
    while d * d <= m:
        if m % d == 0:
            fac.append(d)
            while m % d == 0: m //= d
        d += 1
    if m > 1: fac.append(m)
    return next(g for g in range(2, p) if all(pow(g, (p - 1) // f, p) != 1 for f in fac))

def chi_table(p):
    c = np.full(p, -1, dtype=np.int64); c[0] = 0
    c[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1
    return c

def cubic_class_Fp(p):
    g = prim_root(p); ind = np.zeros(p, dtype=np.int64); v = 1
    for e in range(p - 1): ind[v] = e; v = v * g % p
    return ind % 3

def fp2_pow(A, B, e, p, nr):
    RA = np.ones_like(A); RB = np.zeros_like(B); XA, XB = A.copy(), B.copy()
    while e:
        if e & 1: RA, RB = (RA * XA + nr * RB * XB) % p, (RA * XB + RB * XA) % p
        XA, XB = (XA * XA + nr * XB * XB) % p, (2 * XA * XB) % p
        e >>= 1
    return RA, RB

def exact_power_sums(a, cls, off):
    """exact S2[j], S4[j] via value counts (a has <= 2*off+1 distinct values)."""
    S2, S4 = [], []
    vals = np.arange(-off, off + 1)
    for j in range(3):
        cnt = np.bincount(a[cls == j] + off, minlength=2 * off + 1)
        nz = np.nonzero(cnt)[0]
        S2.append(sum(int(cnt[i]) * int(vals[i]) ** 2 for i in nz))
        S4.append(sum(int(cnt[i]) * int(vals[i]) ** 4 for i in nz))
    return S2, S4

def moments(p, n):
    chi = chi_table(p)
    if n == 1:
        X = np.arange(p); cq = chi[X]; f = cq * chi[(X - 1) % p]
        a = -np.rint(np.fft.ifft(np.fft.fft(f) * np.conj(np.fft.fft(cq))).real).astype(np.int64)
        cls = cubic_class_Fp(p); excl = [0, 1]; q = p
    else:
        nr = next(x for x in range(2, p) if chi[x] == -1)
        A, B = np.meshgrid(np.arange(p, dtype=np.int64), np.arange(p, dtype=np.int64), indexing='ij')
        N = (A * A - nr * B * B) % p; N1 = ((A - 1) ** 2 - nr * B * B) % p
        cq = chi[N].astype(np.float64); f = cq * chi[N1]
        F = np.fft.fft2(f); F *= np.conj(np.fft.fft2(cq))
        a = -np.rint(np.fft.ifft2(F).real).astype(np.int64).ravel(); del F, f, cq
        q = p * p
        if p % 3 == 1:
            cls = cubic_class_Fp(p)[N.ravel()]
        else:
            RA, RB = fp2_pow(A.ravel(), B.ravel(), (q - 1) // 3, p, nr)
            keys = RA * p + RB; del RA, RB
            uniq = np.unique(keys[1:]); one = p
            assert one in uniq and len(uniq) == 3
            others = [k for k in uniq if k != one]
            cls = np.zeros(q, dtype=np.int64); cls[keys == others[0]] = 1; cls[keys == others[1]] = 2
        excl = [0, p]                                 # l = 0 and l = 1 (index a*p + b)
    mask = np.ones(q, bool); mask[excl] = False
    am = a[mask]; cm = cls[mask]
    bound = 2 * math.isqrt(q) + 2
    assert np.all(np.abs(am) <= 2 * math.sqrt(q) + 1e-9) and np.all((am - (q + 1)) % 4 == 0), 'FFT consistency check failed'
    S2, S4 = exact_power_sums(am, cm, bound)
    assert S2[1] == S2[2] and S4[1] == S4[2], 'class symmetry failed'
    return S2[0] - S2[1], S4[0] - S4[1]

def TV(q, m2, m4): return -m4 - 1 - 3 * q * (-m2 - 1 - q) - 3 * q - 2 * q * q

SMALLP = [d for d in range(2, 10000) if all(d % e for e in range(2, math.isqrt(d) + 1))]
def partial_square_reduction(n):
    """n with squares of primes < 10^4 removed (legacy display column, not a certified squarefree part)."""
    s = 1 if n > 0 else -1; n = abs(n)
    for d in SMALLP:
        dd = d * d
        if dd > n: break
        while n % dd == 0: n //= dd
    return s * n

EXACT = {7: (-32, -12786), 13: (28, 113790), 19: (-2504, 4136790), 31: (-272, 13560126),
         37: (2284, 46569486), 43: (4168, -58885050), 61: (-16484, 617583198), 67: (1144, 1689885750)}

def do_prime(p):
    if p % 3 == 1:
        m2, m4 = moments(p, 1); m2b, m4b = moments(p, 2)
        s1 = TV(p, m2, m4); num = s1 * s1 - TV(p * p, m2b, m4b)
        assert num % 2 == 0
        s2 = num // 2
        if p in EXACT: assert (s1, s2) == EXACT[p], 'mismatch vs exact H9 value'
        D = s1 * s1 - 4 * (s2 - 2 * p ** 5)
        Dsq = D >= 0 and math.isqrt(D) ** 2 == D
        return {'p': p, 'type': 'split', 's1': s1, 's2': s2, 't2': -m2 - 1 - p, 'D': D, 'Dsq': Dsq}
    m2b, m4b = moments(p, 2)
    return {'p': p, 'type': 'inert', 'u': TV(p * p, m2b, m4b), 't2_p2': -m2b - 1 - p * p}

# ---------------- reference USp(4) moments (Weyl integration, deterministic) ----------------
def usp4_reference(K=6, n=600):
    th = (np.arange(n) + 0.5) * math.pi / n
    c1, c2 = np.meshgrid(np.cos(th), np.cos(th), indexing='ij')
    s1_, s2_ = np.meshgrid(np.sin(th), np.sin(th), indexing='ij')
    w = (c1 - c2) ** 2 * s1_ ** 2 * s2_ ** 2; w /= w.sum()
    a1 = 2 * c1 + 2 * c2; a2 = 2 + 4 * c1 * c2
    return ({k: float((w * a1 ** k).sum()) for k in range(1, 13)},
            {k: float((w * a2 ** k).sum()) for k in range(1, K + 1)},
            float((w * (a1 ** 2 - 2 * a2)).sum()))

def same_square_class(a, b):
    """Exact rational square-class comparison, without factorization."""
    if a == 0 or b == 0:
        return a == b
    if (a > 0) != (b > 0):
        return False
    a, b = abs(a), abs(b)
    g = math.gcd(a, b)
    a //= g; b //= g
    return math.isqrt(a)**2 == a and math.isqrt(b)**2 == b

def square_class_representatives(values):
    out = []
    for v in values:
        if v != 0 and not any(same_square_class(v, a) for a in out):
            out.append(v)
    return out

# ---------------- reporting ----------------
def write_reports(done, status):
    rows = [done[p] for p in sorted(done)]
    with open(OUT_DATA, 'w', encoding='utf-8') as f:
        f.write('# H13 data. split: p s1 s2 t2 D_is_square partial_square_reduction(D) ; inert: p u=TrV(Frob_p^2) t2(p^2)\n')
        for r in rows:
            if r['type'] == 'split':
                f.write(f"{r['p']} split {r['s1']} {r['s2']} {r['t2']} {int(r['Dsq'])} {partial_square_reduction(r['D'])}\n")
            else:
                f.write(f"{r['p']} inert {r['u']} {r['t2_p2']}\n")
    sp = [r for r in rows if r['type'] == 'split']; ine = [r for r in rows if r['type'] == 'inert']
    ref1, ref2, refu = usp4_reference()
    L = [f'H13 summary — status: {status} — {time.strftime("%Y-%m-%d %H:%M")}',
         f'primes done: {len(rows)} (split {len(sp)}, inert {len(ine)}); largest p = {rows[-1]["p"] if rows else "-"}', '']
    if sp:
        x1 = np.array([r['s1'] / r['p'] ** 2.5 for r in sp]); x2 = np.array([r['s2'] / r['p'] ** 5 for r in sp])
        sq = [r['p'] for r in sp if r['Dsq']]
        reps = square_class_representatives([r['D'] for r in sp if not r['Dsq']])
        L.append('Specified splitting models: both 2-dimensional determinants are +p^5')
        L.append(f'   D square at primes: {sq}  ({len(sq)} of {len(sp)})')
        L.append(f'   exact distinct nonzero nonsquare rational square classes: {len(reps)}')
        L.append(f'   rational 2+2 trace model excluded by input data: {len(sq) < len(sp)}')
        L.append(f'   fixed quadratic conjugate-pair model excluded by input data: {len(reps) > 1}')
        L.append('   These tests do not prove general irreducibility; inputs remain FFT-derived.')
        L.append('')
        L.append('Heuristic diagnostic: moments within 3 nominal iid USp(4) standard errors')
        ok2 = True
        for k in (2, 4, 6):
            m = float(np.mean(x1 ** k)); se = math.sqrt(max(ref1[2 * k] - ref1[k] ** 2, 0) / len(x1))
            good = abs(m - ref1[k]) <= 3 * se; ok2 &= good
            L.append(f'   E[x1^{k}] = {m:.4f} ± {se:.4f}   USp(4) = {ref1[k]:.4f}   {"ok" if good else "OFF"}')
        for k in (1, 2, 3):
            m = float(np.mean(x2 ** k)); se = math.sqrt(max(ref2[2 * k] - ref2[k] ** 2, 0) / len(x2))
            good = abs(m - ref2[k]) <= 3 * se; ok2 &= good
            L.append(f'   E[x2^{k}] = {m:.4f} ± {se:.4f}   USp(4) = {ref2[k]:.4f}   {"ok" if good else "OFF"}')
        L.append('   (nominal iid errors; no iid-prime model or Sato-Tate proof is asserted)')
        L.append(f'   heuristic moment bands: {"within" if ok2 else "outside"}; sample size {len(x1)}')
        L.append('')
    if ine:
        u = np.array([r['u'] / r['p'] ** 5 for r in ine])
        L.append('Exploratory (no PASS/FAIL): inert primes, y = u/p^5 = Tr V(Frob_{p^2})/p^5')
        L.append(f'   mean y = {np.mean(u):.4f} ± {np.std(u) / math.sqrt(len(u)):.4f}   (random USp(4) value of Tr(g^2): {refu:.4f};'
                 ' a different mean would hint at the component structure of the descent W)')
        L.append(f'   E[y^2] = {np.mean(u ** 2):.4f}')
    with open(OUT_SUM, 'w', encoding='utf-8') as f: f.write('\n'.join(L) + '\n')

def main():
    hours = TIME_BUDGET_HOURS
    if '--hours' in sys.argv: hours = float(sys.argv[sys.argv.index('--hours') + 1])
    deadline = time.time() + hours * 3600
    done = {}
    if os.path.exists(CK):
        with open(CK, encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    try: r = json.loads(line); done[r['p']] = r
                    except json.JSONDecodeError: pass      # half-written last line after a crash
    log(f'START  budget {hours} h ; already done {len(done)} primes ; offline run, no network')
    last_p, last_sec = None, None
    status = 'stopped by time budget'
    try:
        with open(CK, 'a', encoding='utf-8') as ck:
            for p in range(5, PMAX_HARD + 1):
                if not is_prime(p) or p in done: continue
                if last_sec is not None:   # predict time for p from the last prime (~ p^2 log p)
                    est = last_sec * (p / last_p) ** 2 * 1.1 * (2 if (p % 3 == 1) != (last_p % 3 == 1) else 1)
                    if time.time() + est > deadline:
                        log(f'next prime {p} would need ~{est/60:.1f} min, beyond budget -> stop'); break
                if time.time() > deadline: log('time budget reached -> stop'); break
                t0 = time.time()
                r = do_prime(p); r['sec'] = round(time.time() - t0, 2)
                ck.write(json.dumps(r) + '\n'); ck.flush(); os.fsync(ck.fileno())
                done[p] = r; last_p, last_sec = p, r['sec']
                if len(done) % 10 == 0 or p < 100:
                    log(f'p={p} ({r["type"]}) {r["sec"]} s ; total {len(done)} primes')
                    write_reports(done, 'running')
            else:
                status = f'finished all primes <= {PMAX_HARD}'
    except KeyboardInterrupt:
        status = 'interrupted (Ctrl+C) — re-run to resume'
        log('Ctrl+C -> saved, can resume')
    write_reports(done, status)
    log(f'END  {status} ; total primes {len(done)} ; see H13_output_summary.txt and H13_output_data.txt')

if __name__ == '__main__':
    main()
    if sys.stdin and sys.stdin.isatty() and os.name == 'nt':
        input('\nपूर्ण. Enter दाबा...')
