"""Stage 1 — test of hypothesis H (R1 §3.4):
    D(p) := sum_{l=1}^{p-1} chi(l) * L(l)^2,   L(l) = sum_w chi(w(w-1)(w-l))   (= twisted 2nd moment)
    H:  D(p) = -a(p) - p,   where  sum a(n) q^n = eta(2z)^4 eta(4z)^4 = q prod (1-q^{2n})^4 (1-q^{4n})^4.

PASS/FAIL (fixed before running, R1 §4): PASS = exact integer equality at every prime p ≡ 1 (mod 4),
5 <= p <= PMAX. FAIL = any mismatch. Primes p ≡ 3 (mod 4) are reported separately (no prior claim).
Also self-checks a(n) via Hecke relations a(25) = a(5)^2 - 5^3 and a(27) = a(3)a(9) - 27 a(3).
Usage: python E3_check_H_D_equals_minus_a_minus_p.py [PMAX]
"""
import sys
from math import isqrt
import numpy as np

PMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 2000

def primes_upto(n):
    s = bytearray([1]) * (n + 1); s[0:2] = b'\x00\x00'
    for i in range(2, isqrt(n) + 1):
        if s[i]: s[i*i::i] = bytearray(len(s[i*i::i]))
    return [i for i in range(n + 1) if s[i]]

def eta_product_coeffs(nmax):
    """Exact a(n), n <= nmax, of q * prod (1-q^{2n})^4 (1-q^{4n})^4 (integer arithmetic)."""
    K = nmax // 2 + 1
    A = [0] * (K + 1); A[0] = 1               # prod (1 - t^n)^4 truncated at t^K
    for n in range(1, K + 1):
        for _ in range(4):
            for i in range(K, n - 1, -1):
                A[i] -= A[i - n]
    Bv = [0] * (K + 1)
    for i in range(0, K // 2 + 1): Bv[2 * i] = A[i]   # prod (1 - t^{2n})^4
    C = [sum(A[j] * Bv[k - j] for j in range(k + 1)) for k in range(K + 1)]
    a = [0] * (nmax + 1)
    for k in range(K + 1):
        if 2 * k + 1 <= nmax: a[2 * k + 1] = C[k]
    return a

def chi_table(p):
    c = np.full(p, -1, dtype=np.int64); c[0] = 0
    c[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1
    return c

def D_twisted(p):
    c = chi_table(p); x = np.arange(p, dtype=np.int64); base = (x * (x - 1)) % p
    return sum(int(c[l]) * int(c[(base * ((x - l) % p)) % p].sum()) ** 2 for l in range(1, p))

if __name__ == '__main__':
    a = eta_product_coeffs(PMAX)
    print('eta-product a(n), n<=29:', {n: a[n] for n in range(1, 30, 2)})
    print('Hecke self-check a(25)=a(5)^2-125:', a[25] == a[5] ** 2 - 125,
          '| a(27)=a(3)a(9)-27a(3):', a[27] == a[3] * a[9] - 27 * a[3])
    fail1, rows3 = [], []
    for p in primes_upto(PMAX):
        if p < 5: continue
        D = D_twisted(p); pred = -a[p] - p
        if p % 4 == 1:
            if D != pred: fail1.append((p, D, pred))
            if p <= 101 or p > PMAX - 60: print(f'p={p:5d} (1 mod 4)  D={D:9d}  -a(p)-p={pred:9d}  {"MATCH" if D == pred else "MISMATCH"}')
        else:
            rows3.append((p, D, pred, a[p]))
    n1 = sum(1 for p in primes_upto(PMAX) if p >= 5 and p % 4 == 1)
    print(f'\nH on p ≡ 1 (mod 4), 5 <= p <= {PMAX}: {n1} primes -> ' + ('PASS' if not fail1 else f'FAIL {fail1[:10]}'))
    print('\np ≡ 3 (mod 4) (no prior claim; first 8):')
    for p, D, pred, ap in rows3[:8]:
        print(f'   p={p:4d}  D={D:6d}  a(p)={ap:6d}  -a(p)-p={pred:6d}')
    print('   D(p) values for p≡3 mod 4 distinct set (first 30 primes):', sorted({r[1] for r in rows3[:30]}))
