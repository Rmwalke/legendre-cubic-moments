"""Stage 1 — exact check of Legendre-family moments against the published class-number formula.

Legendre family E_l : y^2 = x(x-1)(x-l), l = 2..p-1,  a(l) = -sum_x chi(x(x-1)(x-l)).

Published formula (Ono–Saad–Saikia, arXiv:2108.09560, Prop. 2.11(1), q = p, m even), read for l = 2..p-1:
    sum_l a(l)^m = 3 * sum_{s ≡ p+1 (mod 4), |s| <= 2 sqrt p} H((4p - s^2)/4) * s^m
with H the Hurwitz class number (classes of positive definite binary quadratic forms of
discriminant -N, not necessarily primitive; a(x^2+y^2) weighted 1/2, a(x^2+xy+y^2) weighted 1/3).

PASS/FAIL (fixed before running): PASS = exact equality (Fractions) for m = 2, 4, 6 at every
prime 5 <= p <= PMAX (both p ≡ 1 and p ≡ 3 mod 4). FAIL = any mismatch.
Also checks: sum a^2 = p^2 - 2p - 3 for every odd prime (R1 §3.1), Hasse bound, and the old
output file values (p ≡ 1 mod 4, p <= 101).
Usage: python E2_check_ap_moments_exact.py [PMAX]
"""
import sys
from fractions import Fraction
from math import isqrt
import numpy as np

PMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 1000

def primes_upto(n):
    s = bytearray([1]) * (n + 1); s[0:2] = b'\x00\x00'
    for i in range(2, isqrt(n) + 1):
        if s[i]: s[i*i::i] = bytearray(len(s[i*i::i]))
    return [i for i in range(n + 1) if s[i]]

def chi_table(p):
    c = np.full(p, -1, dtype=np.int64); c[0] = 0
    c[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1
    return c

def legendre_ap(p):
    c = chi_table(p); x = np.arange(p, dtype=np.int64); base = (x * (x - 1)) % p
    return [int(-c[(base * ((x - l) % p)) % p].sum()) for l in range(2, p)]

_H = {}
def hurwitz(N):
    """Hurwitz class number H(N) as an exact Fraction, by enumerating reduced forms."""
    if N in _H: return _H[N]
    if N == 0: return Fraction(-1, 12)
    if N % 4 in (1, 2): _H[N] = Fraction(0); return _H[N]
    tot = Fraction(0); a = 1
    while 3 * a * a <= N:
        for b in range(-a + 1, a + 1):
            if (b * b + N) % (4 * a): continue
            c = (b * b + N) // (4 * a)
            if c < a or (c == a and b < 0): continue
            if a == c and b == 0: tot += Fraction(1, 2)
            elif a == b == c: tot += Fraction(1, 3)
            else: tot += 1
        a += 1
    _H[N] = tot; return tot

def class_number_side(p, m):
    tot = Fraction(0); r = isqrt(4 * p)
    for s in range(-r, r + 1):
        if (s - (p + 1)) % 4 or s * s > 4 * p or s % p == 0: continue
        tot += hurwitz((4 * p - s * s) // 4) * s ** m
    return 3 * tot

OLD = {5: (12, 48, 192), 13: (140, 4016, 140480), 17: (252, 7920, 280512), 29: (780, 45744, 3560640),
       37: (1292, 95792, 8560832), 41: (1596, 113520, 9840576), 53: (2700, 266544, 35709120),
       61: (3596, 473264, 75797696), 73: (5180, 688496, 111335360), 89: (7740, 1347696, 317108160),
       97: (9212, 1909232, 475262912), 101: (9996, 2007600, 524181696)}

if __name__ == '__main__':
    fails = {'formula': [], 'sum_a2': [], 'hasse': [], 'old_file': []}
    n = 0
    print('p | p mod 4 | sum a^2 | sum a^4 | sum a^6 | class-number formula m=2,4,6')
    for p in primes_upto(PMAX):
        if p < 5: continue
        a = legendre_ap(p); n += 1
        M = [sum(t ** m for t in a) for m in (2, 4, 6)]
        F = [class_number_side(p, m) for m in (2, 4, 6)]
        ok = all(Fraction(Mi) == Fi for Mi, Fi in zip(M, F))
        if not ok: fails['formula'].append(p)
        if M[0] != p * p - 2 * p - 3: fails['sum_a2'].append(p)
        if any(t * t > 4 * p for t in a): fails['hasse'].append(p)
        if p in OLD and tuple(M) != OLD[p]: fails['old_file'].append(p)
        if p <= 101 or p % 100 < 4:
            print(p, p % 4, *M, 'MATCH' if ok else 'MISMATCH')
    print(f'\nprimes tested: {n} (5 <= p <= {PMAX})')
    for k, v in fails.items():
        print(f'{k:10s}: {"PASS" if not v else "FAIL at " + str(v[:20])}')
