"""H17 — analysis of H13 runner output (H13_output_data.txt).  Runs in chat (light); no network.
Reads integer-valued s1, s2 and u derived from rounded FFTs. Statistics are floating point.
 1. Re-evaluates H11 §5 criteria 1, 2 (same rules as the runner summary).
 2. Kolmogorov–Smirnov distance of x1 = s1/p^{5/2} vs the USp(4) a1-distribution (Weyl integration), with the
    nominal iid 5% reference value 1.36/sqrt(n). This is a heuristic diagnostic, not a calibrated test for primes.
 3. Congruence patterns: s1, s2 mod 2^k, 3, 9 (structure hints; exploratory, no PASS/FAIL).
 4. Inert primes: y = u/p^5; mean vs -1 (connected USp(4) value of Tr g^2); exploratory.
 5. Plots (PNG): histogram of x1 with USp(4) density; scatter (x1, x2) with the USp(4) region; histogram of y.
Usage: python -I H17_...py path/to/H13_output_data.txt [outdir]
"""
import sys, os, math
from collections import Counter
import numpy as np

path = sys.argv[1]; outdir = sys.argv[2] if len(sys.argv) > 2 else '.'
split, inert = [], []
for line in open(path, encoding='utf-8'):
    if line.startswith('#') or not line.strip(): continue
    t = line.split()
    if t[1] == 'split': split.append((int(t[0]), int(t[2]), int(t[3])))
    else: inert.append((int(t[0]), int(t[2])))
print(f'data: {len(split)} split primes, {len(inert)} inert primes, max p = {max(p for p, *_ in split + inert)}')

# USp(4) reference by Weyl integration
n = 800
th = (np.arange(n) + 0.5) * math.pi / n
C1, C2 = np.meshgrid(np.cos(th), np.cos(th), indexing='ij')
S1, S2 = np.meshgrid(np.sin(th), np.sin(th), indexing='ij')
W = (C1 - C2) ** 2 * S1 ** 2 * S2 ** 2; W /= W.sum()
A1 = (2 * C1 + 2 * C2).ravel(); A2 = (2 + 4 * C1 * C2).ravel(); Wf = W.ravel()
ref = lambda f: float(np.sum(Wf * f))
order = np.argsort(A1); A1s = A1[order]; cdf = np.cumsum(Wf[order])

x1 = np.array([s1 / p ** 2.5 for p, s1, s2 in split]); x2 = np.array([s2 / p ** 5 for p, s1, s2 in split])

# 1. criteria
def is_sq(D): return D >= 0 and math.isqrt(D) ** 2 == D
Ds = [(p, s1 * s1 - 4 * (s2 - 2 * p ** 5)) for p, s1, s2 in split]
sq = [p for p, D in Ds if is_sq(D)]
print(f'\n[1] D perfect square at: {sq}  ({len(sq)} of {len(split)})')
for k in (2, 4, 6):
    m = float(np.mean(x1 ** k)); r = ref(A1 ** k); se = math.sqrt((ref(A1 ** (2 * k)) - r * r) / len(x1))
    print(f'    E[x1^{k}] = {m:.4f}  USp(4) {r:.4f}  ({(m - r) / se:+.2f} sigma)')
for k in (1, 2, 3):
    m = float(np.mean(x2 ** k)); r = ref(A2 ** k); se = math.sqrt((ref(A2 ** (2 * k)) - r * r) / len(x2))
    print(f'    E[x2^{k}] = {m:.4f}  USp(4) {r:.4f}  ({(m - r) / se:+.2f} sigma)')

# 2. KS
xs = np.sort(x1); F = np.interp(xs, A1s, cdf)
emp_hi = np.arange(1, len(xs) + 1) / len(xs); emp_lo = np.arange(0, len(xs)) / len(xs)
Dks = float(max(np.max(emp_hi - F), np.max(F - emp_lo))); crit = 1.36 / math.sqrt(len(xs))
print(f'\n[2] KS distance x1 vs USp(4): {Dks:.4f}   nominal iid 5% reference {crit:.4f}  => {"compatible in this diagnostic" if Dks < crit else "outside reference band"}')

# 3. congruences
for m in (8, 16, 3, 9):
    print(f'[3] s1 mod {m}: {dict(sorted(Counter(s1 % m for p, s1, s2 in split).items()))}')
for m in (8, 16, 3, 9):
    print(f'    s2 mod {m}: {dict(sorted(Counter(s2 % m for p, s1, s2 in split).items()))}')
print('    zero traces s1 = 0 at:', [p for p, s1, s2 in split if s1 == 0])

# 4. inert
if inert:
    y = np.array([u / p ** 5 for p, u in inert]); r = ref(A1 ** 2 - 2 * A2); se = math.sqrt((ref((A1 ** 2 - 2 * A2) ** 2) - r * r) / len(y))
    print(f'\n[4] inert y = u/p^5: mean {np.mean(y):.4f}  (connected USp(4): {r:.4f}, {(np.mean(y) - r) / se:+.2f} sigma);  E[y^2] {np.mean(y ** 2):.4f} (USp(4) {ref((A1 ** 2 - 2 * A2) ** 2):.4f})')
    print(f'    u mod 8: {dict(sorted(Counter(u % 8 for p, u in inert).items()))}')

# 5. plots
try:
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
    bins = np.linspace(-4, 4, 33)
    ax[0].hist(x1, bins=bins, density=True, color='#4C78A8', alpha=.75, label=f'data ({len(x1)} split p)')
    dens, _ = np.histogram(A1, bins=bins, weights=Wf, density=True)
    ax[0].step(bins[:-1], dens, where='post', color='#E45756', lw=2, label='USp(4)')
    ax[0].set_title('x1 = s1 / p^{5/2}'); ax[0].legend()
    sub = np.random.default_rng(0).choice(len(A1), 4000, p=Wf)
    ax[1].scatter(A1[sub], A2[sub], s=2, color='#BBBBBB', label='USp(4) sample')
    ax[1].scatter(x1, x2, s=8, color='#4C78A8', label='data'); ax[1].set_xlabel('x1'); ax[1].set_ylabel('x2 = s2/p^5')
    ax[1].set_title('(x1, x2)'); ax[1].legend()
    if inert:
        ax[2].hist(y, bins=30, density=True, color='#72B7B2', alpha=.8, label=f'inert ({len(y)})')
        dy, b2 = np.histogram(A1 ** 2 - 2 * A2, bins=30, weights=Wf, density=True)
        ax[2].step(b2[:-1], dy, where='post', color='#E45756', lw=2, label='Tr g^2, USp(4)')
        ax[2].set_title('inert: y = u/p^5'); ax[2].legend()
    fig.tight_layout(); out = os.path.join(outdir, 'H17_plots.png'); fig.savefig(out, dpi=110); print('\nplot ->', out)
except ImportError:
    print('matplotlib missing: plots skipped')
