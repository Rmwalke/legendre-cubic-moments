"""H8 — explore: full char. poly of the 4-dim piece V (cubic twist, Sym^4) from F_{p^n}, n = 1..4.
 GF(p^n) via a primitive polynomial; log/antilog tables; elements encoded as base-p integers (digits = coeffs).
 For q = p^n:  M2(q), M4(q) = sum_{l != 0,1} rho(l) a_q(l)^{2,4} (rho = cubic char of F_q, real part S0 - S1).
   t2(q) = -M2(q) - 1 - q                                  (verified H5/H6 for n = 1, 2)
   P_n = Tr(Frob_q | V) = -M4(q) - 1 - 3q t2(q) - 3q - 2q^2  (boundary at l=1: weight-0 invariant, eigenvalue 1)
 Newton -> e1..e4 (exact Fractions); report e4/p^10, |roots|/p^{5/2}, e3/(p^5 e1).
Usage: python -I H8_...py p nmax
"""
import sys, itertools
from fractions import Fraction as Fr
import numpy as np

p = int(sys.argv[1]); NMAX = int(sys.argv[2])

def polymulmod(a, b, mod, p):
    n = len(mod) - 1; r = [0] * (2 * n - 1)
    for i, x in enumerate(a):
        if x:
            for j, y in enumerate(b): r[i + j] = (r[i + j] + x * y) % p
    for d in range(len(r) - 1, n - 1, -1):          # mod monic 'mod' (coeff list low->high)
        c = r[d]
        if c:
            for k in range(n + 1): r[d - n + k] = (r[d - n + k] - c * mod[k]) % p
    return r[:n]

def gf(p, n):
    q = p ** n
    if n == 1:
        g = next(g for g in range(2, p) if all(pow(g, (p - 1) // f, p) != 1 for f in range(2, p) if (p - 1) % f == 0 and all(f % d for d in range(2, f))))
        exp = np.zeros(q - 1, dtype=np.int64); v = 1
        for e in range(q - 1): exp[e] = v; v = v * g % p
        return q, exp
    for tail in itertools.product(range(p), repeat=n):
        mod = list(tail) + [1]
        if mod[0] == 0: continue
        x = [0, 1] + [0] * (n - 2); v = [1] + [0] * (n - 1); seen = set(); ok = True
        exps = []
        for e in range(q - 1):
            code = sum(c * p ** i for i, c in enumerate(v))
            if code in seen: ok = False; break
            seen.add(code); exps.append(code); v = polymulmod(v, x, mod, p)
        if ok and len(seen) == q - 1: return q, np.array(exps, dtype=np.int64)

def run(n):
    q, exp = gf(p, n)
    log = np.full(q, -1, dtype=np.int64); log[exp] = np.arange(q - 1)
    pw = p ** np.arange(n)
    digits = lambda arr: (arr[..., None] // pw) % p
    def sub(a, b):  # a - b elementwise (arrays of codes)
        return (((digits(a) - digits(b)) % p) * pw).sum(-1)
    xs = np.arange(q); xm1 = sub(xs, np.ones(q, dtype=np.int64))
    S2 = [0, 0, 0]; S4 = [0, 0, 0]
    for l in range(q):
        if l in (0, 1): continue          # codes: 0 = zero, 1 = one
        xl = sub(xs, np.full(q, l))
        nz = (xs != 0) & (xm1 != 0) & (xl != 0)
        s = (log[xs[nz]] + log[xm1[nz]] + log[xl[nz]]) % 2
        a = -int((1 - 2 * s).sum())
        j = int(log[l] % 3); S2[j] += a * a; S4[j] += a ** 4
    assert S2[1] == S2[2] and S4[1] == S4[2], (n, S2, S4)
    return q, S2[0] - S2[1], S4[0] - S4[1]

data = {n: run(n) for n in range(1, NMAX + 1)}
for n, (q, m2, m4) in data.items(): print(f'n={n} q={q}  M2={m2}  M4={m4}  t2={-m2 - 1 - q}')
for eps in ('one',):
    P = []
    for n in range(1, NMAX + 1):
        q, m2, m4 = data[n]; t2 = -m2 - 1 - q
        P.append(Fr(-m4 - 1 - 3 * q * t2 - 3 * q - 2 * q * q))
    e = [Fr(1)]
    for k in range(1, NMAX + 1):
        e.append(sum((-1) ** (i - 1) * e[k - i] * P[i - 1] for i in range(1, k + 1)) / k)
    line = f'boundary=1  e1..e{NMAX}={[str(x) for x in e[1:]]}'
    if NMAX >= 4:
        coeffs = [float((-1) ** k * e[k]) for k in range(5)]
        r = np.roots(coeffs)
        line += f'  e4/p^10={float(e[4]) / p ** 10:.6f}  e3/(p^5 e1)={float(e[3] / (p ** 5 * e[1])) if e[1] else None}'
        line += f'  |roots|/p^2.5={[round(abs(z) / p ** 2.5, 6) for z in r]}'
    print(line)
