"""H9 — explore: V (4-dim, cubic twist, Sym^4) char poly x^4 - s1 x^3 + s2 x^2 - p^5 s1 x + p^10
(shape verified exactly with n<=4 at p = 7, 13 in H8). From F_p, F_{p^2}:
   s1 = Tr V(p),  s2 = (s1^2 - Tr V(p^2))/2,  Tr V(q) = -M4(q) - 1 - 3q t2(q) - 3q - 2q^2,  t2(q) = -M2(q) - 1 - q.
 y = x + p^5/x :  y^2 - s1 y + (s2 - 2p^5);  D = s1^2 - 4(s2 - 2 p^5).  Report squarefree part of D, and roots a,b if D square.
Usage: python -I H9_...py PMAX
"""
import sys
import numpy as np
src = open('H5_check_cubic_k2_Fp2_relation_2026-10-27.py').read().split("print(' p ")[0]
ns = {}; exec(compile(src, 'h5', 'exec'), ns)
field, is_prime = ns['field'], ns['is_prime']
src7 = open('H7_explore_cubic_k4_charpoly_2026-10-27.py').read().split('for p in range(7')[0]
src7 = src7.replace("spec = importlib.util.spec_from_file_location('h5', 'H5_check_cubic_k2_Fp2_relation_2026-10-27.py')", "")
exec(compile(src7.split("src = open")[0] + "\n", 'h7a', 'exec'), ns)
exec(compile("def moments" + src7.split("def moments")[1], 'h7b', 'exec'), ns)
moments = ns['moments']
from math import isqrt
def sqf(n):
    s = 1 if n > 0 else -1; n = abs(n); out = 1; d = 2
    while d * d <= n:
        while n % (d * d) == 0: n //= d * d
        if n % d == 0: out *= d; n //= d
        d += 1
    return s * out * n
PMAX = int(sys.argv[1])
for p in range(7, PMAX + 1):
    if not is_prime(p) or p % 3 != 1: continue
    _, m2a, m4a = moments(p, 1); _, m2b, m4b = moments(p, 2)
    TV = lambda q, m2, m4: -m4 - 1 - 3 * q * (-m2 - 1 - q) - 3 * q - 2 * q * q
    s1 = TV(p, m2a, m4a); s2 = (s1 * s1 - TV(p * p, m2b, m4b)) // 2
    D = s1 * s1 - 4 * (s2 - 2 * p ** 5)
    ab = ((s1 + isqrt(D)) // 2, (s1 - isqrt(D)) // 2) if D >= 0 and isqrt(D) ** 2 == D else None
    print(f'p={p:3d} p mod 8={p % 8} mod 12={p % 12}  s1={s1:8d}  s2={s2:14d}  D={D:14d}  sqfree(D)={sqf(D):10d}  a,b={ab}')
