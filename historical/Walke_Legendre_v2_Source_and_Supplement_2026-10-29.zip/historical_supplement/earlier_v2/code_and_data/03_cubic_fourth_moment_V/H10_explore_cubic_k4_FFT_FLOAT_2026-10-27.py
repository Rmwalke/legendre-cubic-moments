"""H10 (FLOAT) — fast s1, s2 for the 4-dim piece V (cubic twist, Sym^4), via FFT correlations.
 F_q, q = p or p^2 (elements a + b*i, i^2 = nr).  chi_q(z) = chi_p(N z),  rho_q(z) = rho_p(N z)  (p ≡ 1 mod 3).
 a_q(l) = -sum_x f(x) chi_q(x - l),  f(x) = chi_q(x) chi_q(x-1)  -> additive cross-correlation on (Z/p)^n via FFT.
 FLOAT: FFT values rounded to integers; checks: |a| <= 2 sqrt(q), a ≡ q+1 (mod 4), from full rational 2-torsion, and
 exact cross-check against H9 (direct, exact) at p <= 67.
 Output per prime: s1, s2, D, x = s1/p^{5/2}; then moment statistics of x (Sato–Tate diagnostics).
Usage: python -I H10_...py PMAX [S1ONLY_PMAX]
"""
import sys, json
import numpy as np
from math import isqrt
PMAX = int(sys.argv[1]); S1MAX = int(sys.argv[2]) if len(sys.argv) > 2 else PMAX

def is_prime(n): return n > 1 and all(n % d for d in range(2, isqrt(n) + 1))
def prim_root(p):
    fac = [d for d in range(2, p) if (p - 1) % d == 0 and is_prime(d)]
    return next(g for g in range(2, p) if all(pow(g, (p - 1) // f, p) != 1 for f in fac))

def tables(p):
    g = prim_root(p); ind = np.zeros(p, dtype=np.int64); v = 1
    for e in range(p - 1): ind[v] = e; v = v * g % p
    chi = np.where(ind % 2 == 0, 1, -1); chi[0] = 0
    rho = ind % 3                                    # class index; rho(0) unused
    return chi, rho

def moments_q(p, n):
    chi, rho = tables(p)
    if n == 1:
        X = np.arange(p); Nx = X; Nx1 = (X - 1) % p
        cq = chi[Nx]; f = cq * chi[Nx1]
        F = np.fft.fft(f); G = np.fft.fft(cq)
        corr = np.fft.ifft(F * np.conj(G)).real     # corr[l] = sum_x f(x) chi(x - l)
        a = -np.rint(corr).astype(np.int64)
        L = np.arange(p); Nl = L
    else:
        nr = next(x for x in range(2, p) if chi[x] == -1)
        A, B = np.meshgrid(np.arange(p), np.arange(p), indexing='ij')
        N = (A * A - nr * B * B) % p; N1 = ((A - 1) ** 2 - nr * B * B) % p
        cq = chi[N]; f = cq * chi[N1]
        corr = np.fft.ifft2(np.fft.fft2(f) * np.conj(np.fft.fft2(cq))).real
        a = -np.rint(corr).astype(np.int64)
        Nl = N
    q = p ** n
    a = a.ravel(); Nl = np.asarray(Nl).ravel()
    idx = np.arange(q)
    mask = np.ones(q, bool); mask[0] = False; mask[1 if n == 1 else p] = False   # exclude l = 0, l = 1 (n=2: index a*p+b, so 1 = index p)
    assert np.all(np.abs(a[mask]) <= 2 * np.sqrt(q) + 1e-9) and np.all((a[mask] - (q + 1)) % 4 == 0)
    cls = rho[Nl[mask]]; am = a[mask]
    S2 = [int((am[cls == j] ** 2).sum()) for j in range(3)]
    S4 = [int((am[cls == j].astype(object) ** 4).sum()) for j in range(3)]
    assert S2[1] == S2[2] and S4[1] == S4[2]
    return S2[0] - S2[1], S4[0] - S4[1]

def TV(q, m2, m4): return -m4 - 1 - 3 * q * (-m2 - 1 - q) - 3 * q - 2 * q * q
def sqf(n):
    s = 1 if n > 0 else -1; n = abs(n); out = 1; d = 2
    while d * d <= n:
        while n % (d * d) == 0: n //= d * d
        if n % d == 0: out *= d; n //= d
        d += 1
    return s * out * n

exact_H9 = {7: (-32, -12786), 13: (28, 113790), 19: (-2504, 4136790), 31: (-272, 13560126),
            37: (2284, 46569486), 43: (4168, -58885050), 61: (-16484, 617583198), 67: (1144, 1689885750)}
res = {}
for p in range(7, S1MAX + 1):
    if not is_prime(p) or p % 3 != 1: continue
    m2, m4 = moments_q(p, 1); s1 = TV(p, m2, m4)
    t2 = -m2 - 1 - p
    row = {'s1': s1, 't2': t2}
    if p <= PMAX:
        m2b, m4b = moments_q(p, 2); s2 = (s1 * s1 - TV(p * p, m2b, m4b)) // 2
        D = s1 * s1 - 4 * (s2 - 2 * p ** 5)
        row.update(s2=s2, D=D, sqfD=sqf(D), Dsq=(isqrt(D) ** 2 == D) if D >= 0 else False)
        if p in exact_H9: assert (s1, s2) == exact_H9[p], ('FLOAT mismatch vs exact', p)
    res[p] = row
json.dump({str(k): v for k, v in res.items()}, open(f'H10_data_p_upto_{S1MAX}.json', 'w'))
print('cross-check vs exact H9 (p<=67): OK')
sq = [p for p, r in res.items() if r.get('Dsq')]
print(f'primes with s2: {sum(1 for r in res.values() if "s2" in r)};  D perfect square at: {sq}')
print('sqfree(D) first 25:', [(p, r['sqfD']) for p, r in list(res.items())[:25] if 'sqfD' in r])
x = np.array([r['s1'] / p ** 2.5 for p, r in res.items()])
print(f'\n#primes for s1 stats: {len(x)} (p<= {S1MAX})')
for k in (1, 2, 3, 4, 6):
    print(f'  E[x^{k}] = {np.mean(x ** k):.4f}')
print('  reference: USp(4): E[x^2]=1, E[x^4]=3, E[x^6]=14 ;  SU(2)xSU(2) (split pair): E[x^2]=2, E[x^4]=10')
