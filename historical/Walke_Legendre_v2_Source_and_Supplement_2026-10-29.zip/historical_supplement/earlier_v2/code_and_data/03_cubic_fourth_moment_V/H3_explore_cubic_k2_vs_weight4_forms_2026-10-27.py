"""H3 — explore: fit M_{3,2}(p) (p ≡ 1 mod 3) on {1, p, f(p)} for eta-quotient weight-4 forms f:
   36.4.a.a = eta(6z)^8 ; 8.4.a.a = eta(2z)^4 eta(4z)^4 ; 6.4.a.a = (eta(z)eta(2z)eta(3z)eta(6z))^2 ;
   9.4.a.a = eta(3z)^8 ; 18.4.a.a? not eta, skipped.  Exact Fractions; fit on first primes, test on all.
Usage: python -I H3_...py PMAX
"""
import sys, itertools
from fractions import Fraction as Fr
import importlib.util
spec = importlib.util.spec_from_file_location('h1', 'H1_explore_order_n_twisted_moments_2026-10-27.py')
h1 = importlib.util.module_from_spec(spec); spec.loader.exec_module(h1)
spec2 = importlib.util.spec_from_file_location('h2s', 'H2_explore_cubic_twist_fit_2026-10-27.py')
PMAX = int(sys.argv[1]); N = PMAX + 2

def eta_prod(spec, shift):
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec:
        for n in range(1, N // m + 1):
            for _ in range(e):
                for i in range(N, m * n - 1, -1): P[i] -= P[i - m * n]
    return ([0] * shift + P)[:N + 1]

forms = {
 '36.4.a.a': eta_prod([(6, 8)], 2),          # eta(6z)^8 = q^2 prod... -> q^(48/24)=q^2 ? check
 '8.4.a.a': eta_prod([(2, 4), (4, 4)], 1),
 '6.4.a.a': eta_prod([(1, 2), (2, 2), (3, 2), (6, 2)], 1),
 '9.4.a.a': eta_prod([(3, 8)], 1),
}
# eta(6z)^8: q^{6*8/24} = q^2 -> not a q-start newform; correct 36.4.a.a is eta(6z)^4? weight 2. Fix: use eta(6z)^8 only if starts at q.
print({k: [v[n] for n in range(1, 14)] for k, v in forms.items()})
