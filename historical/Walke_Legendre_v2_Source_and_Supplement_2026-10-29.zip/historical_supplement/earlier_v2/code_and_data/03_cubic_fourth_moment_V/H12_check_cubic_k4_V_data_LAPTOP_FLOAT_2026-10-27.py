"""H12 (LAPTOP, FLOAT) — data for the 4-dim piece V of the cubic-twisted 4th moment of the Legendre family.
Definitions (see H11 notes):
  M2(q), M4(q) = sum_{l in F_q, l != 0,1} rho(l) a_q(l)^{2,4}   (rho cubic char of F_q; real part = S0 - S1)
  t2(q) = -M2(q) - 1 - q ;   TrV(q) = -M4(q) - 1 - 3q t2(q) - 3q - 2q^2
  split p (p ≡ 1 mod 3):  s1 = TrV(p),  s2 = (s1^2 - TrV(p^2))/2,  char poly x^4 - s1 x^3 + s2 x^2 - p^5 s1 x + p^10
  inert p (p ≡ 2 mod 3):  u(p) = TrV(p^2)  (trace of Frob_{p^2}),  plus t2(p^2)
FLOAT: a_q(l) via FFT correlations, rounded; asserted |a| <= 2 sqrt q, a even; exact cross-check table for p <= 67.
Checkpoint: results appended to H12_checkpoint.jsonl (restart-safe). Final table -> H12_output_p_upto_PMAX.txt
Runtime estimate: F_{p^2} FFT of size p^2;  PMAX=1500 ≈ 10–30 min,  PMAX=3000 ≈ 1–3 h (depends on laptop/RAM ~ 1 GB at p=3000).
Usage: python H12_...py PMAX
"""
import sys, json, os, time
import numpy as np
from math import isqrt
PMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 1500
CK = 'H12_checkpoint.jsonl'

def is_prime(n): return n > 1 and all(n % d for d in range(2, isqrt(n) + 1))
def prim_root(p):
    fac = [d for d in range(2, p) if (p - 1) % d == 0 and is_prime(d)]
    return next(g for g in range(2, p) if all(pow(g, (p - 1) // f, p) != 1 for f in fac))

def chi_table(p):
    c = np.full(p, -1, dtype=np.int64); c[0] = 0
    c[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1
    return c

def cubic_class_Fp(p):
    g = prim_root(p); ind = np.zeros(p, dtype=np.int64); v = 1
    for e in range(p - 1): ind[v] = e; v = v * g % p
    return ind % 3

def fp2_pow(A, B, e, p, nr):
    """(A + B i)^e elementwise, i^2 = nr; A, B int64 arrays."""
    RA = np.ones_like(A); RB = np.zeros_like(B); XA, XB = A.copy(), B.copy()
    while e:
        if e & 1: RA, RB = (RA * XA + nr * RB * XB) % p, (RA * XB + RB * XA) % p
        XA, XB = (XA * XA + nr * XB * XB) % p, (2 * XA * XB) % p
        e >>= 1
    return RA, RB

def moments(p, n):
    chi = chi_table(p)
    if n == 1:
        X = np.arange(p); cq = chi[X]; f = cq * chi[(X - 1) % p]
        a = -np.rint(np.fft.ifft(np.fft.fft(f) * np.conj(np.fft.fft(cq))).real).astype(np.int64)
        cls = cubic_class_Fp(p); excl = [0, 1]; q = p
    else:
        nr = next(x for x in range(2, p) if chi[x] == -1)
        A, B = np.meshgrid(np.arange(p, dtype=np.int64), np.arange(p, dtype=np.int64), indexing='ij')
        N = (A * A - nr * B * B) % p; N1 = ((A - 1) ** 2 - nr * B * B) % p
        cq = chi[N]; f = cq * chi[N1]
        a = -np.rint(np.fft.ifft2(np.fft.fft2(f) * np.conj(np.fft.fft2(cq))).real).astype(np.int64).ravel()
        q = p * p
        if p % 3 == 1:
            cls = cubic_class_Fp(p)[N.ravel()]
        else:  # cubic char of F_{p^2} via z^{(q-1)/3} in {1, w, w^2}
            RA, RB = fp2_pow(A.ravel(), B.ravel(), (q - 1) // 3, p, nr)
            vals = {}
            cls = np.zeros(q, dtype=np.int64)
            keys = RA * p + RB
            uniq = [k for k in np.unique(keys[1:])]
            one = 1 * p + 0
            assert one in uniq and len(uniq) == 3, uniq
            others = [k for k in uniq if k != one]
            cls[keys == others[0]] = 1; cls[keys == others[1]] = 2
        excl = [0, p]
    mask = np.ones(q, bool); mask[excl] = False
    am = a[mask]; cm = cls[mask]
    assert np.all(np.abs(am) <= 2 * np.sqrt(q) + 1e-9) and np.all(am % 2 == 0), 'FLOAT rounding problem'
    S2 = [int((am[cm == j] ** 2).sum()) for j in range(3)]
    S4 = [int(sum(int(x) ** 4 for x in am[cm == j])) for j in range(3)] if q < 2000 else \
         [int(((am[cm == j].astype(np.float64)) ** 0).sum() * 0) + int(np.sum(np.asarray(am[cm == j], dtype=object) ** 4)) for j in range(3)]
    assert S2[1] == S2[2] and S4[1] == S4[2], 'class symmetry failed'
    return S2[0] - S2[1], S4[0] - S4[1]

def TV(q, m2, m4): return -m4 - 1 - 3 * q * (-m2 - 1 - q) - 3 * q - 2 * q * q

EXACT = {7: (-32, -12786), 13: (28, 113790), 19: (-2504, 4136790), 31: (-272, 13560126),
         37: (2284, 46569486), 43: (4168, -58885050), 61: (-16484, 617583198), 67: (1144, 1689885750)}
done = {}
if os.path.exists(CK):
    for line in open(CK): r = json.loads(line); done[r['p']] = r
with open(CK, 'a') as ck:
    for p in range(5, PMAX + 1):
        if not is_prime(p) or p in done: continue
        t0 = time.time()
        if p % 3 == 1:
            m2, m4 = moments(p, 1); m2b, m4b = moments(p, 2)
            s1 = TV(p, m2, m4); s2 = (s1 * s1 - TV(p * p, m2b, m4b)) // 2
            r = {'p': p, 'type': 'split', 's1': s1, 's2': s2, 't2': -m2 - 1 - p}
            if p in EXACT: assert (s1, s2) == EXACT[p], 'mismatch vs exact'
        else:
            m2b, m4b = moments(p, 2)
            r = {'p': p, 'type': 'inert', 'u': TV(p * p, m2b, m4b), 't2_p2': -m2b - 1 - p * p}
        r['sec'] = round(time.time() - t0, 2)
        ck.write(json.dumps(r) + '\n'); ck.flush(); done[p] = r
        print(r, flush=True)
rows = [done[p] for p in sorted(done) if p <= PMAX]
with open(f'H12_output_p_upto_{PMAX}.txt', 'w') as out:
    out.write('# H12 output. split: p s1 s2 t2 ; inert: p u=TrV(Frob_p^2) t2(p^2)\n')
    for r in rows:
        out.write((f"{r['p']} split {r['s1']} {r['s2']} {r['t2']}" if r['type'] == 'split'
                   else f"{r['p']} inert {r['u']} {r['t2_p2']}") + '\n')
    x = np.array([r['s1'] / r['p'] ** 2.5 for r in rows if r['type'] == 'split'])
    out.write(f'# split primes: {len(x)};  E[x^2]={np.mean(x**2):.4f} E[x^4]={np.mean(x**4):.4f} E[x^6]={np.mean(x**6):.4f}  (USp(4): 1, 3, 14)\n')
print('written', f'H12_output_p_upto_{PMAX}.txt')
