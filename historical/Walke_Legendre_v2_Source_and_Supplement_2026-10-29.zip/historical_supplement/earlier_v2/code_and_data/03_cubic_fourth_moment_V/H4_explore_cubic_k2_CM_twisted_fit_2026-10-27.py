"""H4 — explore: fit M_{3,k}(p), p ≡ 1 mod 3, on {p^j} ∪ {p^j Re(w^{c e2 + d e3} J^t)},
where e2 = ind(2) mod 3, e3 = ind(3) mod 3 (cubic residue classes, same generator as rho and J),
J = J(rho,rho) made primary. Exact Fractions; fit on first part, residual check on all.
Usage: python -I H4_...py PMAX K
"""
import sys
from fractions import Fraction as Fr
import importlib.util
spec = importlib.util.spec_from_file_location('h1', 'H1_explore_order_n_twisted_moments_2026-10-27.py')
h1 = importlib.util.module_from_spec(spec); spec.loader.exec_module(h1)
PMAX = int(sys.argv[1]); K = int(sys.argv[2])

def mul(z1, z2):  # (a+bw)(c+dw), w^2=-1-w
    a, b = z1; c, d = z2
    return (a * c - b * d, a * d + b * c - b * d)

def data(p):
    g = h1.prim_root(p); ind = [0] * p; v = 1
    for e in range(p - 1): ind[v] = e; v = v * g % p
    cnt = [0, 0, 0]
    for x in range(2, p): cnt[(ind[x] + ind[(1 - x) % p]) % 3] += 1
    z = (cnt[0] - cnt[2], cnt[1] - cnt[2])     # sum cnt_j w^j with rho(g)=w
    for _ in range(3):
        if (z[0] + 1) % 3 == 0 and z[1] % 3 == 0: break
        if (-z[0] + 1) % 3 == 0 and z[1] % 3 == 0: z = (-z[0], -z[1]); break
        z = mul(z, (0, 1))
    assert (z[0] + 1) % 3 == 0 and z[1] % 3 == 0
    tr = h1.traces(p)
    S = [0, 0, 0]
    for l in range(2, p): S[ind[l] % 3] += tr[l] ** K
    assert S[1] == S[2]
    return S[0] - S[1], z, ind[2] % 3, ind[3] % 3

def wpow(j):
    z = (1, 0)
    for _ in range(j % 3): z = mul(z, (0, 1))
    return z
def zpow(z, t):
    r = (1, 0)
    for _ in range(t): r = mul(r, z)
    return r
def re(z): return Fr(2 * z[0] - z[1], 2)

def solve(A, y):
    n = len(A[0]); M = [[sum(A[r][i] * A[r][j] for r in range(len(A))) for j in range(n)] for i in range(n)]
    v = [sum(A[r][i] * y[r] for r in range(len(A))) for i in range(n)]
    for c in range(n):
        piv = next((r for r in range(c, n) if M[r][c] != 0), None)
        if piv is None: return None
        M[c], M[piv] = M[piv], M[c]; v[c], v[piv] = v[piv], v[c]
        for r in range(n):
            if r != c and M[r][c] != 0:
                f = M[r][c] / M[c][c]; M[r] = [M[r][j] - f * M[c][j] for j in range(n)]; v[r] -= f * v[c]
    return [v[i] / M[i][i] for i in range(n)]

D = [(p,) + data(p) for p in h1.primes_upto(PMAX) if p > 5 and p % 3 == 1]
hits = []
for c in range(3):
    for d in range(3):
        rows, ys = [], []
        for p, M, J, e2, e3 in D:
            u = wpow(c * e2 + d * e3)
            b = [Fr(p) ** j for j in range(K // 2 + 2)]
            for t in range(1, K + 2):
                for j in range(K // 2 + 1):
                    if t + 2 * j <= K + 2: b.append(Fr(p) ** j * re(mul(u, zpow(J, t))))
            rows.append(b); ys.append(Fr(M))
        nb = len(rows[0]); cut = nb + 8
        co = solve(rows[:cut], ys[:cut])
        if co is None: continue
        bad = sum(1 for r, y in zip(rows, ys) if y != sum(a * x for a, x in zip(co, r)))
        print(f'c={c} d={d}: basis {nb}, primes {len(rows)}, nonzero residuals {bad}')
        if bad == 0: hits.append((c, d, [str(x) for x in co]))
print('exact fits:', hits)
