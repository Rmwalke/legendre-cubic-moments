"""H7 — explore: 4-dim weight-5 piece of the cubic-twisted 4th moment.
 a^4 = TrSym^4 + 3q TrSym^2 + 2q^2.  Over F_q (q = p, p^2; p ≡ 1 mod 3):
   M2(q) = sum rho(l) a(l)^2,  M4(q) = sum rho(l) a(l)^4  (l != 0,1; real parts S0 - S1).
 H6:  t2(q) := -M2(q) - 1 - q  (= a_{36.4.a.a}(p) at q=p).
 Ansatz: t4(q) := -M4(q) - eps*q^2 - 3q*t2(q) - 3q - 2q^2   (eps in {-1,0,1}, boundary term at l=1; for q=p^2, eps^2).
 Test: s1 = t4(p), s2 = (s1^2 - t4(p^2))/2 integral, and P(x) = x^4 - s1 x^3 + s2 x^2 - p^5 s1 x + p^10
 has all roots on |x| = p^{5/2}.  Then try factoring P over Z into two quadratics x^2 - a x + p^5.
Usage: python -I H7_...py PMAX
"""
import sys, cmath
import numpy as np
import importlib.util
spec = importlib.util.spec_from_file_location('h5', 'H5_check_cubic_k2_Fp2_relation_2026-10-27.py')
src = open('H5_check_cubic_k2_Fp2_relation_2026-10-27.py').read().split("print(' p ")[0]
ns = {}; exec(compile(src, 'h5', 'exec'), ns)
field, is_prime = ns['field'], ns['is_prime']
PMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 43

def moments(p, deg):
    q, add, mul = field(p, deg)
    neg = np.array([int(np.where(add[x] == 0)[0][0]) for x in range(q)])
    for g in range(2, q):
        v = 1
        for e in range(1, q):
            v = mul[v, g]
            if v == 1: break
        if e == q - 1: break
    ind = np.zeros(q, dtype=np.int64); v = 1
    for e in range(q - 1): ind[v] = e; v = mul[v, g]
    chi = np.where(ind % 2 == 0, 1, -1); chi[0] = 0
    xs = np.arange(q); base = mul[xs, add[xs, neg[1]]]
    S2 = [0, 0, 0]; S4 = [0, 0, 0]
    for l in range(2, q):
        a = -int(chi[mul[base, add[xs, neg[l]]]].sum()); j = int(ind[l] % 3)
        S2[j] += a ** 2; S4[j] += a ** 4
    assert S2[1] == S2[2] and S4[1] == S4[2]
    return q, S2[0] - S2[1], S4[0] - S4[1]

for p in range(7, PMAX + 1):
    if not is_prime(p) or p % 3 != 1: continue
    q1, m2a, m4a = moments(p, 1); q2, m2b, m4b = moments(p, 2)
    t2a = -m2a - 1 - p; t2b = -m2b - 1 - p * p
    assert t2b == t2a ** 2 - 2 * p ** 3, 'k=2 F_p^2 relation broken'
    for eps in (-1, 0, 1):
        s1 = -m4a - eps * p * p - 3 * p * t2a - 3 * p - 2 * p * p
        t4b = -m4b - eps * eps * p ** 4 - 3 * p * p * t2b - 3 * p * p - 2 * p ** 4
        num = s1 * s1 - t4b
        if num % 2: print(p, eps, 's2 not integral'); continue
        s2 = num // 2
        roots = np.roots([1, -s1, s2, -p ** 5 * s1, p ** 10])
        weil = max(abs(abs(r) / p ** 2.5 - 1) for r in roots)
        # factor into (x^2 - a x + p^5)(x^2 - b x + p^5): a+b = s1, ab + 2p^5 = s2
        disc = s1 * s1 - 4 * (s2 - 2 * p ** 5)
        from math import isqrt
        fac = None
        if disc >= 0 and isqrt(disc) ** 2 == disc: fac = ((s1 + isqrt(disc)) // 2, (s1 - isqrt(disc)) // 2)
        # also (x^2 - a x - p^5)(x^2 - b x - p^5)? : a+b = s1, ab - 2p^5 = s2, and -p^5(a+b)... sign check
        print(f'p={p:3d} eps={eps:2d}  s1={s1:10d}  s2={s2:16d}  Weil dev={weil:.2e}  disc={disc}  factor a,b={fac}')
