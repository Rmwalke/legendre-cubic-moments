"""H18 — explore: are s1, s2 (char poly of V) congruent mod small moduli to those of a sum of Tate twists
   T = p^{a} + p^{b} + p^{c} + p^{d}   (symplectic: pairs a+d = b+c = 5),  i.e. {a,b,c,d} = {0,5,1,4} or {0,5,2,3} or {1,4,2,3} ...
 s1 ≡ e1(T), s2 ≡ e2(T)  (mod m)  for every split p in the data?  m in 2^k, 3^k.  Exploratory; reports largest m that works.
Usage: python -I H18_...py H13_output_data.txt
"""
import sys, itertools
split = []
for line in open(sys.argv[1], encoding='utf-8'):
    if line.startswith('#') or not line.strip(): continue
    t = line.split()
    if t[1] == 'split': split.append((int(t[0]), int(t[2]), int(t[3])))
cands = {'{0,1,4,5}': (0, 1, 4, 5), '{0,2,3,5}': (0, 2, 3, 5), '{1,2,3,4}': (1, 2, 3, 4), '{0,0,5,5}': (0, 0, 5, 5),
         '{1,1,4,4}': (1, 1, 4, 4), '{2,2,3,3}': (2, 2, 3, 3)}
def e12(p, ex):
    v = [p ** e for e in ex]; e1 = sum(v); e2 = sum(v[i] * v[j] for i in range(4) for j in range(i + 1, 4)); return e1, e2
for name, ex in cands.items():
    best = {}
    for base in (2, 3, 5, 7):
        k = 0
        while k < 12:
            m = base ** (k + 1)
            if all((s1 - e12(p, ex)[0]) % m == 0 for p, s1, s2 in split): k += 1
            else: break
        k2 = 0
        while k2 < 12:
            m = base ** (k2 + 1)
            if all((s2 - e12(p, ex)[1]) % m == 0 for p, s1, s2 in split): k2 += 1
            else: break
        best[base] = (k, k2)
    print(f'{name}: s1 ≡ e1 mod base^k1, s2 ≡ e2 mod base^k2  ->', {b: f'2^{v[0]},{v[1]}'.replace('2^', f'{b}^') for b, v in best.items()})
