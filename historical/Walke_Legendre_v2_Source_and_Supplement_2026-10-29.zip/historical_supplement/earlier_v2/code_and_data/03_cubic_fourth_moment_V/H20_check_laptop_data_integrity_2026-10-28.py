"""H20 — consistency check of integer-valued laptop H13 data derived from rounded FFTs.  PASS/FAIL fixed before running:
 (a) split p: t2(p) == a_f(p), f = 36.4.a.a (eta-quotient, exact) ;  inert p: t2(p^2) == a_f(p)^2 - 2 p^3
 (b) p <= 67: (s1, s2) equal to exact direct values (H9)
 (c) Weil: all roots of x^4 - s1 x^3 + s2 x^2 - p^5 s1 x + p^10 on |x| = p^{5/2}  (checked via y = x + p^5/x real in [-2p^{5/2}, 2p^{5/2}])
 (d) inert: |u| <= 4 p^5
 PASS = no exception in (a)-(d).
Usage: python -I H20_...py data.txt
"""
import sys, math
data = [l.split() for l in open(sys.argv[1], encoding='utf-8') if l.strip() and not l.startswith('#')]
PMAX = max(int(r[0]) for r in data); N = PMAX + 2
def prod_pow(m, e):
    P = [0] * (N + 1); P[0] = 1
    if e >= 0:
        for n in range(1, N // m + 1):
            for _ in range(e):
                for i in range(N, m * n - 1, -1): P[i] -= P[i - m * n]
    else:
        for n in range(1, N // m + 1):
            for _ in range(-e):
                for i in range(m * n, N + 1): P[i] += P[i - m * n]
    return P
def mul(A, B):
    C = [0] * (N + 1)
    for i, x in enumerate(A):
        if x:
            for j in range(N + 1 - i):
                if B[j]: C[i + j] += x * B[j]
    return C
def eta_q(spec):
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec: P = mul(P, prod_pow(m, e))
    s = sum(m * e for m, e in spec) // 24
    return ([0] * s + P)[:N + 1]
F1 = eta_q([(6, 14), (2, -3), (18, -3)]); F2 = eta_q([(2, 3), (6, 2), (18, 3)])
f = [x - 3 * y for x, y in zip(F1, F2)]
EXACT = {7: (-32, -12786), 13: (28, 113790), 19: (-2504, 4136790), 31: (-272, 13560126),
         37: (2284, 46569486), 43: (4168, -58885050), 61: (-16484, 617583198), 67: (1144, 1689885750)}
bad = {'a': [], 'b': [], 'c': [], 'd': []}
for r in data:
    p = int(r[0])
    if r[1] == 'split':
        s1, s2, t2 = int(r[2]), int(r[3]), int(r[4])
        if t2 != f[p]: bad['a'].append(p)
        if p in EXACT and (s1, s2) != EXACT[p]: bad['b'].append(p)
        P5 = p ** 5; disc = s1 * s1 - 4 * (s2 - 2 * P5)       # y-roots
        if disc < 0: bad['c'].append(p); continue
        # Exact equivalent of |s1|+sqrt(disc) <= 4*sqrt(p**5).
        A = 16 * P5 - s1 * s1 - disc
        if A < 0 or A * A < 4 * s1 * s1 * disc:
            bad['c'].append(p)
    else:
        u, t2 = int(r[2]), int(r[3])
        if t2 != f[p] ** 2 - 2 * p ** 3: bad['a'].append(p)
        if abs(u) > 4 * p ** 5: bad['d'].append(p)
ns = sum(1 for r in data if r[1] == 'split'); ni = len(data) - ns
print(f'{ns} split, {ni} inert primes; max p = {PMAX}')
for k, v in bad.items(): print(f'  ({k}) failures: {v[:10]} ({len(v)})')
print('INTEGRITY:', 'PASS' if not any(bad.values()) else 'FAIL')

print('The inequalities are exact; this does not certify every FFT-derived input.')
if any(bad.values()):
    raise SystemExit(1)
