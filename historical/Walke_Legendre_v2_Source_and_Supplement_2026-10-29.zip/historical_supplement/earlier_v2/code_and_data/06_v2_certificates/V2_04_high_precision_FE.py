"""Decimal re-evaluation of the supplied candidate L-function (not a proof).

Run: python V2_04_high_precision_FE.py /path/to/code_and_data [decimal_precision]
Uses the author's rounded Euler data, but builds Dirichlet coefficients as
Python integers and evaluates K0/K1 independently using DLMF 10.31.2.
The supplied dataset is not certified by this calculation. There is no
interval enclosure or rigorous tail certificate in this script.
Requirements: numpy, scipy (only for loading the author's Euler-factor code).
"""
from decimal import Decimal as D, getcontext
from pathlib import Path
import contextlib
import io
import json
import math
import os
import sys
import time


def arctan(x, eps):
    term, total, k = x, x, 1
    xx = x*x
    while True:
        term *= -xx
        add = term / (2*k+1)
        total += add
        if abs(add) < eps:
            return total
        k += 1


def positive_series(z, eps):
    """I0(z), I1(z), sum H_k a_k, and its derivative; a_k=(z/2)^(2k)/(k!)^2."""
    u = z*z/4
    term = D(1)
    i0, i1, sh, dh, harmonic = D(1), D(0), D(0), D(0), D(0)
    k = 1
    while True:
        term *= u / (k*k)
        harmonic += D(1)/k
        deriv = term * (2*k) / z
        i0 += term
        i1 += deriv
        sh += harmonic*term
        dh += harmonic*deriv
        if k > z and term < eps:
            return i0, i1, sh, dh
        k += 1


def constants(precision):
    eps = D(10) ** (-(precision+10))
    pi = 16*arctan(D(1)/5, eps) - 4*arctan(D(1)/239, eps)
    # At z=400, omitted K0(z)/I0(z) is about pi*exp(-800), < 1e-346.
    # Consequently this gamma construction is suitable for <= 280 digits.
    i0, _, sh, _ = positive_series(D(400), eps)
    gamma = sh/i0-D(200).ln()
    return pi, gamma, eps


def k01(z, gamma, eps):
    i0, i1, sh, dh = positive_series(z, eps)
    a = (z/2).ln()+gamma
    return sh-a*i0, i0/z+a*i1-dh


def load_coefficients(root):
    folder = root/'04_descent_and_L_function'
    data = root/'05_runner_laptop_p_upto_4999/H13_output_data_laptop_p_upto_4999.txt'
    src = (folder/'L2_explore_LW_functional_equation_FLOAT_2026-10-28.py').read_text().split('ts = [1.05')[0]
    # The corrected L2 API explicitly exposes exact integer coefficients.
    oldcwd, oldargv = os.getcwd(), sys.argv
    ns = {'__name__': 'author_definitions'}
    try:
        os.chdir(folder)
        sys.argv = ['review', str(data)]
        with contextlib.redirect_stdout(io.StringIO()):
            exec(compile(src, '<author-L2-integer-coefficients>', 'exec'), ns)
        return ns['coeffs'](-1, as_float=False)
    finally:
        os.chdir(oldcwd)
        sys.argv = oldargv


def main(root, precision):
    assert 170 <= precision <= 280
    getcontext().prec = precision
    pi, gamma, eps = constants(precision)
    coeff = load_coefficients(root)
    nonzero = [(n, D(a)) for n, a in enumerate(coeff) if a]
    def theta(t):
        v = D(0)
        for n, a in nonzero:
            z = 4*pi*(D(n)*t/36).sqrt()
            v += 2*a*k01(z, gamma, eps)[0]
        return v
    start = time.monotonic()
    print('Decimal precision:', precision, '; n_max:', len(coeff)-1, '; nonzero coefficients:', len(nonzero), flush=True)
    print('gamma:', str(gamma)[:60], flush=True)
    out = {'precision': precision, 'n_max': len(coeff)-1, 'defects': {}}
    for s in ('1.1', '1.3', '2'):
        t = D(s)
        a, b = theta(1/t), t**6*theta(t)
        defect = abs(a-b)/(abs(a)+abs(b))
        out['defects'][s] = str(defect)
        print('t=', s, 'defect=', f'{defect:.20E}', flush=True)
    # Analytic evaluation of the central-value kernel:
    # integral_z^infty x^5 K0(x) dx = z^5 K1(z)+4z^4 K2(z)+8z^3 K3(z).
    lam3 = D(0)
    for n, a in nonzero:
        z = 4*pi*(D(n)/36).sqrt()
        k0, k1 = k01(z, gamma, eps)
        k2 = k0+2*k1/z
        k3 = k1+4*k2/z
        lam3 += 8*a*(k1/z+4*k2/z**2+8*k3/z**3)
    L3 = lam3 / (D(1296)**D('1.5') * (2*pi)**(-6) * 4)
    out['L3'] = str(L3)
    print('Conditional central value:', str(L3)[:70], flush=True)
    print('Seconds:', round(time.monotonic()-start, 2), flush=True)
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve(), int(sys.argv[2]) if len(sys.argv)>2 else 220)
