"""Check the corrected normalization in original Section 4.3.

G = M_{3,2}+1 = -J(rho,phi*rhobar)^2 H_p(A;1), with Grove Eq. (1.1).
The proof is an exact comparison of denominators; these FLOAT tests detect
implementation/sign mistakes and are not exact Gauss-sum certificates.
Run: python -I V2_02_hypergeometric_normalization_FLOAT.py [PMAX=250]
"""
import cmath
import math
import sys

maxp=int(sys.argv[1]) if len(sys.argv)>1 else 250
errors=[];unscaled=[]
for p in range(7,maxp+1):
    if p%3!=1 or any(p%d==0 for d in range(2,math.isqrt(p)+1)):
        continue
    n=p-1
    factors=[d for d in range(2,n+1) if n%d==0 and all(d%e for e in range(2,math.isqrt(d)+1))]
    g=next(a for a in range(2,p) if all(pow(a,n//d,p)!=1 for d in factors))
    ind={pow(g,e,p):e for e in range(n)}
    def char(k,x):
        return 0 if x%p==0 else cmath.exp(2j*math.pi*(k*ind[x%p]%n)/n)
    gauss=[sum(char(k,x)*cmath.exp(2j*math.pi*x/p) for x in range(1,p)) for k in range(n)]
    gs=lambda k:gauss[k%n]
    h=n//2;r=n//3
    c=lambda k:gs(h+k)**2*gs(-k)**2/gs(h)**2
    G=sum(c(k)*c(-r-k) for k in range(n))/(p-1)
    denominator=gs(h)**2*gs(r)**2*gs(0)**2*gs(h-r)**2
    HA=sum(gs(h+k)**2*gs(r+k)**2*gs(-k)**2*gs(h-r-k)**2 for k in range(n))/((1-p)*denominator)
    J=sum(char(r,x)*char(h-r,1-x) for x in range(p))
    chi=[0]+[-1]*(p-1)
    for x in range(1,p):
        chi[x*x%p]=1
    S=[0,0,0]
    for lam in range(2,p):
        tr=-sum(chi[x*(x-1)*(x-lam)%p] for x in range(p))
        S[ind[lam]%3]+=tr*tr
    assert S[1]==S[2]
    M=S[0]-S[1]
    err=max(abs(G+J*J*HA),abs(G-(M+1)))
    assert err<1e-6,(p,err)
    errors.append(err);unscaled.append(abs(G-HA))
    if p<=31:
        print(f'p={p}, G={M+1}, H_A={HA}, J^2={J*J}, corrected error={err:.3e}')
print(f'{len(errors)} split primes <= {maxp}; max corrected error={max(errors):.3e}: PASS')
print(f'Unscaled equality G=H_A fails: min observed error={min(unscaled):.3e}')
