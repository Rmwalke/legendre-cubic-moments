"""Focused regressions for the corrected validators and square-class logic.
Run: python -I V2_03_regressions.py
Does not perform the expensive full H13 run or modify its stored data.
"""
from pathlib import Path
import ast
import importlib.util
import math
import subprocess
import sys
import tempfile

BASE=Path(__file__).resolve().parents[1]


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


a=load('exact_arithmetic',Path(__file__).with_name('exact_arithmetic.py'))
h=load('h13',next(BASE.glob('05_*/H13_*.py')))

# These two quartics lie on opposite sides of the exact unit-circle condition.
assert a.old_weil(5,0,-6251)
assert not a.exact_weil(5,0,-6251)
assert a.exact_weil(5,0,-6250)
assert not a.exact_weil(5,0,6251)
# Products of two quadratics with integer traces strictly inside Hasse bounds.
for u in (-111,0,111):
    for v in (-111,0,111):
        assert a.exact_weil(5,u+v,u*v+2*5**5)
assert a.exact_weil(7,-32,-12786)
assert a.exact_weil(13,28,113790)

# Exercise the production H20 script on synthetic rows on either side of the
# boundary; this catches a regression even if the reference helper is correct.
h20=next(BASE.glob('03_*/H20_*.py'))
with tempfile.TemporaryDirectory() as td:
    data=Path(td)/'synthetic.txt'
    for c2,valid in ((-6250,True),(-6251,False)):
        data.write_text(f'5 split 0 {c2} 18 0 1\n')
        result=subprocess.run([sys.executable,'-I',str(h20),str(data)],
                              capture_output=True,text=True)
        assert (result.returncode==0)==valid, result.stdout+result.stderr
        expected='(c) failures: [] (0)' if valid else '(c) failures: [5] (1)'
        assert expected in result.stdout, result.stdout

# Load just the production L2 validator, without triggering its full FE search.
l2=next(BASE.glob('04_*/L2_*.py'))
tree=ast.parse(l2.read_text())
validator=next(n for n in tree.body if isinstance(n,ast.FunctionDef)
               and n.name=='exact_weil_multiplier')
namespace={}
exec(compile(ast.Module(body=[validator],type_ignores=[]),str(l2),'exec'),namespace)
actual=namespace['exact_weil_multiplier']
for sign in (-1,1):
    assert actual(5,0,-6250,sign)
    assert actual(5,0,6250,sign)
    assert not actual(5,0,-6251,sign)
    assert not actual(5,0,6251,sign)
assert not actual(5,1,0,-1)
assert actual(7,-32,-12786,1)

# A square beyond the old trial-division cutoff must not change square class.
assert h.same_square_class(2,2*10007**2)
assert not h.same_square_class(2,3)
assert not h.same_square_class(2,-2)
assert not h.same_square_class(2515968,9531648)
assert len(h.square_class_representatives([2,2*10007**2,3]))==2

# The stronger rational-2-torsion check remains satisfied by small FFT runs.
for p in (7,13,19):
    row=h.do_prime(p)
    assert (row['s1'],row['s2'])==h.EXACT[p]

# Regenerate the full report from the historical table, without recomputing or
# overwriting it. This checks the changed reporting path and exact class count.
source=next(BASE.glob('05_*/H13_output_data_laptop*.txt'))
rows={}
for line in source.read_text().splitlines():
    if not line.strip() or line.startswith('#'):
        continue
    t=line.split();p=int(t[0])
    if t[1]=='split':
        s1,s2,t2=map(int,t[2:5]);D=s1*s1-4*(s2-2*p**5)
        rows[p]=dict(p=p,type='split',s1=s1,s2=s2,t2=t2,D=D,
                     Dsq=D>=0 and math.isqrt(D)**2==D)
    else:
        rows[p]=dict(p=p,type='inert',u=int(t[2]),t2_p2=int(t[3]))
with tempfile.TemporaryDirectory() as td:
    h.OUT_DATA=str(Path(td)/'report_data.txt')
    h.OUT_SUM=str(Path(td)/'report_summary.txt')
    h.write_reports(rows,'v2 regression; historical FFT inputs')
    report=Path(h.OUT_SUM).read_text()
    assert '330' in report and '337' in report
    assert 'do not prove general irreducibility' in report
    assert 'partial_square_reduction(D)' in Path(h.OUT_DATA).read_text()
    if len(sys.argv)>1:
        Path(sys.argv[1]).write_text(report)
print('Production Weil validators, exact square classes, small FFT checks, and full historical-data report: PASS')
