"""H27 (FLOAT for F_{p^2} moments, rounded integer outputs; see the v2 exact certificate) — Livné test set using SPLIT primes only, with determinant check.
 For each split p (p ≡ 1 mod 3) and each prime P | p (sqrt(-3) ≡ ±s0): Frobenius vector as in H26.
 W2 (2-dim, rho-part of H^1(Sym^2)): tr = t2(p) = -M2(p) - 1 - p ;  tr Frob^2 = t2(p^2) = -M2(p^2) - 1 - p^2
   det(Frob_P | W2) = (t2(p)^2 - t2(p^2)) / 2   — expected p^3 (= det rho_f|K, trivial nebentypus).
 PASS/FAIL (fixed before running): every T-prime has tr W2 = a_f(p) AND det = p^3; T covers all 7 nonzero vectors.
 Moments over F_p, F_{p^2}: functions of the H13 runner (FFT, rounded, asserted Hasse + parity).
Usage: python -I H27_...py [path/to/H13_run_one_click_V_data_LAPTOP_FLOAT_2026-10-27.py]
"""
import sys, importlib.util, math
H13_PATH = sys.argv[1] if len(sys.argv) > 1 else 'H13_run_one_click_V_data_LAPTOP_FLOAT_2026-10-27.py'
spec = importlib.util.spec_from_file_location('h13', H13_PATH)
h13 = importlib.util.module_from_spec(spec); spec.loader.exec_module(h13)
def leg(a, p): a %= p; return 0 if a == 0 else (1 if pow(a, (p - 1) // 2, p) == 1 else -1)
bit = lambda s: 0 if s == 1 else 1
N = 600
def eta_prod(spec_):
    lead = sum(m * e for m, e in spec_); s = lead // 24
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec_:
        for nn in range(1, N // m + 1):
            for _ in range(abs(e)):
                if e > 0:
                    for i in range(N, m * nn - 1, -1): P[i] -= P[i - m * nn]
                else:
                    for i in range(m * nn, N + 1): P[i] += P[i - m * nn]
    return ([0] * s + P)[:N + 1]
f = [x - 3 * y for x, y in zip(eta_prod([(6, 14), (2, -3), (18, -3)]), eta_prod([(2, 3), (6, 2), (18, 3)]))]
need = set(range(1, 8)); T = []
for p in range(7, N + 1):
    if not h13.is_prime(p) or p % 3 != 1: continue
    s0 = next(x for x in range(p) if (x * x + 3) % p == 0)
    vs = [bit(leg(-1, p)) | (bit(leg(2, p)) << 1) | (bit(leg(s, p)) << 2) for s in (s0, p - s0)]
    if not (set(vs) & need): continue
    m2, _ = h13.moments(p, 1); m2b, _ = h13.moments(p, 2)
    t2 = -m2 - 1 - p; t2b = -m2b - 1 - p * p; det = (t2 * t2 - t2b) // 2
    for v in vs:
        if v in need:
            need.discard(v); T.append((p, format(v, '03b'), t2, f[p], det, p ** 3))
    if not need: break
print('vectors not reached:', sorted(need))
ok = True
for p, v, t2, af, det, p3 in T:
    good = (t2 == af) and (det == p3); ok &= good
    print(f'  P|{p:4d}  vec(sqrt s,2,-1)={v}  tr W2={t2:6d}  a_f={af:6d}  det={det}  p^3={p3}  {"OK" if good else "MISMATCH"}')
print('Livné conditions on T (trace + det):', 'PASS' if ok and not need else 'FAIL / incomplete')
