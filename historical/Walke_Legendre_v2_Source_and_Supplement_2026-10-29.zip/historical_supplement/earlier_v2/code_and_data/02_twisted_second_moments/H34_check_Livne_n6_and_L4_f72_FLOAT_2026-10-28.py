"""H34 (FLOAT for F_{p^2} moments; rounded integer outputs; see the v2 exact certificate) — n = 6: L4 for f = 72.4.a.b and Livné test over K = Q(sqrt(-3)).
 f coefficients: a_2 = a_3 = 0 (4 | 72, 9 | 72, trivial character); a_5 = -14 (H33: BCM sum + LTYZ, validated at p=5
 on n=2,3); a_p (p >= 7) from the LTYZ supercongruence (H24); prime powers by a_{p^{k+1}} = a_p a_{p^k} - p^3 a_{p^{k-1}};
 multiplicative.
 L4: f ≡ eta(3z)^8 (mod 2) checked for n <= 48 = Sturm bound of Gamma_0(72) in weight 4 (index 144).
 Livné: same K, S, T as n = 3 (primes above 7, 7', 13, 19, 19', 37, 73).  W2 for psi_6 (order 6):
   tr = -M - 1 - q,  M = Re sum psi_6(l) a(l)^2 = S0 + S1 - S2 - S3 (S1=S5, S2=S4 asserted);  det = (t^2 - t(p^2))/2.
 PASS/FAIL fixed before running: Sturm congruence for n <= 48; on T: tr = a_f(p) and det = p^3.
Usage: python -I H34_...py path/to/H13_run_one_click_V_data_LAPTOP_FLOAT_2026-10-27.py
"""
import sys, importlib.util, math
from fractions import Fraction as Fr
import numpy as np
spec = importlib.util.spec_from_file_location('h13', sys.argv[1]); h13 = importlib.util.module_from_spec(spec); spec.loader.exec_module(h13)
NB = 200
def ltyz_ap(p, r):
    m = p ** 3; a = [Fr(1, 2), Fr(1, 2), r, 1 - r]; tot, term = 0, 1
    for k in range(p):
        tot = (tot + term) % m
        if k == p - 1: break
        num, den = 1, 1
        for x in a:
            v = k + x; num = num * v.numerator % m; den = den * v.denominator % m
        den = den * pow(k + 1, 4, m) % m; term = term * num % m * pow(den, -1, m) % m
    t = tot % m; return t - m if t > m // 2 else t
ap = {2: 0, 3: 0, 5: -14}
for p in range(7, NB + 1):
    if h13.is_prime(p): ap[p] = ltyz_ap(p, Fr(1, 6))
def a_pk(p, k):
    if p in (2, 3): return 1 if k == 0 else 0
    prev, cur = 1, ap[p]
    if k == 0: return 1
    for _ in range(k - 1): prev, cur = cur, ap[p] * cur - p ** 3 * prev
    return cur
def a_n(n):
    r, d = 1, 2
    while n > 1:
        if n % d == 0:
            k = 0
            while n % d == 0: n //= d; k += 1
            r *= a_pk(d, k)
        d += 1
    return r
f = [0] + [a_n(n) for n in range(1, NB + 1)]
print('72.4.a.b q-exp:', {n: f[n] for n in range(1, 30) if f[n]})
N = NB
def eta_prod(spec_):
    lead = sum(m * e for m, e in spec_); s = lead // 24
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec_:
        for nn in range(1, N // m + 1):
            for _ in range(abs(e)):
                if e > 0:
                    for i in range(N, m * nn - 1, -1): P[i] -= P[i - m * nn]
                else:
                    for i in range(m * nn, N + 1): P[i] += P[i - m * nn]
    return ([0] * s + P)[:N + 1]
g = eta_prod([(3, 8)])
sturm = all((f[n] - g[n]) % 2 == 0 for n in range(0, 49))
print('L4: f ≡ eta(3z)^8 mod 2 for n <= 48 (Sturm, Gamma_0(72), weight 4):', 'PASS' if sturm else 'FAIL',
      '| mismatches n<=200:', [n for n in range(1, NB + 1) if (f[n] - g[n]) % 2][:8])

def leg(a, p): a %= p; return 0 if a == 0 else (1 if pow(a, (p - 1) // 2, p) == 1 else -1)
bit = lambda s: 0 if s == 1 else 1
def sext_moment(p, deg):
    chi = h13.chi_table(p); g0 = h13.prim_root(p); ind = np.zeros(p, dtype=np.int64); v = 1
    for e in range(p - 1): ind[v] = e; v = v * g0 % p
    if deg == 1:
        X = np.arange(p); cq = chi[X]; ff = cq * chi[(X - 1) % p]
        a = -np.rint(np.fft.ifft(np.fft.fft(ff) * np.conj(np.fft.fft(cq))).real).astype(np.int64)
        cls = ind % 6; excl = [0, 1]; q = p
    else:
        nr = next(x for x in range(2, p) if chi[x] == -1)
        A, B = np.meshgrid(np.arange(p, dtype=np.int64), np.arange(p, dtype=np.int64), indexing='ij')
        Nn = (A * A - nr * B * B) % p; N1 = ((A - 1) ** 2 - nr * B * B) % p
        cq = chi[Nn].astype(float); ff = cq * chi[N1]
        a = -np.rint(np.fft.ifft2(np.fft.fft2(ff) * np.conj(np.fft.fft2(cq))).real).astype(np.int64).ravel()
        cls = (ind % 6)[Nn.ravel()]; excl = [0, p]; q = p * p
    mask = np.ones(q, bool); mask[excl] = False
    am, cm = a[mask], cls[mask]
    assert np.all(np.abs(am) <= 2 * math.sqrt(q) + 1e-9) and np.all(am % 2 == 0)
    S = [int((am[cm == j].astype(object) ** 2).sum()) for j in range(6)]
    assert S[1] == S[5] and S[2] == S[4]
    return S[0] + S[1] - S[2] - S[3]
Tp = [7, 13, 19, 37, 73]; ok = sturm
for p in Tp:
    M1 = sext_moment(p, 1); M2 = sext_moment(p, 2)
    t = -M1 - 1 - p; t2 = -M2 - 1 - p * p; det = (t * t - t2) // 2
    good = t == f[p] and det == p ** 3; ok &= good
    print(f'  P|{p:3d}: tr W2 = {t:6d}  a_f(p) = {f[p]:6d}  det = {det}  p^3 = {p ** 3}  {"OK" if good else "MISMATCH"}')
print('Livné (n=6) on T (vectors as in H27):', 'PASS' if ok else 'FAIL')
