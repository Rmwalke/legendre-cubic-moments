"""H31 LEGACY THREE-VECTOR CHECK: the v2 proof route uses the seven-vector
 exact certificate in 06_v2_certificates/V2_01_exact_livne.py with S={2,3}.
 H31 (FLOAT for F_{p^2} moments; rounded integer outputs) — Livné route for n = 4 (quartic twist), K = Q(i), S = {(1+i)}.
 Claim: tr(Frob_P | W2,psi) = a_f(p),  f = 16.4.a.a = eta(4z)^16 / (eta(2z)^4 eta(8z)^4),  P | p ≡ 1 (mod 4).
   tr W2 = -M - 1 - q,  M = Re sum_{l != 0,1} psi(l) a(l)^2  (psi quartic; S1 = S3 => M = S0 - S2).
 Finite parity-support check; the global parity proof uses the eta-product identity, not this test alone.
 S-units of Q(i) mod squares: <i, 1+i>  (-1 = i^2)  => r = 2; Frobenius vector at P = (pi), residue F_p, i -> i0:
   e(i) = Legendre(i0, p), e(1+i) = Legendre(1 + i0, p).  T = split primes covering the 3 nonzero vectors.
 Legacy finite check: on its three-vector T, trace and determinant agree; parity support agrees with odd squares through N=400.
Usage: python -I H31_...py path/to/H13_run_one_click_V_data_LAPTOP_FLOAT_2026-10-27.py
"""
import sys, importlib.util, math
import numpy as np
spec = importlib.util.spec_from_file_location('h13', sys.argv[1]); h13 = importlib.util.module_from_spec(spec); spec.loader.exec_module(h13)
N = 400
def eta_prod(spec_):
    lead = sum(m * e for m, e in spec_); s = lead // 24
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec_:
        for nn in range(1, N // m + 1):
            for _ in range(abs(e)):
                if e > 0:
                    for i in range(N, m * nn - 1, -1): P[i] -= P[i - m * nn]
                else:
                    for i in range(m * nn, N + 1): P[i] += P[i - m * nn]
    return ([0] * s + P)[:N + 1]
f = eta_prod([(4, 16), (2, -4), (8, -4)])
a8 = eta_prod([(2, 4), (4, 4)])
print('f = 16.4.a.a: ', {n: f[n] for n in range(1, 30) if f[n]})
odd = [n for n in range(1, N + 1) if f[n] % 2]
print('n<=400 with f(n) odd:', odd[:12], '... all squares:', all(math.isqrt(n) ** 2 == n for n in odd))
sq_odd = [n for n in range(1, N + 1) if n % 2 and math.isqrt(n) ** 2 == n]
parity_ok = odd == sq_odd
print('odd-coefficient support == odd squares (n<=400):', parity_ok)
def leg(a, p): a %= p; return 0 if a == 0 else (1 if pow(a, (p - 1) // 2, p) == 1 else -1)
bit = lambda s: 0 if s == 1 else 1

def quartic_moment(p, deg):
    chi = h13.chi_table(p); ind_p = None
    g0 = h13.prim_root(p); ind = np.zeros(p, dtype=np.int64); v = 1
    for e in range(p - 1): ind[v] = e; v = v * g0 % p
    if deg == 1:
        X = np.arange(p); cq = chi[X]; ff = cq * chi[(X - 1) % p]
        a = -np.rint(np.fft.ifft(np.fft.fft(ff) * np.conj(np.fft.fft(cq))).real).astype(np.int64)
        cls = ind % 4; excl = [0, 1]; q = p
    else:
        nr = next(x for x in range(2, p) if chi[x] == -1)
        A, B = np.meshgrid(np.arange(p, dtype=np.int64), np.arange(p, dtype=np.int64), indexing='ij')
        Nn = (A * A - nr * B * B) % p; N1 = ((A - 1) ** 2 - nr * B * B) % p
        cq = chi[Nn].astype(float); ff = cq * chi[N1]
        a = -np.rint(np.fft.ifft2(np.fft.fft2(ff) * np.conj(np.fft.fft2(cq))).real).astype(np.int64).ravel()
        cls = (ind % 4)[Nn.ravel()]; excl = [0, p]; q = p * p
    mask = np.ones(q, bool); mask[excl] = False
    am, cm = a[mask], cls[mask]
    assert np.all(np.abs(am) <= 2 * math.sqrt(q) + 1e-9) and np.all(am % 2 == 0)
    S = [int((am[cm == j].astype(object) ** 2).sum()) for j in range(4)]
    assert S[1] == S[3]
    return S[0] - S[2]

need = {1, 2, 3}; T = []
for p in range(5, N + 1):
    if not h13.is_prime(p) or p % 4 != 1: continue
    i0 = next(x for x in range(p) if (x * x + 1) % p == 0)
    vs = [bit(leg(r, p)) | (bit(leg(1 + r, p)) << 1) for r in (i0, p - i0)]
    if not (set(vs) & need): continue
    M1 = quartic_moment(p, 1); M2 = quartic_moment(p, 2)
    t = -M1 - 1 - p; t2 = -M2 - 1 - p * p; det = (t * t - t2) // 2
    for v in vs:
        if v in need: need.discard(v); T.append((p, format(v, '02b'), t, f[p], a8[p], det, p ** 3))
    if not need: break
ok = not need and parity_ok
for p, v, t, af, a8p, det, p3 in T:
    good = t == af and det == p3; ok &= good
    print(f'  P|{p:3d} vec(1+i, i)={v}  tr W2={t:6d}  a_16(p)={af:6d}  (a_8(p)={a8p})  det={det} p^3={p3}  {"OK" if good else "MISMATCH"}')
print('Livné (n=4) on T:', 'PASS' if ok else 'FAIL / incomplete')
