"""H2 — explore: cubic-twisted moments M_{3,k}(p) = sum_{l=2}^{p-1} rho(l) a(l)^k, p ≡ 1 mod 3.
(1) check identity M_{4,k} = T_k (quartic = quadratic) on p ≡ 1 mod 4;
(2) exact rational least-squares fit of M_{3,k} on basis {p^j} ∪ {Re J^t, p^j Re J^t},
    J = J(rho,rho) normalised primary (J ≡ -1 mod 3 in Z[w]); fit on half the primes, test on the rest.
Usage: python -I H2_...py PMAX K
"""
import sys
from fractions import Fraction as Fr
sys.path.insert(0, '.')
import importlib.util
spec = importlib.util.spec_from_file_location('h1', 'H1_explore_order_n_twisted_moments_2026-10-27.py')
h1 = importlib.util.module_from_spec(spec); spec.loader.exec_module(h1)

PMAX = int(sys.argv[1]); K = int(sys.argv[2])

def jacobi_cubic(p):
    """J(rho,rho) = sum_x rho(x) rho(1-x) as (u,v) meaning u + v*w, w = e^{2pi i/3}."""
    g = h1.prim_root(p); ind = [0] * p; v = 1
    for e in range(p - 1): ind[v] = e; v = v * g % p
    cnt = [0, 0, 0]
    for x in range(2, p): cnt[(ind[x] + ind[(1 - x) % p]) % 3] += 1
    # sum cnt[j] w^j, w^2 = -1 - w
    u, vv = cnt[0] - cnt[2], cnt[1] - cnt[2]
    # make primary: multiply by unit so that u+v w ≡ -1 mod 3  (units: ±1, ±w, ±w^2)
    def mulw(a, b): return (-b, a - b)          # (a + b w) * w
    cands = []
    z = (u, vv)
    for _ in range(3):
        for s in (1, -1):
            a, b = s * z[0], s * z[1]
            if (a + 1) % 3 == 0 and b % 3 == 0: cands.append((a, b))
        z = mulw(*z)
    return cands[0]

def re_pow(z, t):  # real part of (a + b w)^t ; returns Fraction
    a, b = z; ra, rb = 1, 0
    for _ in range(t):
        ra, rb = ra * a - rb * b, ra * b + rb * a - rb * b
    return Fr(2 * ra - rb, 2)  # Re(x + y w) = x - y/2

def solve(A, y):
    """exact least squares via normal equations (Fractions)."""
    n = len(A[0]); M = [[sum(A[r][i] * A[r][j] for r in range(len(A))) for j in range(n)] for i in range(n)]
    v = [sum(A[r][i] * y[r] for r in range(len(A))) for i in range(n)]
    for c in range(n):
        piv = next(r for r in range(c, n) if M[r][c] != 0)
        M[c], M[piv] = M[piv], M[c]; v[c], v[piv] = v[piv], v[c]
        for r in range(n):
            if r != c and M[r][c] != 0:
                f = M[r][c] / M[c][c]
                M[r] = [M[r][j] - f * M[c][j] for j in range(n)]; v[r] -= f * v[c]
    return [v[i] / M[i][i] for i in range(n)]

rows, ys, ps, quart_bad = [], [], [], []
for p in h1.primes_upto(PMAX):
    if p < 5: continue
    tr = h1.traces(p)
    if p % 4 == 1:
        S4 = h1.class_sums(p, 4, K, tr); S2 = h1.class_sums(p, 2, K, tr)
        if S4[0] - S4[2] != S2[0] - S2[1]: quart_bad.append(p)
    if p % 3 != 1: continue
    S = h1.class_sums(p, 3, K, tr); M = S[0] - S[1]
    J = jacobi_cubic(p)
    basis = [Fr(p) ** j for j in range(0, K // 2 + 2)]
    for t in range(1, K + 2):
        for j in range(0, K // 2 + 1):
            if t + 2 * j <= K + 2: basis.append(Fr(p) ** j * re_pow(J, t))
    rows.append(basis); ys.append(Fr(M)); ps.append(p)
print('quartic identity M_{4,k}=T_k failures:', quart_bad, '(tested p≡1 mod 4 up to', PMAX, ')')
nb = len(rows[0]); half = max(nb + 5, len(rows) // 2)
coef = solve(rows[:half], ys[:half])
res = [ys[i] - sum(c * x for c, x in zip(coef, rows[i])) for i in range(len(rows))]
print('basis size', nb, '; fit primes', half, '; test primes', len(rows) - half)
print('coefficients:', [str(c) for c in coef])
bad = [(ps[i], str(res[i])) for i in range(len(rows)) if res[i] != 0]
print('nonzero residuals:', len(bad), bad[:8])
