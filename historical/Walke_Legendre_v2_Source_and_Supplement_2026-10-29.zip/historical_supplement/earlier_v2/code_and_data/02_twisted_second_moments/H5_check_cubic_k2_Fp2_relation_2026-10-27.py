"""H5 — check: cubic-twisted 2nd moment over F_p and F_{p^2}.
 Predicted from Euler characteristic (H1 notes): M(q)+1 = -t(q) - c^q-part, t 2-dim weight 3.
 Test for split p (p ≡ 1 mod 3) and c in {-1,0,1}:
   R_c(p) := [M(p^2)+1] + c^2 p^2 + ( (M(p)+1+c p)^2 - 2 p^3 )  == 0 ?
 M(q) = sum_{l in F_q, l != 0,1} rho(l) a_q(l)^2, rho cubic char of F_q (real-valued sum: S0 - S1).
 PASS/FAIL fixed before running: a value of c is accepted only if R_c = 0 for every tested p.
Usage: python -I H5_...py PMAX
"""
import sys
import numpy as np
PMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 40

def is_prime(n): return n > 1 and all(n % d for d in range(2, int(n ** .5) + 1))

def field(p, deg):
    """elements as ints: deg 1 -> 0..p-1 ; deg 2 -> a + b p with i^2 = nr (non-residue)."""
    q = p ** deg
    if deg == 1:
        add = (np.arange(q)[:, None] + np.arange(q)[None, :]) % p
        mul = (np.arange(q)[:, None] * np.arange(q)[None, :]) % p
        return q, add, mul
    nr = next(x for x in range(2, p) if pow(x, (p - 1) // 2, p) == p - 1)
    A = np.arange(q) % p; B = np.arange(q) // p
    a1, b1 = A[:, None], B[:, None]; a2, b2 = A[None, :], B[None, :]
    add = (a1 + a2) % p + p * ((b1 + b2) % p)
    mul = (a1 * a2 + nr * b1 * b2) % p + p * ((a1 * b2 + a2 * b1) % p)
    return q, add, mul

def M_cubic(p, deg):
    q, add, mul = field(p, deg)
    one = 1; neg1 = add[0].tolist().index(0)  # placeholder
    neg = np.array([int(np.where(add[x] == 0)[0][0]) for x in range(q)])
    # generator of F_q^*
    for g in range(2, q):
        v, seen = 1, 0
        for e in range(1, q):
            v = mul[v, g]
            if v == 1: break
        if e == q - 1: break
    ind = np.zeros(q, dtype=np.int64); v = 1
    for e in range(q - 1): ind[v] = e; v = mul[v, g]
    chi = np.where(ind % 2 == 0, 1, -1); chi[0] = 0
    xs = np.arange(q)
    base = mul[xs, add[xs, neg[1]]]                    # x(x-1)
    S = [0, 0, 0]
    for l in range(q):
        if l in (0, 1): continue
        a = -int(chi[mul[base, add[xs, neg[l]]]].sum())
        S[int(ind[l] % 3)] += a * a
    assert S[1] == S[2], (p, deg, S)
    return S[0] - S[1]

print(' p   M(p)    M(p^2)     R_-1/0/+1   t(p)=-(M+1)-cp for accepted c')
ok = {-1: True, 0: True, 1: True}; rows = []
for p in range(7, PMAX + 1):
    if not is_prime(p) or p % 3 != 1: continue
    m1, m2 = M_cubic(p, 1), M_cubic(p, 2)
    R = {c: (m2 + 1) + c * c * p * p + ((m1 + 1 + c * p) ** 2 - 2 * p ** 3) for c in (-1, 0, 1)}
    for c in R: ok[c] &= (R[c] == 0)
    rows.append((p, m1, m2)); print(p, m1, m2, R)
print('accepted c:', [c for c in ok if ok[c]])
for c in ok:
    if ok[c]: print('t(p) =', {p: -(m1 + 1) - c * p for p, m1, m2 in rows})
