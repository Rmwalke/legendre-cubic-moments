"""H33 (FLOAT: complex Gauss sums, results rounded to integers) — BCM finite hypergeometric sums for Q-defined data
   B_n = (1/2, 1/2, 1/n, 1-1/n ; 1,1,1,1), n = 2, 3, 6  (LTYZ forms 8.4.a.a, 36.4.a.a, 72.4.a.b).
 BCM (Beukers–Cohen–Mellit 2015): with prod_j (x^j - 1)^{gamma_j} = prod(x - e(alpha)) / prod(x - e(beta)),
   H_p(t) = 1/(1-p) * sum_{m=0}^{p-2} p^{s(0)-s(m)} * prod_j g(j m)^{gamma_j} * omega(eps * M^{-1} * t)^m,
   M = prod_j j^{j gamma_j},  g(m) = sum_x omega(x)^m zeta_p^x (omega = a generator character),  s(m) = #{beta_i = m/(p-1)}.
 NOTE: first run used p^{-s(0)+s(m)} -> |terms| ~ p^-6, no variant fit; corrected to p^{s(0)-s(m)} (|H| ~ p^{3/2}).
 Conventions (sign eps, M vs M^{-1}, omega vs omega^{-1}) are CALIBRATED: choose the variant for which
   H_p = a_f(p) + chi(p) p  holds at every prime 7 <= p <= 200 for all three data (a_f from eta for n=2,3,
   from the LTYZ supercongruence for n=6, H24).  PASS/FAIL fixed before running: exactly one variant modulo character conjugation fits all
   (else FAIL, no a_5 reported).  Then report a_f(5) = H_5 - chi(5)*5 for each n (n=2,3 known: -2, 18 = validation).
 gamma vectors:  n=2: Phi2^4/Phi1^4 = (x^2-1)^4/(x-1)^8          -> {2:4, 1:-8}
                 n=3: Phi2^2 Phi3/Phi1^4 = (x^2-1)^2 (x^3-1)/(x-1)^7 -> {2:2, 3:1, 1:-7}
                 n=6: Phi2^2 Phi6/Phi1^4 = (x^2-1)(x^6-1)/((x-1)^5 (x^3-1)) -> {2:1, 6:1, 1:-5, 3:-1}
 chi_alpha(p) (LTYZ Table 1): n=2: chi_1 (trivial) ; n=3: chi_3 = (p/3) ; n=6: chi_1.   [for p ≡ 1 mod 3 these are 1]
Usage: python -I H33_...py
"""
import cmath, itertools, math
from fractions import Fraction as Fr
def is_prime(n): return n > 1 and all(n % d for d in range(2, int(n ** .5) + 1))
def prim_root(p):
    fac = [d for d in range(2, p) if (p - 1) % d == 0 and is_prime(d)]
    return next(g for g in range(2, p) if all(pow(g, (p - 1) // f, p) != 1 for f in fac))
GAM = {2: {2: 4, 1: -8}, 3: {2: 2, 3: 1, 1: -7}, 6: {2: 1, 6: 1, 1: -5, 3: -1}}
def leg(a, p): a %= p; return 0 if a == 0 else (1 if pow(a, (p - 1) // 2, p) == 1 else -1)
CHI3 = 'm1'   # chi_alpha for n=3: candidates 'm1' = (-1/p), 'p3' = (3/p), 'm3' = (-3/p); chosen by calibration below
def chi_alpha(n, p):
    if n in (2, 6): return 1
    return {'m1': leg(-1, p), 'p3': leg(3, p), 'm3': leg(-3, p)}[CHI3]

def H(p, gam, eps, Minv, conj):
    g0 = prim_root(p); n = p - 1
    ind = {pow(g0, e, p): e for e in range(n)}
    zeta = cmath.exp(2j * math.pi / p)
    sgn = -1 if conj else 1
    gs = [sum(cmath.exp(sgn * 2j * math.pi * m * ind[x] / n) * zeta ** x for x in range(1, p)) for m in range(n)]
    M = Fr(1)
    for j, e in gam.items(): M *= Fr(j) ** (j * e)
    Mm = (M.denominator * pow(M.numerator, -1, p)) % p if Minv else (M.numerator * pow(M.denominator, -1, p)) % p
    arg = (eps * Mm) % p
    tot = 0
    for m in range(n):
        term = 1
        for j, e in gam.items(): term *= gs[(j * m) % n] ** e if gs[(j * m) % n] != 0 else 0
        sm = 4 if m == 0 else 0
        term *= p ** (4 - sm)   # q^{s(0)-s(m)} (sign fixed after magnitude check, see H33 notes)
        term *= cmath.exp(sgn * 2j * math.pi * m * ind[arg] / n)
        tot += term
    return tot / (1 - p)

# reference a_f(p)
N = 220
def eta_prod(spec):
    lead = sum(m * e for m, e in spec); s = lead // 24
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec:
        for nn in range(1, N // m + 1):
            for _ in range(abs(e)):
                if e > 0:
                    for i in range(N, m * nn - 1, -1): P[i] -= P[i - m * nn]
                else:
                    for i in range(m * nn, N + 1): P[i] += P[i - m * nn]
    return ([0] * s + P)[:N + 1]
a8 = eta_prod([(2, 4), (4, 4)])
f36 = [x - 3 * y for x, y in zip(eta_prod([(6, 14), (2, -3), (18, -3)]), eta_prod([(2, 3), (6, 2), (18, 3)]))]
def ltyz_ap(p, r):
    m = p ** 3; a = [Fr(1, 2), Fr(1, 2), r, 1 - r]; tot, term = 0, 1
    for k in range(p):
        tot = (tot + term) % m
        if k == p - 1: break
        num, den = 1, 1
        for x in a:
            v = k + x; num = num * v.numerator % m; den = den * v.denominator % m
        den = den * pow(k + 1, 4, m) % m; term = term * num % m * pow(den, -1, m) % m
    t = tot % m; return t - m if t > m // 2 else t
ref = {2: lambda p: a8[p], 3: lambda p: f36[p], 6: lambda p: ltyz_ap(p, Fr(1, 6))}
primes = [p for p in range(7, 201) if is_prime(p)]
for c in ('m1', 'p3', 'm3'):
    CHI3 = c
    ok3 = all(round(H(p, GAM[3], 1, True, False).real) == f36[p] + chi_alpha(3, p) * p for p in primes)
    print(f'n=3 chi_alpha candidate {c}: fits all 7<=p<=200: {ok3}')
    if ok3: break
good = []
for eps, Minv, conj in itertools.product((1, -1), (False, True), (False, True)):
    ok = True
    for n in (2, 3, 6):
        for p in primes:
            h = H(p, GAM[n], eps, Minv, conj)
            if abs(h.imag) > 1e-6 or round(h.real) != ref[n](p) + chi_alpha(n, p) * p: ok = False; break
        if not ok: break
    print(f'variant eps={eps:+d} Minv={Minv} conj={conj}: {"fits p<=" + str(primes[-1]) if ok else "no"}')
    if ok: good.append((eps, Minv, conj))
if len({(eps, Minv) for eps, Minv, conj in good}) == 1:
    v = good[0]
    full = all(round(H(p, GAM[n], *v).real) == ref[n](p) + chi_alpha(n, p) * p for n in (2, 3, 6) for p in primes)
    print(f'chosen variant {v}: all primes 7..200, n=2,3,6:', 'PASS' if full else 'FAIL')
    same = all(abs(H(5, GAM[n], *w) - H(5, GAM[n], *v)) < 1e-6 for w in good for n in (2, 3, 6))
    print('all fitting variants agree at p=5:', same)
    for n in (2, 3, 6):
        h5 = H(5, GAM[n], *v)
        print(f'n={n}: H_5 = {h5.real:.6f}{h5.imag:+.1e}i  ->  a_f(5) = H_5 - chi(5)*5 = {round(h5.real) - chi_alpha(n, 5) * 5}')
    print('validation: a_8(5) =', a8[5], ' a_36(5) =', f36[5])

else:
    raise RuntimeError('No unique normalization up to character conjugation')
