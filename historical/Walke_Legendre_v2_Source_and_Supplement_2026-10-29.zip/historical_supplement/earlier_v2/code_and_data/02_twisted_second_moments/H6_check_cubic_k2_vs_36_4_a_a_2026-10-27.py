"""H6 — check: t(p) := -M_{3,2}(p) - 1 - p  vs  a_f(p),  f = eta6^14/(eta2^3 eta18^3) - 3 eta2^3 eta6^2 eta18^3
(level 36 weight 4, the form attached to 4F3 datum (1/2,1/2,1/3,2/3) in Long–Tu–Yui–Zudilin, arXiv:1705.01663, Table 1).
PASS/FAIL fixed before running: PASS = exact equality t(p) = a_f(p) (or = -a_f(p), reported separately)
for every prime 7 <= p <= PMAX with p ≡ 1 mod 3. FAIL = any mismatch. Also reports p ≡ 2 mod 3 values.
eta_m^e  = q^{m e/24} prod (1-q^{mn})^e ; exponents combine to integer q-powers. Exact integers (power series with
negative eta exponents via series inversion of prod(1-q^n)).
Usage: python -I H6_...py PMAX
"""
import sys
from math import isqrt
import importlib.util
spec = importlib.util.spec_from_file_location('h1', 'H1_explore_order_n_twisted_moments_2026-10-27.py')
h1 = importlib.util.module_from_spec(spec); spec.loader.exec_module(h1)
PMAX = int(sys.argv[1]); N = PMAX + 2

def prod_pow(m, e):  # prod_n (1-q^{mn})^e for integer e (possibly negative), truncated at N
    P = [0] * (N + 1); P[0] = 1
    if e >= 0:
        for n in range(1, N // m + 1):
            for _ in range(e):
                for i in range(N, m * n - 1, -1): P[i] -= P[i - m * n]
    else:
        for n in range(1, N // m + 1):          # multiply by 1/(1-q^{mn}) = sum q^{mnk}
            for _ in range(-e):
                for i in range(m * n, N + 1): P[i] += P[i - m * n]
    return P
def mul(A, B):
    C = [0] * (N + 1)
    for i, x in enumerate(A):
        if x:
            for j in range(N + 1 - i): C[i + j] += x * B[j]
    return C
def eta_q(spec):
    lead = sum(m * e for m, e in spec); assert lead % 24 == 0
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec: P = mul(P, prod_pow(m, e))
    s = lead // 24
    return ([0] * s + P)[:N + 1]
F1 = eta_q([(6, 14), (2, -3), (18, -3)])
F2 = eta_q([(2, 3), (6, 2), (18, 3)])
f = [x - 3 * y for x, y in zip(F1, F2)]
print('f q-exp n<=25:', {n: f[n] for n in range(1, 26) if f[n]})
print('Hecke self-check f(25)=f(5)^2-5^3:', f[25] == f[5] ** 2 - 125, ' f(35)=f(5)f(7):', f[35] == f[5] * f[7] if N > 35 else '-')

def M3(p):
    tr = h1.traces(p); S = h1.class_sums(p, 3, 2, tr); assert S[1] == S[2]; return S[0] - S[1]
plus, minus, n = [], [], 0
for p in h1.primes_upto(PMAX):
    if p < 7 or p % 3 != 1: continue
    t = -M3(p) - 1 - p; n += 1
    if t != f[p]: plus.append(p)
    if t != -f[p]: minus.append(p)
    if p < 80: print(f'p={p:4d}  t(p)={t:7d}  a_f(p)={f[p]:7d}')
print(f'\n{n} primes p≡1 mod 3, 7<=p<={PMAX}:  t = a_f : ' + ('PASS' if not plus else f'FAIL at {plus[:6]}'),
      ' |  t = -a_f : ' + ('PASS' if not minus else f'FAIL at {minus[:6]}'))
