"""H15 (FLOAT) — check the paper derivation (H16 §1):
  sum_{l in F_p^*} rho(l) H(l)^2 = (1/(p-1)) sum_chi c(chi) c(rhobar chibar),  c(chi) = g(phi chi)^2 g(chibar)^2 / g(phi)^2,
  H(l) = (1/(1-p)) sum_chi c(chi) chi(l)   (Grove's normalisation),  a(l) = phi(-1) H(l) for l != 0,1.
Then  M_{3,2}(p) = sum_{l != 0,1} rho(l) a(l)^2 = G - H(1)^2.
Gauss sums g(omega^k) = sum_x omega^k(x) zeta_p^x computed by a DFT over discrete logs (complex floats).
PASS/FAIL (fixed before running): PASS = |G - H(1)^2 - M_exact| < 1e-6 and |H(l) - phi(-1)a(l)| < 1e-6 for all l != 0,1,
for every prime p ≡ 1 mod 3, 7 <= p <= PMAX.  Also prints H(1).
Usage: python -I H15_...py PMAX
"""
import sys, cmath
import numpy as np
PMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 200

def is_prime(n): return n > 1 and all(n % d for d in range(2, int(n ** .5) + 1))
def prim_root(p):
    fac = [d for d in range(2, p) if (p - 1) % d == 0 and is_prime(d)]
    return next(g for g in range(2, p) if all(pow(g, (p - 1) // f, p) != 1 for f in fac))

fails = []
for p in range(7, PMAX + 1):
    if not is_prime(p) or p % 3 != 1: continue
    n = p - 1; g = prim_root(p)
    pw = [pow(g, e, p) for e in range(n)]; ind = {v: e for e, v in enumerate(pw)}
    zeta = np.exp(2j * np.pi * np.array(pw) / p)            # zeta^{g^e}
    # chi_k(g^e) = exp(2 pi i k e / n);  g(chi_k) = sum_e chi_k(g^e) zeta^{g^e}
    G = np.array([np.sum(np.exp(2j * np.pi * k * np.arange(n) / n) * zeta) for k in range(n)])
    gs = lambda k: G[k % n]
    h = n // 2; r = n // 3                                   # phi = chi_h, rho = chi_r
    c = np.array([gs(h + k) ** 2 * gs(-k) ** 2 / gs(h) ** 2 for k in range(n)])
    def H(l):
        e = ind[l]; return np.sum(c * np.exp(2j * np.pi * np.arange(n) * e / n)) / (1 - p)
    Gsum = sum(c[k] * c[(-r - k) % n] for k in range(n)) / (p - 1)
    # exact Legendre traces and M
    chi = [0] + [-1] * (p - 1)
    for x in range(1, p): chi[x * x % p] = 1
    a = {l: -sum(chi[x * (x - 1) * (x - l) % p] for x in range(p)) for l in range(2, p)}
    M = sum((a[l] ** 2) * (1 if ind[l] % 3 == 0 else -0.5) for l in range(2, p))     # Re rho = 1 or -1/2
    phim1 = chi[p - 1]
    errH = max(abs(H(l) - phim1 * a[l]) for l in range(2, p))
    H1 = H(1)
    lhs = Gsum - H1 ** 2
    ok = abs(lhs - M) < 1e-6 and errH < 1e-6
    if not ok: fails.append(p)
    if p < 80: print(f'p={p:4d}  M={M:9.3f}  G-H(1)^2={lhs.real:12.6f}{lhs.imag:+.1e}i  H(1)={H1.real:+.4f}{H1.imag:+.1e}i  max|H-phi(-1)a|={errH:.1e}')
print('\nGauss-sum form check, p≡1 mod 3, 7<=p<=%d: ' % PMAX + ('PASS' if not fails else f'FAIL at {fails}'))
