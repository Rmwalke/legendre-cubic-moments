"""H24 — check: is the order-n twisted 2nd moment governed by the LTYZ form of datum (1/2,1/2,1/n,1-1/n)?
  Claim to test (n = 2,3,4,6):  M_{n,2}(p) := Re sum_{l=2}^{p-1} psi_n(l) a(l)^2  =  -a_f(p) - p - 1   (p ≡ 1 mod n, p > 5)
  (n = 2: sum over l=2..p-1 so T_2 = -a(p) - p - 1, Ahlgren–Ono; n = 3: H6.)
  a_f(p) obtained from the LTYZ supercongruence (arXiv:1705.01663, Thm 1):
     sum_{k=0}^{p-1} (1/2)_k^2 (r)_k (1-r)_k / k!^4  ≡  a_f(p)  (mod p^3),   p > 5,
  and |a_f(p)| <= 2 p^{3/2} < p^3/2  =>  a_f(p) = centred residue.  Exact modular arithmetic.
  Validation built in: n = 2 must reproduce eta(2z)^4 eta(4z)^4 ; n = 3 must reproduce 36.4.a.a (eta-quotient).
PASS/FAIL fixed before running: for each n, PASS = equality at every prime p ≡ 1 mod n, 7 <= p <= PMAX.
Usage: python -I H24_...py PMAX
"""
import sys
from fractions import Fraction as Fr
import numpy as np
PMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 400

def is_prime(n): return n > 1 and all(n % d for d in range(2, int(n ** .5) + 1))
def prim_root(p):
    fac = [d for d in range(2, p) if (p - 1) % d == 0 and is_prime(d)]
    return next(g for g in range(2, p) if all(pow(g, (p - 1) // f, p) != 1 for f in fac))

def ltyz_ap(p, r):
    m = p ** 3; a = [Fr(1, 2), Fr(1, 2), r, 1 - r]
    tot, term = 0, 1
    for k in range(p):
        tot = (tot + term) % m
        if k == p - 1: break
        num, den = 1, 1
        for x in a:
            v = k + x; num = num * v.numerator % m; den = den * v.denominator % m
        den = den * pow(k + 1, 4, m) % m
        term = term * num % m * pow(den, -1, m) % m
    t = tot % m
    return t - m if t > m // 2 else t

def traces(p):
    c = np.full(p, -1, dtype=np.int64); c[0] = 0
    c[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1
    x = np.arange(p, dtype=np.int64); base = (x * (x - 1)) % p
    return {l: -int(c[(base * ((x - l) % p)) % p].sum()) for l in range(2, p)}

def M_re(p, n, tr):
    g = prim_root(p); ind = [0] * p; v = 1
    for e in range(p - 1): ind[v] = e; v = v * g % p
    S = [0] * n
    for l in range(2, p): S[ind[l] % n] += tr[l] ** 2
    # Re sum_j zeta_n^j S_j, using S_j = S_{n-j}; exact via cos values for n in {2,3,4,6}
    cos2 = {2: [2, -2], 3: [2, -1, -1], 4: [2, 0, -2, 0], 6: [2, 1, -1, -2, -1, 1]}[n]   # 2*cos(2 pi j/n)
    val = sum(cos2[j] * S[j] for j in range(n))
    assert val % 2 == 0
    return val // 2

# eta validations
N = PMAX + 2
def eta_prod(spec, shift=None):
    lead = sum(m * e for m, e in spec); assert lead % 24 == 0; shift = lead // 24
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec:
        if e >= 0:
            for nn in range(1, N // m + 1):
                for _ in range(e):
                    for i in range(N, m * nn - 1, -1): P[i] -= P[i - m * nn]
        else:
            for nn in range(1, N // m + 1):
                for _ in range(-e):
                    for i in range(m * nn, N + 1): P[i] += P[i - m * nn]
    return ([0] * shift + P)[:N + 1]
a8 = eta_prod([(2, 4), (4, 4)], 1)
f36 = [x - 3 * y for x, y in zip(eta_prod([(6, 14), (2, -3), (18, -3)], 1), eta_prod([(2, 3), (6, 2), (18, 3)], 1))]

results = {}
for n, r in ((2, Fr(1, 2)), (3, Fr(1, 3)), (4, Fr(1, 4)), (6, Fr(1, 6))):
    bad_claim, bad_val, cnt, rows = [], [], 0, []
    for p in range(7, PMAX + 1):
        if not is_prime(p) or p % n != 1: continue
        ap = ltyz_ap(p, r)
        if n == 2 and ap != a8[p]: bad_val.append(p)
        if n == 3 and ap != f36[p]: bad_val.append(p)
        tr = traces(p); M = M_re(p, n, tr); cnt += 1
        if M != -ap - p - 1: bad_claim.append((p, M, -ap - p - 1))
        if len(rows) < 6: rows.append((p, M, ap))
    results[n] = (cnt, bad_claim, bad_val)
    print(f'n={n} (r={r}): {cnt} primes; first rows (p, M, a_f(p)) = {rows}')
    if n in (2, 3): print(f'   supercongruence validation vs eta-quotient: {"PASS" if not bad_val else "FAIL " + str(bad_val[:5])}')
    print(f'   claim M = -a_f - p - 1: {"PASS" if not bad_claim else "FAIL " + str(bad_claim[:5])}')
