"""H29 — Lemma L4: a_f(p) even for all primes p, f = 36.4.a.a.
 Claim: f ≡ eta(3z)^8 (mod 2) as q-series.  Both in S_4(Gamma_0(36)) (eta(3z)^8 = 9.4.a.a, level 9 | 36).
 Sturm (1987): congruence mod 2 holds if coefficients n <= k/12 * [SL2:Gamma_0(36)] = 4/12*72 = 24 agree mod 2.
 Then eta(3z)^8 ≡ eta(24z) (mod 2) ((1-x)^8 ≡ 1-x^8), and eta(24z) = sum_n chi_12(n) q^{n^2} (Euler) is supported on
 squares, so a_f(p) ≡ 0 (mod 2) for every prime p.  (p = 2, 3: a_f = 0 anyway.)
 PASS/FAIL fixed before running: PASS = f(n) ≡ eta(3z)^8(n) mod 2 for all n <= 24 (Sturm); also reported up to 2000.
Usage: python -I H29_...py
"""
N = 2000
def eta_prod(spec):
    lead = sum(m * e for m, e in spec); s = lead // 24
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec:
        for nn in range(1, N // m + 1):
            for _ in range(abs(e)):
                if e > 0:
                    for i in range(N, m * nn - 1, -1): P[i] -= P[i - m * nn]
                else:
                    for i in range(m * nn, N + 1): P[i] += P[i - m * nn]
    return ([0] * s + P)[:N + 1]
f = [x - 3 * y for x, y in zip(eta_prod([(6, 14), (2, -3), (18, -3)]), eta_prod([(2, 3), (6, 2), (18, 3)]))]
g = eta_prod([(3, 8)])
sturm = all((f[n] - g[n]) % 2 == 0 for n in range(0, 25))
full = [n for n in range(N + 1) if (f[n] - g[n]) % 2]
print('index [SL2:Gamma0(36)] = 36*(1+1/2)*(1+1/3) =', int(36 * 1.5 * 4 / 3), '; Sturm bound = 24')
print('f ≡ eta(3z)^8 mod 2 for n <= 24 (Sturm):', 'PASS' if sturm else 'FAIL')
print('mismatches up to', N, ':', full[:10])
import math
print('primes p<=2000 with f(p) odd:', [p for p in range(2, N + 1) if all(p % d for d in range(2, int(p ** .5) + 1)) and f[p] % 2])
