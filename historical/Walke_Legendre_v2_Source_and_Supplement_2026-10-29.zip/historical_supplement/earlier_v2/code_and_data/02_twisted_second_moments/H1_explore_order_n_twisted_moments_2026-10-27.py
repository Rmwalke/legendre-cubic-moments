"""H1 — explore: order-n character twisted moments of the Legendre family.
   M_{n,k}(p) = sum_{l=2}^{p-1} psi_n(l) a(l)^k ,  psi_n of exact order n (p ≡ 1 mod n).
Since a(1/l)^2 = a(l)^2 and psi(1/l) = conj psi(l), M is real for even k.
Exact: we store class sums S_j = sum_{ind(l) ≡ j mod n} a(l)^k (integers).
  n=4: M = S0 - S2 (and S1 = S3 checked);  n=3: M = S0 - S1 (S1 = S2 checked);  n=6 similarly.
Depends on choice of generator only through psi -> psi^{-1}, which leaves M unchanged (M real).
Usage: python -I H1_...py PMAX
"""
import sys
from math import isqrt
import numpy as np
PMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 600

def primes_upto(n):
    s = bytearray([1]) * (n + 1); s[0:2] = b'\x00\x00'
    for i in range(2, isqrt(n) + 1):
        if s[i]: s[i*i::i] = bytearray(len(s[i*i::i]))
    return [i for i in range(n + 1) if s[i]]

def prim_root(p):
    fac = [q for q in primes_upto(p) if (p - 1) % q == 0]
    for g in range(2, p):
        if all(pow(g, (p - 1) // q, p) != 1 for q in fac): return g

def traces(p):
    c = np.full(p, -1, dtype=np.int64); c[0] = 0
    c[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1
    x = np.arange(p, dtype=np.int64); base = (x * (x - 1)) % p
    return {l: -int(c[(base * ((x - l) % p)) % p].sum()) for l in range(2, p)}

def class_sums(p, n, k, tr):
    g = prim_root(p); ind = [0] * p; v = 1
    for e in range(p - 1): ind[v] = e; v = v * g % p
    S = [0] * n
    for l in range(2, p): S[ind[l] % n] += tr[l] ** k
    return S

if __name__ == '__main__':
    out = {}
    for p in primes_upto(PMAX):
        if p < 5: continue
        tr = traces(p)
        row = {}
        for n in (3, 4, 6):
            if (p - 1) % n: continue
            for k in (2, 4):
                S = class_sums(p, n, k, tr)
                if n == 4: assert S[1] == S[3]; M = S[0] - S[2]
                if n == 3: assert S[1] == S[2]; M = S[0] - S[1]
                if n == 6:
                    assert S[1] == S[5] and S[2] == S[4]
                    M2 = 2 * S[0] + S[1] - S[2] - 2 * S[3] - S[4] + S[5]  # 2*Re sum zeta6^j S_j
                    M = M2  # = 2*M_{6,k}
                row[(n, k)] = M
        out[p] = row
        print(p, row)
