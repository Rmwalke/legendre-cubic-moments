"""G3 — check of the T_4 formula derived (on paper) from the Ahlgren / Ahlgren–Ono trace formulas
(as quoted in Grove, arXiv:2409.14502, Thm 2.3):
   (1) -Tr_{k+2}(G0(4),p) = 3 + sum_{l=2}^{p-1} G_{k+2}(a(l),p)
   (2) -Tr_{k+2}(G0(8),p) = 4 + sum_{l=2}^{p-2} G_{k+2}(a(l^2),p),   G_6(s,p) = s^4 - 3p s^2 + p^2.
Derived claim (G2 §2):  T_4(p) := sum_{l=2}^{p-1} chi(l) a(l)^4
                       = -c(p) - b(p) - 3p a(p) - 2p^2 - 3p - 1,
   a = 8.4.a.a = eta(2z)^4 eta(4z)^4,  b = 4.6.a.a = eta(2z)^12,  c = newform 8.6.a.a.
c is built INDEPENDENTLY here: odd-exponent part of S_6(G0(8)) = span{b, c}; take g = A(z)*F(2z) with
A = eta(2z)^4 eta(4z)^4, F = 2E_2(2z) - E_2(z) (weight 2, level 2); diagonalise T_3 on span{b, g}.
PASS/FAIL (fixed before running): PASS = exact integer equality for every prime 5 <= p <= PMAX. FAIL = any mismatch.
All arithmetic exact (Python int / Fraction).  Usage: python -I G3_...py [PMAX]
"""
import sys
from fractions import Fraction as Fr
from math import isqrt

PMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 400
N = 3 * PMAX + 3

def primes_upto(n):
    s = bytearray([1]) * (n + 1); s[0:2] = b'\x00\x00'
    for i in range(2, isqrt(n) + 1):
        if s[i]: s[i*i::i] = bytearray(len(s[i*i::i]))
    return [i for i in range(n + 1) if s[i]]

def mul(A, B):
    C = [0] * (N + 1)
    for i, x in enumerate(A):
        if x:
            for j in range(N + 1 - i):
                if B[j]: C[i + j] += x * B[j]
    return C

def eta_pow(m, e):  # prod (1 - q^{m n})^e, truncated (no q^{1/24} factor)
    P = [0] * (N + 1); P[0] = 1
    for n in range(1, N // m + 1):
        for _ in range(e):
            for i in range(N, m * n - 1, -1): P[i] -= P[i - m * n]
    return P

def shift(P, k): return ([0] * k + P)[:N + 1]

# a = q prod(1-q^2n)^4 (1-q^4n)^4 ; b = q prod (1-q^2n)^12
A = shift(mul(eta_pow(2, 4), eta_pow(4, 4)), 1)
B = shift(eta_pow(2, 12), 1)
# F(z) = 2E2(2z) - E2(z) = 1 + 24 sum_{n} sigma_odd(n) q^n ; use F(2z)
sig_odd = [0] * (N + 1)
for d in range(1, N + 1, 2):
    for m in range(d, N + 1, d): sig_odd[m] += d
F = [1] + [24 * sig_odd[n] for n in range(1, N + 1)]
F2 = [0] * (N + 1)
for n in range(0, N // 2 + 1): F2[2 * n] = F[n]
G = mul(A, F2)

def T3(P, M):  # coefficients n<=M of T_3 P (weight 6)
    return [P[3 * n] + (243 * P[n // 3] if n % 3 == 0 else 0) for n in range(M + 1)]

# express T3(b), T3(g) in basis {b, g} using coefficients n = 1, 3
M = PMAX
def coords(V):  # solve V = x b + y g from n=1,3
    det = Fr(B[1] * G[3] - B[3] * G[1])
    return (Fr(V[1] * G[3] - V[3] * G[1]) / det, Fr(B[1] * V[3] - B[3] * V[1]) / det)
tb, tg = coords(T3(B, 3)), coords(T3(G, 3))
# matrix columns: T b = tb, T g = tg ; b is eigen (tb = (b3,0)); find other eigenvector
b3 = tb[0]; assert tb[1] == 0
lam = tg[1]                      # eigenvalue on quotient = c(3)
# eigenvector v = g + s b with (T - lam) v = 0:  tg[0] + s*b3 - lam*s = 0
s = -tg[0] / (b3 - lam)
Cv = [Fr(G[n]) + s * B[n] for n in range(M + 1)]
c = [x / Cv[1] for x in Cv]
assert all(x.denominator == 1 for x in c), 'c not integral'
c = [int(x) for x in c]
print('c = 8.6.a.a (constructed): ', {n: c[n] for n in range(1, 16, 2)})
print('Hecke check c(9)=c(3)^2-3^5:', c[9] == c[3] ** 2 - 243, ' c(15)=c(3)c(5):', c[15] == c[3] * c[5])
print('b = eta(2z)^12:', {n: B[n] for n in range(1, 12, 2)}, ' a = 8.4.a.a:', {n: A[n] for n in range(1, 12, 2)})

def legendre_traces(p):
    chi = [0] + [-1] * (p - 1)
    for x in range(1, p): chi[x * x % p] = 1
    base = [x * (x - 1) % p for x in range(p)]
    tr = {}
    for l in range(2, p):
        tr[l] = -sum(chi[base[x] * (x - l) % p] for x in range(p))
    return chi, tr

fails, n = [], 0
for p in primes_upto(PMAX):
    if p < 5: continue
    chi, tr = legendre_traces(p)
    T4 = sum(chi[l] * tr[l] ** 4 for l in range(2, p))
    pred = -c[p] - B[p] - 3 * p * A[p] - 2 * p * p - 3 * p - 1
    n += 1
    if T4 != pred: fails.append((p, T4, pred))
    if p < 60: print(f'p={p:4d}  T4={T4:12d}  formula={pred:12d}  {"MATCH" if T4 == pred else "MISMATCH"}')
print(f'\nT4 formula, primes 5<=p<={PMAX}: {n} primes -> ' + ('PASS' if not fails else f'FAIL {fails[:5]}'))
