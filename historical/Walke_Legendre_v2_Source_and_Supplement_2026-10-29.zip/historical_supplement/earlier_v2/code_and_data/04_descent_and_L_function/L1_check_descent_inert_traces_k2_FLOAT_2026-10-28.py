"""L1 (FLOAT: FFT for a'(x); rounded integer outputs, not certified point counts) — descent W of the rho-part to Q: traces at INERT p (p ≡ 2 mod 3)
 via the twisted Lefschetz formula for sigma∘Frob_p, sigma: lambda -> 1/lambda.
 Fixed points: lambda^{p+1} = 1 (norm-1 torus T1 ⊂ F_{p^2}).  lambda = nu^{p-1}, nu = x + sqrt(nr) (x in F_p) plus lambda = 1.
 E_lambda ≅ (quadratic twist of) E'_x : Y^2 = X (X^2 - 2x X + x^2 - nr)  over F_p   [x = X'/nu substitution],
 so on Sym^k (k even) the local trace is Sym^k of Frob on E'_x:  a'^2 - p (k=2),  a'^4 - 3p a'^2 + p^2 (k=4).
 Kummer factor at a fixed point: cubic character of nu in F_{p^2}  (rho_{p^2}(nu)^{±1}; real part used).
 k = 2 prediction:  tW2(p) := -Re sum_x rho(nu_x) (a'(x)^2 - p) - eta,  eta = boundary eigenvalue at lambda = 1 (try ±1),
 should equal  eps * a_f(p)  (f = 36.4.a.a) with ONE global sign eps (the two descents W, W ⊗ chi_{-3}).
 PASS/FAIL fixed before running: some (eta, eps) fits every inert prime 5 <= p <= PMAX exactly.
Usage: python -I L1_...py PMAX
"""
import sys, math
import numpy as np
PMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 300
def is_prime(n): return n > 1 and all(n % d for d in range(2, math.isqrt(n) + 1))
def chi_table(p):
    c = np.full(p, -1, dtype=np.int64); c[0] = 0; c[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1; return c
def fp2_pow(A, B, e, p, nr):
    RA = np.ones_like(A); RB = np.zeros_like(B); XA, XB = A.copy(), B.copy()
    while e:
        if e & 1: RA, RB = (RA * XA + nr * RB * XB) % p, (RA * XB + RB * XA) % p
        XA, XB = (XA * XA + nr * XB * XB) % p, (2 * XA * XB) % p
        e >>= 1
    return RA, RB
def twisted_data(p):
    chi = chi_table(p); nr = next(x for x in range(2, p) if chi[x] == -1)
    X = np.arange(p)
    # a'(x) = -sum_X chi(X) chi((X-x)^2 - nr)  = -corr(chi, g)(x),  g(u) = chi(u^2 - nr)
    g = chi[(X * X - nr) % p].astype(float); c = chi.astype(float)
    corr = np.fft.ifft(np.fft.fft(c) * np.conj(np.fft.fft(g))).real     # corr[x] = sum_X c(X) g(X - x)
    ap = -np.rint(corr).astype(np.int64)
    assert np.all(np.abs(ap) <= 2 * math.sqrt(p) + 1e-9) and np.all(ap % 2 == 0)
    # cubic class of nu = x + sqrt(nr) in F_{p^2}
    RA, RB = fp2_pow(X.astype(np.int64), np.ones(p, dtype=np.int64), (p * p - 1) // 3, p, nr)
    keys = RA * p + RB; one = p
    others = sorted(set(keys.tolist()) - {one})
    cls = np.zeros(p, dtype=np.int64)
    if len(others) >= 1: cls[keys == others[0]] = 1
    if len(others) == 2: cls[keys == others[1]] = 2
    return ap, cls
def re_sum(vals, cls):
    S = [int(sum(int(v) for v in vals[cls == j])) for j in range(3)]
    assert S[1] == S[2], S
    return S[0] - S[1]
N = PMAX + 2
def eta_prod(spec):
    lead = sum(m * e for m, e in spec); s = lead // 24
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec:
        for nn in range(1, N // m + 1):
            for _ in range(abs(e)):
                if e > 0:
                    for i in range(N, m * nn - 1, -1): P[i] -= P[i - m * nn]
                else:
                    for i in range(m * nn, N + 1): P[i] += P[i - m * nn]
    return ([0] * s + P)[:N + 1]
f = [x - 3 * y for x, y in zip(eta_prod([(6, 14), (2, -3), (18, -3)]), eta_prod([(2, 3), (6, 2), (18, 3)]))]
rows = []
for p in range(5, PMAX + 1):
    if not is_prime(p) or p % 3 != 2: continue
    ap, cls = twisted_data(p)
    Y2 = re_sum(ap * ap - p, cls)
    rows.append((p, Y2, f[p]))
fits = []
for eta in (1, -1):
    for eps in (1, -1):
        if all(-Y2 - eta == eps * af for p, Y2, af in rows): fits.append((eta, eps))
print('first rows (p, Y2, a_f):', rows[:8])
print('fitting (eta, eps):', fits)
print(f'k=2 descent check, inert 5<=p<={PMAX} ({len(rows)} primes):', 'PASS' if fits else 'FAIL')
