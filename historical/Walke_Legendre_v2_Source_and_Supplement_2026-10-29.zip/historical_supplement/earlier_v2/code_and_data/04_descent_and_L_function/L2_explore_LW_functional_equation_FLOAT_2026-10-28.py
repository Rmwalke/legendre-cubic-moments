"""L2 (FLOAT) — L(W, s) for the descent W of V (cubic twist, Sym^4) to Q: Euler factors + functional-equation search.
 Split p (≡ 1 mod 3): P_p(T) = 1 - s1 T + s2 T^2 - p^5 s1 T^3 + p^10 T^4   (laptop H13 data, integer-valued after FFT rounding).
 Inert p (≡ 2 mod 3): c1 = tr W(Frob_p) = -Re sum_x rho(nu_x) (a'^4 - 3p a'^2 + p^2) - 1   (L1 method, k = 4),
     c2 = (c1^2 - u)/2  (u = tr V(Frob_{p^2}) from H13),  P_p(T) = 1 - c1 T + c2 T^2 - mu c1 T^3 + mu^2 T^4, mu = ±p^5.
     mu chosen by the Weil test (all roots |x| = p^{5/2}); both signs of c1 (descents W, W ⊗ chi_{-3}) are tried.
 Bad p = 2, 3: P = 1 is an explicit numerical assumption, not a local computation.
 Lambda_hat(s) = N^{s/2} (2pi)^(-2s) Gamma(s)^2 L(s); Lambda=4*Lambda_hat with standard Gamma_C,  Lambda(s) = eps Lambda(6 - s)  <=>  theta(1/t) = eps t^6 theta(t),
   theta(t) = sum_n a_n phi(n t / sqrt N),  phi(x) = 2 K_0(4 pi sqrt x).
 PASS/FAIL fixed before running: PASS = some (N = 2^a 3^b <= 1e5, eps, descent sign) with max relative defect < 1e-6
   at t in {1.05, 1.1, 1.2, 1.3}; otherwise report the best candidates (no claim).
Usage: python -I L2_...py H13_output_data.txt
"""
import sys, math, itertools
import numpy as np
from scipy.special import k0
import importlib.util
spec = importlib.util.spec_from_file_location('l1', 'L1_check_descent_inert_traces_k2_FLOAT_2026-10-28.py')
src = open('L1_check_descent_inert_traces_k2_FLOAT_2026-10-28.py').read().split('N = PMAX + 2')[0]
ns = {'sys': sys}; sys_argv = sys.argv; sys.argv = ['x', '10']; exec(src, ns); sys.argv = sys_argv
twisted_data, re_sum, is_prime = ns['twisted_data'], ns['re_sum'], ns['is_prime']

data = {}
for l in open(sys.argv[1], encoding='utf-8'):
    if l.startswith('#') or not l.strip(): continue
    t = l.split(); data[int(t[0])] = t
NMAX = max(data)
def exact_weil_multiplier(p, c1, c2, sign):
    P = p**5
    if sign == -1:
        # A real monic unit-circle quartic with constant 1 is reciprocal.
        # Comparing the +/-c1 coefficients forces c1=0 for multiplier -P.
        return c1 == 0 and abs(c2) <= 2*P
    D = c1*c1 - 4*(c2-2*P)
    A = 16*P-c1*c1-D
    return D >= 0 and A >= 0 and A*A >= 4*c1*c1*D

euler = {}            # p -> (c1, c2, mu) ; inert stored with c1 for descent '+'
weil_ok = {+1: 0, -1: 0}; ninert = 0
for p in sorted(data):
    t = data[p]
    if t[1] == 'split':
        euler[p] = (int(t[2]), int(t[3]), p ** 5)
    else:
        u = int(t[2]); ap, cls = twisted_data(p)
        c1 = -re_sum(ap ** 4 - 3 * p * ap ** 2 + p * p, cls) - 1
        assert (c1 * c1 - u) % 2 == 0
        c2 = (c1 * c1 - u) // 2; ninert += 1
        for sg in (1, -1):
            mu = sg * p ** 5
            if exact_weil_multiplier(p, c1, c2, sg): weil_ok[sg] += 1
        euler[p] = (c1, c2, None)
print(f'inert primes: {ninert};  Weil OK with mu=+p^5: {weil_ok[1]},  mu=-p^5: {weil_ok[-1]}')
valid_mu = [sg for sg in (1, -1) if ninert > 0 and weil_ok[sg] == ninert]
if len(valid_mu) != 1:
    raise ValueError('Multiplier is not uniquely selected by all inert input factors')
MU = valid_mu[0]
print('chosen mu sign:', MU)
print('Bad factors P2=P3=1 are assumed; a numerical FE fit does not prove the conductor.')

def coeffs(desc, as_float=True):
    a = np.zeros(NMAX + 1); a[1] = 1.0
    pk = {}
    for p, (c1, c2, mu) in euler.items():
        if mu is None: c1 = desc * c1; mu = MU * p ** 5
        # 1/P(T) power series: b_k = c1 b_{k-1} - c2 b_{k-2} + mu c1 b_{k-3} - mu^2 b_{k-4}
        b = [1]; k = 1
        while p ** k <= NMAX:
            v = c1 * b[k - 1] - (c2 * b[k - 2] if k >= 2 else 0) + (mu * c1 * b[k - 3] if k >= 3 else 0) - (mu * mu * b[k - 4] if k >= 4 else 0)
            b.append(v); k += 1
        pk[p] = b
    # multiplicative fill (smallest prime factor sieve)
    spf = list(range(NMAX + 1))
    for i in range(2, math.isqrt(NMAX) + 1):
        if spf[i] == i:
            for j in range(i * i, NMAX + 1, i):
                if spf[j] == j: spf[j] = i
    A = [0] * (NMAX + 1); A[1] = 1
    for n in range(2, NMAX + 1):
        p = spf[n]; m = n; k = 0
        while m % p == 0: m //= p; k += 1
        if p in (2, 3): A[n] = 0
        else: A[n] = A[m] * pk[p][k]
    return np.array(A, dtype=float) if as_float else A

ts = [1.05, 1.1, 1.2, 1.3]
nvec = np.arange(1, NMAX + 1, dtype=float)
def theta(A, N, t):
    x = nvec * t / math.sqrt(N)
    return float(np.sum(A[1:] * 2 * k0(4 * math.pi * np.sqrt(x))))
results = []
for desc in (1, -1):
    A = coeffs(desc)
    for a2 in range(0, 17):
        for a3 in range(0, 11):
            N = 2 ** a2 * 3 ** a3
            if N > 1e5: continue
            th = [(theta(A, N, t), theta(A, N, 1 / t)) for t in ts]
            for eps in (1, -1):
                d = max(abs(tb - eps * t ** 6 * ta) / (abs(tb) + abs(t ** 6 * ta) + 1e-300) for t, (ta, tb) in zip(ts, th))
                results.append((d, N, a2, a3, eps, desc))
results.sort()
print('best candidates (defect, N, 2^a, 3^b, eps, descent):')
for r in results[:10]: print('  ', f'{r[0]:.3e}', r[1:])
print('FE search:', 'PASS' if results[0][0] < 1e-6 else 'no candidate below 1e-6 (N <= 1e5, bad factors = 1)')
