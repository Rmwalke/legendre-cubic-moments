"""L4 (FLOAT) — central value of L(W, s) at s = 3 (N = 1296, eps = +1, descent -1), and a_p table.
 Lambda_hat(s) = N^{s/2} (2pi)^{-2s} Gamma(s)^2 L(s) = int_1^inf theta(t) (t^{s-1} + eps t^{5-s}) dt,  theta(t) = sum a_n 2K_0(4 pi sqrt(n t / sqrt N)).
 Lambda(3) = 2 int_1^inf theta(t) t^2 dt  (eps = +1).  The equality at s=3.5 and s=2.5 with t0=1 is built into the integrand
 and is not an independent FE test; and L(3) via two different splitting points t0 = 1 and t0 = 1.3 must agree.
Usage: python -I L4_...py H13_output_data.txt
"""
import sys, math
import numpy as np
from scipy.special import k0
from scipy.integrate import quad
src = open('L2_explore_LW_functional_equation_FLOAT_2026-10-28.py').read().split('ts = [1.05')[0]
ns = {'__name__': 'l2'}; exec(compile(src, 'l2', 'exec'), ns)
A = ns['coeffs'](-1); NMAX = ns['NMAX']; N = 1296; eps = 1
n = np.arange(1, NMAX + 1, dtype=float)
theta = lambda t: float(np.sum(A[1:] * 2 * k0(4 * math.pi * np.sqrt(n * t / math.sqrt(N)))))
def Lam(s, t0=1.0):
    # Lambda(s) = int_{t0}^inf theta(t) t^{s-1} dt + eps * int_{1/t0}^inf theta(t) t^{5-s} dt   (general split)
    I1 = quad(lambda t: theta(t) * t ** (s - 1), t0, 3000, limit=500)[0]
    I2 = quad(lambda t: theta(t) * t ** (5 - s), 1 / t0, 3000, limit=500)[0]
    return I1 + eps * I2
def L_of(s, t0=1.0): return Lam(s, t0) / (N ** (s / 2) * (2 * math.pi) ** (-2 * s) * math.gamma(s) ** 2)
L3a, L3b = L_of(3, 1.0), L_of(3, 1.3)
print(f'L(W,3) with split t0=1: {L3a:.10f} ; t0=1.3: {L3b:.10f}')
print(f'Built-in symmetry (not an independent FE test): Lambda_hat(3.5) = {Lam(3.5):.10e}, Lambda_hat(2.5) = {Lam(2.5):.10e}')
# Dirichlet-series sanity at s = 6 (absolutely convergent region s > 3.5 + 1): compare with integral representation
Ls = float(np.sum(A[1:] / n ** 6.5))
print(f'L(6.5) direct sum (n<=NMAX) = {Ls:.8f} ; integral repr = {L_of(6.5):.8f}')
print('a_p table (p, a_p):', [(p, int(A[p])) for p in range(5, 60) if ns['is_prime'](p)])

print('Central values are conditional on the candidate completion and bad-prime assumptions.')
