"""L3 (FLOAT) — robustness of the functional equation found in L2: N = 1296, eps = +1, descent -1, mu = +p^5,
 bad factors at 2, 3 equal to 1, Gamma_C(s)^2, s <-> 6 - s.
 PASS/FAIL fixed before running:
  (1) defect < 1e-10 for every t in {1.01, 1.02, 1.05, 1.1, 1.3, 1.5, 2.0}  (n <= 4999)
  (2) defect < 1e-10 with coefficients truncated to n <= 3000 at t in {1.1, 1.2}
  (3) control: changing a_7 by +1 (and its multiples via multiplicativity are NOT changed) raises the defect above 1e-6
  (4) control: N = 1296 with eps = -1, and N = 648, 2592, 3888 with eps = +1 all have defect > 1e-6.
Usage: python -I L3_...py H13_output_data.txt
"""
import sys, math
import numpy as np
from scipy.special import k0
src = open('L2_explore_LW_functional_equation_FLOAT_2026-10-28.py').read().split('ts = [1.05')[0]
ns = {'__name__': 'l2'}; exec(compile(src, 'l2', 'exec'), ns)
A = ns['coeffs'](-1); NMAX = ns['NMAX']
def defect(A, N, eps, t, nmax):
    n = np.arange(1, nmax + 1, dtype=float)
    th = lambda tt: float(np.sum(A[1:nmax + 1] * 2 * k0(4 * math.pi * np.sqrt(n * tt / math.sqrt(N)))))
    a, b = th(t), th(1 / t)
    return abs(b - eps * t ** 6 * a) / (abs(b) + abs(t ** 6 * a))
ok = True
d1 = {t: defect(A, 1296, 1, t, NMAX) for t in (1.01, 1.02, 1.05, 1.1, 1.3, 1.5, 2.0)}
print('(1)', {t: f'{d:.1e}' for t, d in d1.items()}); ok &= max(d1.values()) < 1e-10
d2 = {t: defect(A, 1296, 1, t, 3000) for t in (1.1, 1.2)}
print('(2) n<=3000:', {t: f'{d:.1e}' for t, d in d2.items()}); ok &= max(d2.values()) < 1e-10
B = A.copy(); B[7] += 1
d3 = defect(B, 1296, 1, 1.1, NMAX); print(f'(3) a_7 + 1: defect {d3:.1e}'); ok &= d3 > 1e-6
d4 = {(N, e): defect(A, N, e, 1.1, NMAX) for N, e in ((1296, -1), (648, 1), (2592, 1), (3888, 1))}
print('(4)', {k: f'{d:.1e}' for k, d in d4.items()}); ok &= min(d4.values()) > 1e-6
print('a_n (n <= 30, W descent -1):', {n: int(A[n]) for n in range(1, 31) if A[n]})
print('ROBUSTNESS:', 'PASS' if ok else 'FAIL')
