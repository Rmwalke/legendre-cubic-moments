Compile audit_addendum.tex twice with a standard pdfLaTeX installation.
No numerical research scripts are part of this addendum.
