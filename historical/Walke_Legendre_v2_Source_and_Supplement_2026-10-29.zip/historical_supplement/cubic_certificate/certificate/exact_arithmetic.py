"""Exact finite-arithmetic helpers for the v2 correction draft.
Direct character sums use integers; they do not invoke FFT routines.
The quartic Weil test is exact for the stated +p^5 reciprocal polynomial.
"""
from pathlib import Path
import importlib.util
import json
import math
import sys
import numpy as np


def chi_table(p):
    out = np.full(p, -1, dtype=np.int64)
    out[0] = 0
    out[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1
    return out


def discrete_logs(p):
    for g in range(2, p):
        seen, a = [], 1
        for e in range(p - 1):
            seen.append(a)
            a = a * g % p
        if len(set(seen)) == p - 1:
            out = np.zeros(p, dtype=np.int64)
            for e, a in enumerate(seen):
                out[a] = e
            return out
    raise ValueError(p)


def direct_moments(p, degree, orders):
    """All Legendre traces over F_p or F_p[sqrt(d)] by exact O(q^2) sums.

    For degree 2 the order-n character is the norm lift of a character on
    F_p, so this function requires n | p-1. Conjugate class sums are equal.
    """
    chi = chi_table(p)
    logs = discrete_logs(p)
    if degree == 1:
        aa = np.arange(p, dtype=np.int64)
        bb = np.zeros(p, dtype=np.int64)
        nr = 0
    else:
        nr = next(i for i in range(2, p) if chi[i] == -1)
        aa = np.repeat(np.arange(p, dtype=np.int64), p)
        bb = np.tile(np.arange(p, dtype=np.int64), p)
    q = p ** degree
    norm = (aa * aa - nr * bb * bb) % p
    if degree == 1:
        cq = chi[aa]
        cc1 = chi[(aa - 1) % p]
    else:
        cq = chi[norm]
        cc1 = chi[((aa - 1) ** 2 - nr * bb * bb) % p]
    base = cq * cc1
    traces = []
    indices = []
    for j, (c, d) in enumerate(zip(aa, bb)):
        if int(d) == 0 and int(c) in (0, 1):
            continue
        if degree == 1:
            shift = chi[(aa - c) % p]
        else:
            shift = chi[((aa - c) ** 2 - nr * (bb - d) ** 2) % p]
        tr = -int(np.dot(base, shift))
        assert tr * tr <= 4 * q
        assert (q + 1 - tr) % 4 == 0  # full rational 2-torsion
        traces.append(tr)
        indices.append(j)
    class_source = logs[aa if degree == 1 else norm]
    ans = {}
    for n in orders:
        assert (p - 1) % n == 0
        for k in (2, 4):
            sums = [0] * n
            for j, tr in zip(indices, traces):
                sums[int(class_source[j]) % n] += tr ** k
            assert all(sums[j] == sums[-j] for j in range(1, n))
            if n == 3:
                val = sums[0] - sums[1]
            elif n == 4:
                val = sums[0] - sums[2]
            elif n == 6:
                val = sums[0] + sums[1] - sums[2] - sums[3]
            else:
                raise ValueError(n)
            ans[(n, k)] = val
    return ans


def exact_weil(p, c1, c2):
    """Exact criterion for the reciprocal quartic with multiplier +p^5.

    y = x + p^5/x gives y^2-c1*y+c2-2*p^5. All four x-roots
    have modulus p^(5/2) iff D >= 0 and |c1|+sqrt(D) <= 4*sqrt(p^5).
    The last inequality is squared with both signs checked, using integers.
    """
    P = p ** 5
    D = c1 * c1 - 4 * (c2 - 2 * P)
    if D < 0:
        return False
    A = 16 * P - c1 * c1 - D
    return A >= 0 and A * A >= 4 * c1 * c1 * D


def old_weil(p, c1, c2):
    D = c1 * c1 - 4 * (c2 - 2 * p ** 5)
    if D < 0:
        return False
    sq = math.isqrt(D)
    return all((z / 2) ** 2 <= 4 * p ** 5 * (1 + 1e-9)
               for z in (c1 + sq, c1 - sq))


def fp2_pow(z, e, p, d):
    def mul(u, v):
        return ((u[0]*v[0]+d*u[1]*v[1]) % p,
                (u[0]*v[1]+u[1]*v[0]) % p)
    a = (1, 0)
    while e:
        if e & 1:
            a = mul(a, z)
        z = mul(z, z)
        e >>= 1
    return a


def direct_inert(p):
    """Exact trace for the conjectural descent formula, not its proof."""
    chi = chi_table(p)
    d = next(i for i in range(2, p) if chi[i] == -1)
    X = np.arange(p, dtype=np.int64)
    tr, classes = [], []
    for x in range(p):
        a = -int(np.dot(chi[X], chi[((X-x)**2-d) % p]))
        assert a*a <= 4*p
        tr.append(a)
        classes.append(fp2_pow((x, 1), (p*p-1)//3, p, d))
    vals = {k: {} for k in (2, 4)}
    for a, cl in zip(tr, classes):
        for k, v in ((2, a*a-p), (4, a**4-3*p*a*a+p*p)):
            vals[k][cl] = vals[k].get(cl, 0) + v
    out = {}
    for k, sums in vals.items():
        nontriv = [sums[c] for c in sums if c != (1, 0)]
        assert len(nontriv) == 2 and nontriv[0] == nontriv[1]
        M = sums.get((1, 0), 0) - nontriv[0]
        out[k] = M + 1  # W=W' tensor chi_-3; inert sign is reversed
    return out


