CARRIED EXACT CERTIFICATE — NOT RERUN FOR THIS NOTE

These files are unchanged copies from the earlier corrected manuscript bundle.
The geometric proof in the accompanying PDF treats n=3 only. The certificate
script also contains n=4 and n=6 tests; those finite tests do not complete
their separate geometric proof obligations.

The three Python files are kept together because V2_01_exact_livne.py imports
exact_arithmetic.py and exact_bcm_p5.py locally. This task did not execute
any of these scripts. The requirements file records the earlier validation
environment; it is not a claim about packages installed or used in this task.

For a future arithmetic rerun, the script documents its invocation. Use a
new output filename and a separately captured log; preserve the carried files.
