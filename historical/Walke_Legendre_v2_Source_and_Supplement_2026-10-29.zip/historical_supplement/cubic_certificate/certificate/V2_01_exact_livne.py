"""Exact finite Livne comparisons, including the enlarged quartic test set.

All three cases use S consisting of primes over 2 and 3. This avoids assuming
an additional unramifiedness-at-3 result in the quartic case.
Run: python -I V2_01_exact_livne.py [certificate.json]
This certifies finite arithmetic, not the geometric hypotheses of Livne.
"""
from fractions import Fraction as F
from pathlib import Path
import importlib.util
import json
import math
import sys

HERE = Path(__file__).resolve().parent


def local_module(name):
    spec = importlib.util.spec_from_file_location(name, HERE/(name+'.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


arith = local_module('exact_arithmetic')
bcm = local_module('exact_bcm_p5')


def prime(p):
    return p >= 2 and all(p%d for d in range(2, math.isqrt(p)+1))


def leg(a, p):
    a %= p
    return 0 if a == 0 else (1 if pow(a, (p-1)//2, p) == 1 else -1)


def eta(spec, N):
    lead = sum(m*e for m,e in spec)
    assert lead % 24 == 0
    A = [1]+[0]*N
    for m,e in spec:
        for j in range(m,N+1,m):
            for _ in range(abs(e)):
                for i in (range(N,j-1,-1) if e > 0 else range(j,N+1)):
                    A[i] += (-1 if e > 0 else 1)*A[i-j]
    return ([0]*(lead//24)+A)[:N+1]


def ltyz(p, r):
    assert p > 5
    modulus = p**3
    term, total = 1, 0
    for k in range(p):
        total = (total+term) % modulus
        if k == p-1:
            break
        numerator, denominator = 1, 1
        for z in (F(1,2),F(1,2),r,1-r):
            z += k
            numerator = numerator*z.numerator % modulus
            denominator = denominator*z.denominator % modulus
        denominator = denominator*pow(k+1,4,modulus) % modulus
        term = term*numerator*pow(denominator,-1,modulus) % modulus
    ans = total-modulus if total > modulus//2 else total
    assert ans*ans <= 4*p**3
    return ans


def forms(N):
    f3 = [a-3*b for a,b in zip(eta([(6,14),(2,-3),(18,-3)],N),
                                eta([(2,3),(6,2),(18,3)],N))]
    f4 = eta([(4,16),(2,-4),(8,-4)],N)
    ap = {2:0,3:0,5:int(bcm.compute_values()[6][1])}
    for p in range(7,N+1):
        if prime(p):
            ap[p] = ltyz(p,F(1,6))
    f6=[0]*(N+1);f6[1]=1
    for n in range(2,N+1):
        p=next(d for d in range(2,n+1) if n%d==0)
        m,k=n,0
        while m%p==0:
            m//=p;k+=1
        if p in (2,3):
            b=0
        else:
            b0,b=1,ap[p]
            for _ in range(1,k):
                b0,b=b,ap[p]*b-p**3*b0
        f6[n]=f6[m]*b
    g=eta([(3,8)],N)
    assert all((f3[j]-g[j])%2==0 for j in range(25))
    assert all((f6[j]-g[j])%2==0 for j in range(49))
    odd_squares={j*j for j in range(1,math.isqrt(N)+1,2)}
    assert all(f4[j]%2 == (j in odd_squares) for j in range(N+1))
    return {3:f3,4:f4,6:f6}


def test_set(n, maxp=400):
    seen=set();out=[]
    for p in range(5,maxp+1):
        if not prime(p) or p%n!=1:
            continue
        disc=-1 if n==4 else -3
        root=next(r for r in range(p) if r*r%p==disc%p)
        for r in (root,p-root):
            units=(r,1+r,3) if n==4 else (-1,2,r)
            vector=[int(leg(u,p)==-1) for u in units]
            v=sum(b<<j for j,b in enumerate(vector))
            if v and v not in seen:
                out.append({'p':p,'root':r,'vector':vector,'bits':format(v,'03b')})
                seen.add(v)
        if len(seen)==7:
            return out
    raise RuntimeError('incomplete non-cubic set')


def main():
    f=forms(200)
    cache={};result={'S':'primes over 2 and 3 in all three cases','cases':{}}
    for n in (3,4,6):
        rows=test_set(n)
        for row in rows:
            p=row['p']
            for d in (1,2):
                key=(p,d)
                if key not in cache:
                    orders=[m for m in (3,4,6) if (p-1)%m==0]
                    cache[key]=arith.direct_moments(p,d,orders)
            M1=cache[p,1][n,2];M2=cache[p,2][n,2]
            t=-M1-1-p;u=-M2-1-p*p
            assert (t*t-u)%2==0
            det=(t*t-u)//2
            assert t==f[n][p] and det==p**3
            row.update(M2_Fp=M1,M2_Fp2=M2,trace=t,target=f[n][p],det=det)
            print(f'n={n} p={p:2d} root={row["root"]:2d} vector={row["bits"]} trace={t:5d} det={det}: PASS')
        assert {r['bits'] for r in rows}=={format(k,'03b') for k in range(1,8)}
        result['cases'][str(n)]=rows
    print('Exact finite comparisons: PASS. Geometric hypotheses are separate.')
    print('Sturm comparisons f36 / f72: PASS through bounds 24 / 48.')
    if len(sys.argv)>1:
        Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':
    main()
