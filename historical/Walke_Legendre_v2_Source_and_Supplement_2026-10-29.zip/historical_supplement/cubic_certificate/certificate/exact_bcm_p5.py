"""Exact BCM sums at p=5 in Q[zeta_20], using Fraction arithmetic.

This uses Theorem 1.3 of Beukers--Cohen--Mellit, arXiv:1505.02900,
directly in its product-of-Gauss-sums normalization, with no numerical
calibration. The modular interpretation still invokes the cited LTYZ theorem.
Run: python exact_bcm_p5.py
"""
from fractions import Fraction as F


def add(a, b):
    return tuple(x+y for x, y in zip(a, b))


def scalar(a, c):
    return tuple(c*x for x in a)


def mul(a, b):
    v = [F(0)]*15
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            v[i+j] += x*y
    # Phi_20(X)=X^8-X^6+X^4-X^2+1.
    for k in range(14, 7, -1):
        c = v[k]
        v[k] = F(0)
        for shift, sign in ((2, 1), (4, -1), (6, 1), (8, -1)):
            v[k-shift] += sign*c
    return tuple(v[:8])


ZERO = (F(0),)*8
ONE = (F(1),)+(F(0),)*7
Z = (F(0), F(1))+(F(0),)*6
ZPOW = [ONE]
for _ in range(20):
    ZPOW.append(mul(ZPOW[-1], Z))
assert ZPOW[20] == ONE


def compute_values():
    result = {}
    # 2 generates F_5^*. omega(2)=i=zeta_20^5; additive character=zeta_20^(4x).
    logs = {pow(2, e, 5): e for e in range(4)}
    gs = []
    for m in range(4):
        g = ZERO
        for x in range(1, 5):
            g = add(g, ZPOW[(5*m*logs[x]+4*x) % 20])
        gs.append(g)
    assert gs[0] == scalar(ONE, -1)
    # At fourth roots of unity, D has a root only at 1, with multiplicity s0.
    cases = {2: ([2]*4, [1]*8, 4),
             3: ([2, 2, 3], [1]*7, 3),
             6: ([2, 6], [1]*5+[3], 2)}
    expected = {2: (3, -2), 3: (13, 18), 6: (-9, -14)}
    for n, (ps, qs, s0) in cases.items():
        M = F(1)
        for a in ps:
            M *= a**a
        for b in qs:
            M /= b**b
        modM = M.numerator*pow(M.denominator, -1, 5) % 5
        arg = (-1)**sum(qs)*pow(modM, -1, 5) % 5
        total = ZERO
        for m in range(4):
            term = ONE
            for a in ps:
                term = mul(term, gs[(a*m) % 4])
            for b in qs:
                term = mul(term, gs[(-b*m) % 4])
            sm = s0 if m == 0 else 0
            term = scalar(term, F(1, 5**(s0-sm)))
            term = mul(term, ZPOW[(5*m*logs[arg]) % 20])
            total = add(total, term)
        total = scalar(total, F((-1)**(len(ps)+len(qs)), 1-5))
        assert all(x == 0 for x in total[1:])
        H = total[0]
        chi = -1 if n == 3 else 1  # (3/5)=-1 for n=3; trivial for n=2,6.
        ap = H-5*chi
        assert (H, ap) == expected[n]
        result[n] = (H, ap)
    return result


if __name__ == '__main__':
    for n, (H, ap) in compute_values().items():
        print(f'n={n}: exact H_5={H}, a_5={ap}; PASS')
