NEW INDEPENDENT EXACT CUBIC CERTIFICATE CHECK
29 October 2026 (India)

Purpose and status
------------------
This is a newly written reference implementation of the finite arithmetic in
the cubic second-moment comparison. It was executed successfully in this
revision-preparation session. It does not import, copy, or execute the archived
research programs. The historical certificate JSON is read only after every
new field/moment/eta calculation, for an output comparison.

"Independent" here means a separate implementation from the archived code.
It is not an independent human referee report, formal proof verification,
or certification of literature priority. The implementation and this review
were AI-assisted. The mathematical hypotheses of the geometric construction
and the quoted modularity theorems require their own checking.

Files
-----
independent_cubic_exact.py
    Complete new implementation, Python standard library only.
independent_cubic_exact_results.json
    Newly computed exact moments, traces, determinants, character choices,
    eta coefficients, all Sturm rows, sanity-check coverage, and source hashes.
independent_cubic_exact_run.log
    Console output of the successful run. This is a new log, not an old PASS.
equations_used.tex
    Frozen manuscript section used for the input formulas. It describes the
    earlier carried-certificate status and is retained only as an equation
    source snapshot. Consult the current main manuscript for current status.

Dependencies and command
------------------------
Python 3.8 or later; no NumPy, SciPy, mpmath, Sage, or other package required.
From this directory, to compute again into a fresh directory:

    python3 independent_cubic_exact.py --source equations_used.tex --output-dir new_run

The --expected option is optional. If the package places this directory at
release/independent_verification/ and retains the old certificate at the
standard consolidated path, an additional historical comparison is:

    python3 independent_cubic_exact.py --source equations_used.tex --expected ../../supplement/cubic_certificate/certificate/exact_livne_certificate.json --output-dir new_run

Adjust that comparison-only path if the package layout differs. Without
--expected the calculation still checks trace=independently computed eta
coefficient, determinant=p^3, Sturm congruence, and square-class coverage.
Any failed mathematical check raises an error and the process exits nonzero.
The script records its own SHA256 and the optional source/comparison hashes.
It refuses to overwrite an existing result JSON; choose a fresh --output-dir
for each rerun. Each generated JSON records its actual run-start timestamp
in UTC and its corresponding India calendar date (UTC+05:30). These are run
provenance, separate from the editorial date of this document.

Exact arithmetic and character convention
----------------------------------------
For each p in {7,13,19,37,73}, choose the least primitive root g and set
rho(g^k)=zeta_3^(k mod 3). Character sums are pairs of Python integers in
the basis (1,zeta_3), with zeta_3^2=-1-zeta_3. All final moments have second
coordinate zero. The conjugate character therefore gives the same moment.

For F_(p^2), take s^2=d for the least quadratic nonsquare d and write x=a+b*s.
The quadratic character is Legendre(a^2-d*b^2,p), and the cubic character
is rho(Norm(x)). Traces use the exact direct sum

    a_q(lambda) = -sum_x chi_q(x) chi_q(x-1) chi_q(x-lambda).

List rotations implement subtraction on the additive coordinate grid.
They do not approximate a convolution and are not FFTs. Python integers are
arbitrary precision, so there is no fixed-width overflow bound or rounding
tolerance. The largest field has 73^2=5329 elements. Timing uses ordinary
wall-clock floating point only for reporting; no mathematical calculation
uses floating-point arithmetic.

The eta quotient is constructed independently as an integer power series:

    f36 = eta(6z)^14 / (eta(2z)^3 eta(18z)^3)
          - 3 eta(2z)^3 eta(6z)^2 eta(18z)^3.

Each (1-q^m) factor uses descending coefficient updates; each inverse uses
ascending updates. The q shifts are respectively 1 and 3. Coefficients are
computed through73, and f36-eta(3z)^8 is checked modulo2 through24 inclusive.
Identifying these expressions as the required modular forms, and justifying
24 as the applicable Sturm bound, are mathematical inputs rather than things
proved by this program.

Results
-------
 p   M2(Fp)   M2(Fp2)   trace t   det=(t^2-u)/2   a_f(p)
 7      -16        572          8              343          8
13       -4       4124        -10             2197        -10
19       80       3356       -100             6859       -100
37      188      48860       -226            50653       -226
73     -100     772028         26           389017         26

Here t=-M2(Fp)-p-1 and u=-M2(Fp2)-p^2-1. The seven prime-ideal rows use
(p,r)=(7,2),(7,5),(13,6),(19,4),(19,15),(37,16),(73,17), with r^2=-3.
Their bits in the order (sqrt(-3),2,-1) are
001,101,110,011,111,010,100: all seven nonzero vectors.

Sanity checks beyond historical-output agreement
-----------------------------------------------
- Hasse bound and full rational 2-torsion mod4 for every smooth fibre counted.
- a_(p^2)(lambda)=a_p(lambda)^2-2p at every lambda in Fp excluding0,1.
- Equal traces for all Frobenius-conjugate fibres over F_(p^2).
- For p=7, every one of the47 smooth F49 fibres is also counted by a separate
  explicit multiplication of x(x-1)(x-lambda) in F49, without grid shifts.
- The simple E_2(F7) trace is0, hence it has8 points.
- Eta qseries starts q+..., and all25 coefficients from0 through24 satisfy
  the stated mod2 congruence.

Limits
------
This bounded exact check verifies the numerical inputs of the displayed
cubic certificate and supplies a reproducible alternative implementation.
It does not establish the geometric representation, specialization,
ramification, determinant character, or any other Livne/Sturm hypothesis
that is not a finite arithmetic check. It does not test quartic/sextic
certificates, rank-four traces, the historical large FFT tables, bad factors,
conductors, functional equations, special values, novelty, or BSD.
No all-prime conclusion follows from these rows alone without the stated
mathematical comparison argument and all of its hypotheses.
