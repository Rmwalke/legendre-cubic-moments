#!/usr/bin/env python3
"""Fresh exact cubic Legendre certificate calculation; Python standard library only.

No archived research program is imported or executed. All finite-field sums
below use arbitrary-precision Python integers, without FFTs or floating point.
An optional historical JSON is read only AFTER the new calculation, to compare
outputs. This program does not certify geometric hypotheses or novelty.
"""

import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import itertools
import json
from pathlib import Path
import platform
import time


PRIMES = (7, 13, 19, 37, 73)
PRIME_IDEALS = ((7, 2), (7, 5), (13, 6), (19, 4), (19, 15), (37, 16), (73, 17))


def require(condition, message):
    if not condition:
        raise ArithmeticError(message)


def quadratic(a, p):
    a %= p
    if a == 0:
        return 0
    value = pow(a, (p - 1) // 2, p)
    require(value in (1, p - 1), "p must be an odd prime")
    return 1 if value == 1 else -1


def prime_factors(n):
    result = []
    d = 2
    while d * d <= n:
        if n % d == 0:
            result.append(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        result.append(n)
    return result


def primitive_root(p):
    factors = prime_factors(p - 1)
    return next(g for g in range(2, p) if all(pow(g, (p - 1) // d, p) != 1 for d in factors))


def cubic_exponents(p):
    """rho(g^k)=zeta_3^k; None at zero, where the character is zero."""
    require((p - 1) % 3 == 0, "split prime required")
    g = primitive_root(p)
    exponents = [None] * p
    value = 1
    for k in range(p - 1):
        require(exponents[value] is None, "primitive-root orbit repeated")
        exponents[value] = k % 3
        value = value * g % p
    require(value == 1 and all(x is not None for x in exponents[1:]), "incomplete character")
    return g, exponents


def eisenstein_sum(trace_character_pairs):
    """Return M in the exact basis (1,zeta_3), using zeta_3^2=-1-zeta_3."""
    buckets = [0, 0, 0]
    for trace, exponent in trace_character_pairs:
        require(exponent in (0, 1, 2), "nonzero character expected")
        buckets[exponent] += trace * trace
    return (buckets[0] - buckets[2], buckets[1] - buckets[2]), buckets


def fp_traces(p):
    traces = {}
    for lam in range(2, p):
        trace = -sum(quadratic(x * (x - 1) * (x - lam), p) for x in range(p))
        require(trace * trace <= 4 * p, "Fp Hasse bound failed")
        require((p + 1 - trace) % 4 == 0, "Fp full 2-torsion check failed")
        traces[lam] = trace
    return traces


def fp2_traces(p, rational_traces):
    """Exact traces over Fp[s]/(s^2-d), indexed by lambda=(a,b)=a+b*s.

    chi_{p^2}(a+b*s)=chi_p(a^2-d*b^2), by the field norm. Multiplicativity
    gives a(lambda)=-sum_x chi(x)chi(x-1)chi(x-lambda). The implementation
    sums this character product directly on the additive p-by-p grid.
    Precomputed list rotations merely index x-lambda; they are not an FFT.
    """
    d = next(n for n in range(2, p) if quadratic(n, p) == -1)
    chi = [[quadratic(a * a - d * b * b, p) for b in range(p)] for a in range(p)]
    fixed = [[chi[a][b] * chi[(a - 1) % p][b] for b in range(p)] for a in range(p)]
    shifted = [[row[-v:] + row[:-v] if v else row[:] for v in range(p)] for row in chi]
    traces = {}
    for u in range(p):
        for v in range(p):
            if v == 0 and u in (0, 1):
                continue
            trace = -sum(
                sum(x * y for x, y in zip(fixed[a], shifted[(a - u) % p][v]))
                for a in range(p)
            )
            require(trace * trace <= 4 * p * p, "Fp2 Hasse bound failed")
            require((p * p + 1 - trace) % 4 == 0, "Fp2 full 2-torsion check failed")
            traces[(u, v)] = trace
    for lam, trace in rational_traces.items():
        require(traces[(lam, 0)] == trace * trace - 2 * p, "quadratic base-change check failed")
    for (a, b), trace in traces.items():
        require(traces[(a, (-b) % p)] == trace, "Frobenius-conjugate fibre traces differ")
    return d, traces


def naive_extension_trace(p, d, lam):
    """Independent small-field check: multiply x(x-1)(x-lambda) explicitly."""
    def mul(x, y):
        return ((x[0] * y[0] + d * x[1] * y[1]) % p, (x[0] * y[1] + x[1] * y[0]) % p)
    total = 0
    for a in range(p):
        for b in range(p):
            value = mul(mul((a, b), ((a - 1) % p, b)), ((a - lam[0]) % p, (b - lam[1]) % p))
            total += quadratic(value[0] * value[0] - d * value[1] * value[1], p)
    return -total


def eta_product(exponents, bound):
    """Integer coefficients of product_d eta(d*z)^exponents[d] through bound.

    Multiplication by (1-q^m) uses descending updates; its inverse uses
    ascending updates. Repeating implements positive or negative powers.
    """
    shift24 = sum(d * exponent for d, exponent in exponents.items())
    require(shift24 % 24 == 0 and shift24 >= 0, "integral nonnegative q shift required")
    shift = shift24 // 24
    if shift > bound:
        return [0] * (bound + 1)
    limit = bound - shift
    coeffs = [1] + [0] * limit
    for d, exponent in sorted(exponents.items()):
        for step in range(d, limit + 1, d):
            if exponent >= 0:
                for _ in range(exponent):
                    for n in range(limit, step - 1, -1):
                        coeffs[n] -= coeffs[n - step]
            else:
                for _ in range(-exponent):
                    for n in range(step, limit + 1):
                        coeffs[n] += coeffs[n - step]
    return [0] * shift + coeffs


def file_sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected", type=Path, help="optional historical certificate JSON, read only after calculation")
    parser.add_argument("--source", type=Path, help="manuscript equation source to hash for provenance")
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    destination = args.output_dir / "independent_cubic_exact_results.json"
    if destination.exists():
        parser.error(f"refusing to overwrite existing result: {destination}; choose a fresh --output-dir")
    created_utc = datetime.now(timezone.utc)
    start = time.monotonic()
    records = {}
    first = eta_product({6: 14, 2: -3, 18: -3}, 73)
    second = eta_product({2: 3, 6: 2, 18: 3}, 73)
    form = [a - 3 * b for a, b in zip(first, second)]
    comparison = eta_product({3: 8}, 24)
    sturm_rows = [{"n": n, "f36": form[n], "eta3_power8": comparison[n], "difference_mod2": (form[n] - comparison[n]) % 2} for n in range(25)]
    require(all(row["difference_mod2"] == 0 for row in sturm_rows), "Sturm finite check failed")
    require(form[0] == 0 and form[1] == 1, "normalized cusp q-series check failed")
    print("Integer eta-series calculation: normalized; all coefficients through Sturm bound24 agree modulo2.", flush=True)

    for p in PRIMES:
        g, character = cubic_exponents(p)
        rational = fp_traces(p)
        fp_moment, fp_buckets = eisenstein_sum((t, character[lam]) for lam, t in rational.items())
        d, extension = fp2_traces(p, rational)
        fp2_moment, fp2_buckets = eisenstein_sum((t, character[(a * a - d * b * b) % p]) for (a, b), t in extension.items())
        require(fp_moment[1] == 0 and fp2_moment[1] == 0, "moment is not rational")
        t = -fp_moment[0] - p - 1
        u = -fp2_moment[0] - p * p - 1
        require((t * t - u) % 2 == 0, "determinant numerator is odd")
        determinant = (t * t - u) // 2
        require(t == form[p], "moment trace differs from independent eta coefficient")
        require(determinant == p ** 3, "determinant differs from p^3")
        if p == 7:
            require(rational[2] == 0, "hand-check E_2(F7) should have8 points")
            for lam, trace in extension.items():
                require(naive_extension_trace(p, d, lam) == trace, "explicit multiplication disagrees with grid sum")
        trace_payload = [{"a": a, "b": b, "trace": tr} for (a, b), tr in sorted(extension.items())]
        trace_bytes = json.dumps(trace_payload, sort_keys=True, separators=(",", ":")).encode()
        records[p] = {
            "p": p, "primitive_root": g, "extension_nonsquare_d": d,
            "M2_Fp_pair": fp_moment, "M2_Fp2_pair": fp2_moment,
            "Fp_character_buckets": fp_buckets, "Fp2_character_buckets": fp2_buckets,
            "trace": t, "trace_square": u, "eta_coefficient": form[p], "determinant": determinant,
            "rational_fibres_checked": p - 2, "extension_fibres_counted": p * p - 2,
            "fp2_trace_table_sha256": hashlib.sha256(trace_bytes).hexdigest(),
            "sanity_checks": ["Hasse bound for every smooth fibre", "full rational2-torsion mod4 for every smooth fibre", "a_p2(lambda)=a_p(lambda)^2-2p for every rational smooth lambda", "Frobenius conjugation for every extension fibre"] + (["all47 F49 traces checked by independent explicit field multiplication", "E_2(F7) has8 points"] if p == 7 else [])
        }
        print(f"p={p}: M2(Fp)={fp_moment}; M2(Fp2)={fp2_moment}; trace={t}; eta={form[p]}; det={determinant}=p^3; PASS", flush=True)

    rows = []
    for p, root in PRIME_IDEALS:
        require(root * root % p == (-3) % p, "root does not represent sqrt(-3)")
        bits = "".join("0" if quadratic(x, p) == 1 else "1" for x in (root, 2, -1))
        row = {"p": p, "root": root, "bits_sqrtm3_2_m1": bits,
               "M2_Fp": records[p]["M2_Fp_pair"][0], "M2_Fp2": records[p]["M2_Fp2_pair"][0],
               "trace": records[p]["trace"], "target_eta": records[p]["eta_coefficient"], "det": records[p]["determinant"]}
        rows.append(row)
    require({row["bits_sqrtm3_2_m1"] for row in rows} == {"".join(bits) for bits in itertools.product("01", repeat=3)} - {"000"}, "seven nonzero vectors not covered")
    print("Seven prime-ideal rows: square-class vectors cover all nonzero elements of F2^3; PASS", flush=True)

    historical = {"performed": False}
    if args.expected:
        # This is deliberately after all finite-field and eta computations.
        expected = json.loads(args.expected.read_text())["cases"]["3"]
        lookup = {(row["p"], row["root"]): row for row in expected}
        require(set(lookup) == set(PRIME_IDEALS), "historical prime ideals differ")
        for row in rows:
            old = lookup[(row["p"], row["root"])]
            for field in ("M2_Fp", "M2_Fp2", "trace", "det"):
                require(row[field] == old[field], f"historical disagreement in {field}")
            require(row["target_eta"] == old["target"], "historical eta target disagreement")
            require(row["bits_sqrtm3_2_m1"] == old["bits"], "historical bit disagreement")
        historical = {"performed": True, "source_name": args.expected.name, "sha256": file_sha256(args.expected), "rows_matched": len(rows)}
        print("Post-computation comparison with historical cubic JSON: all7rows match; PASS", flush=True)

    result = {
        "status": "PASS", "scope": "new independent bounded exact arithmetic check; no archived research program executed",
        "run_date_asia_kolkata": created_utc.astimezone(timezone(timedelta(hours=5, minutes=30))).date().isoformat(),
        "run_timestamp_utc": created_utc.isoformat(),
        "python_version": platform.python_version(), "dependencies": "Python standard library only",
        "script_sha256": file_sha256(__file__), "elapsed_seconds": round(time.monotonic() - start, 3),
        "arithmetic": "arbitrary-precision Python integers; Eisenstein pair basis(1,zeta3); no FFT or floating-point arithmetic in any mathematical calculation",
        "character": "rho(g^k)=zeta3^(k mod3); over Fp2 use rho composed with Norm_Fp2/Fp",
        "rows": rows, "prime_details": list(records.values()),
        "form_coefficients_through73": form, "sturm_bound": 24, "sturm_rows": sturm_rows,
        "historical_comparison": historical,
        "not_verified": ["geometric construction/specialization/descent", "identification of eta expression as the stated newform", "hypotheses of Sturm or Livne theorems beyond their displayed finite arithmetic", "quartic or sextic certificates", "rank-four traces or bad local factors", "large historical FFT tables or functional equations", "novelty, journal suitability, or any BSD conclusion"]
    }
    if args.source:
        result["manuscript_equation_source"] = {"name": args.source.name, "sha256": file_sha256(args.source)}
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    print(f"Saved {destination.name}; total elapsed {result['elapsed_seconds']}s.", flush=True)


if __name__ == "__main__":
    run()
