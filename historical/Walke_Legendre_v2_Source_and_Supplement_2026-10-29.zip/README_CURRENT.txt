CURRENT VERSION2 SOURCE AND COMPUTATIONAL SUPPLEMENT

Read current_review/CURRENT_STATUS.json and CURRENT_CLAIM_LEDGER.json first.
manuscript/ is the authoritative current TeX source for the accompanying PDF.

historical_supplement/, historical_release/ and historical_N_stage/ preserve
the supplied earlier files byte-for-byte, including success/failure logs and
older proof-obligation/metadata worksheets. Their earlier statuses, titles, dates and publication instructions are historical. They do not override the
current manuscript, current_review, or the current metadata supplied separately.

The retained standalone exact cubic verifier and its earlier run are under
historical_release/independent_verification/. Original certificate dependencies
are under historical_supplement/cubic_certificate/certificate/.
The N11/N12 period-sign sources referenced in AppendixC are in historical_N_stage/.
No experiment was rerun during this version2 integration. Hash equality records
preservation; it does not independently certify the mathematics or numerical data.

Rights/provenance: materials retain their supplied provenance and applicable
rights. No new software-license grant is made here. The publication metadata
worksheet records the historical v1 CC BY4.0 field for author verification.
