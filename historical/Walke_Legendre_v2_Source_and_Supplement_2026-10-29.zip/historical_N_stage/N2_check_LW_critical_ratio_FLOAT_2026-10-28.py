"""N2 (FLOAT, high precision with Python's built-in `decimal`) — Deligne ratio test for L(W, s):
        R := L(W, 5) / (pi^4 * L(W, 3)).
 Version 3 (28 Oct 2026): run 1 of v2 failed control CB (fixed step h too coarse for x ~ 160); v3 adapts h to x
 (see _level). Criteria unchanged.
 Version 2 (28 Oct 2026): mpmath was NOT available (PyPI blocked in the session), so the high-precision layer is
 written here with `decimal` only: pi (Machin), K_0/K_1 (trapezoid rule for int_0^inf e^{-x cosh t} cosh(nu t) dt,
 which converges exponentially), incomplete Gamma for integer s (closed form), and integer-relation search by
 continued fractions + an independent 2-D lattice (Lagrange/LLL) reduction. Needs only numpy (for the L1 FFT).

 W: degree 4, weight 5, Hodge {0,0,5,5}, N = 1296, eps = +1, Gamma_C(s)^2, Euler factors at 2 and 3 equal to 1 (L2/L3/L5).
 Deligne [known conjecture; applying it to W: conjecture]: L(W, m) ~ (2 pi i)^(2m) c^{(-1)^m}(W) mod Q^*, so for
 m = 3, 5 (same parity, same period c^-):  R in Q.

 a_n (exact integers): split p from the H13 laptop data (s1, s2), inert p by the L1 twisted-Lefschetz trace (k = 4),
   c2 = (c1^2 - u)/2, mu = +p^5, descent '-' (= L2 coeffs(-1)). Re-implemented here; no other script is exec'd.
 L-values WITHOUT quadrature in t (closed form, integer s only):
   Lambda(s) = sum_n a_n [ G(s; c_n, t0) + eps * G(k - s; c_n, 1/t0) ],  c_n = n / sqrt(N),  k = 6.
   degree 4:  Lambda(s) = N^(s/2) (2pi)^(-2s) Gamma(s)^2 L(s),  theta(t) = sum a_n 2 K_0(4 pi sqrt(c_n t)),
     G(s; c, t0) = 4 (16 pi^2)^(-s) c^(-s) I_{s-1}(Y),  Y = 4 pi sqrt(c t0),  I_m(Y) = int_Y^inf y^(2m+1) K_0(y) dy,
     I_0 = Y K_1(Y),   I_m = Y^(2m+1) K_1(Y) + 2m Y^(2m) K_0(Y) + 4 m^2 I_{m-1}   (integration by parts).
   degree 2:  Lambda(s) = N^(s/2) (2pi)^(-s) Gamma(s) L(s),  G(s; c, t0) = (2 pi c)^(-s) Gamma(s, 2 pi c t0),
     Gamma(s, z) = (s-1)! e^(-z) sum_{j<s} z^j / j!.
 Independence of the split point t0 (1 vs 1.1) is a high-precision check of the functional equation itself.

 PASS/FAIL fixed BEFORE running (N1 notes, R2):
  CB  Bessel layer: trapezoid K_{1/2}, K_{3/2} equal sqrt(pi/2x) e^-x (1, 1 + 1/x) to >= dps - 3 digits at
      x = 0.5, 2, 20, 160; K_0(1), K_1(1), K_0(2), K_1(2) equal the Abramowitz-Stegun 10-digit values.
  C0  every object: with the chosen eps, Lambda(s; t0=1) = Lambda(s; t0=1.1) at s = 4, 5 to >= 30 digits; the other eps
      must disagree (< 10 digits).
  C1  f = 4.6.a.a = eta(2z)^12 (degree 2): R_f = L(f,5)/(pi^2 L(f,3)) is p/q, q <= 1e6, >= 30 digits, CF and lattice agree.
  C2  g = L(f) * L(f x chi_5) as ONE degree-4 Dirichlet series (N = 4 * 100 = 400) through the SAME code path as W:
      (a) L_g(s) = L_f(s) L_{f chi}(s) at s = 3, 4, 5 to >= 30 digits;  (b) R_g = L_g(5)/(pi^4 L_g(3)) rational as in C1
      (R_g or sqrt(3) R_g).
      CHANGE vs N1 (decided before running): N1 proposed chi_{-3}. But chi_{-3} is odd, so
      eps(f x chi_{-3}) = eps(f) chi_{-3}(4) tau(chi)^2 / 3 = -eps(f) = -1 and L(f x chi_{-3}, 3) = 0 identically, which
      makes the ratio meaningless. The even character chi_5 (5 coprime to 4) gives eps = +1. Hodge {0,0,5,5} is unchanged.
  C3  L(W, 3) agrees with the L4 FLOAT value 2.2413552032 to 1e-9.
  W   PASS iff CB, C0-C3 PASS and R or sqrt(3) R is p/q with q <= 1e6, >= 30 digits, CF and lattice agree, the SAME p/q
      at dps = 40 and dps = 60 and with n <= 4000 vs n <= 4999.  Otherwise FAIL (best convergents printed; no claim).
  A PASS stays [numerical], not [proved].

Usage (offline, no network):  python -I N2_check_LW_critical_ratio_FLOAT_2026-10-28.py H13_output_data_laptop_p_upto_4999.txt
Needs: numpy.  Expected run time: a few minutes.
"""
import sys, math, time
from decimal import Decimal as D, getcontext, ROUND_FLOOR
from fractions import Fraction
import numpy as np

T_START = time.time()
DPS_LIST = (40, 60)
GUARD = 12
MAXDEN = 10 ** 6
NEED_DIGITS = 30
K_WT = 6
T0_ALT = D('1.1')

# ================================================================ high-precision layer (decimal only)
HP = {}
def set_dps(dps):
    getcontext().prec = dps + GUARD
    P = dps + GUARD
    scale = 10 ** (P + 10)
    def atan_inv(x):
        total = term = scale // x; x2 = x * x; k = 1; sg = 1
        while term:
            term //= x2; k += 2; sg = -sg; total += sg * (term // k)
        return total
    HP['pi'] = D(16 * atan_inv(5) - 4 * atan_inv(239)) / D(scale)
    HP['dps'] = dps
    # trapezoid step for int_R e^{-x cosh t}: error ~ exp(-pi^2 / h); take margin 1.15
    HP['h'] = D(math.pi ** 2 / (1.15 * (P + 5) * math.log(10)))
    HP['logtarget'] = D((P + 5) * math.log(10))
    HP['P'] = P
    HP['nodes'] = {}                                  # (nu2, k) -> list of (cosh(t_j), cosh(nu t_j)), step h / 2^k
    HP['kcache'] = {}
def _nodes(nu2, k):                                   # nu = nu2 / 2 ; nodes up to t = 12 (enough for x >= 1e-3)
    if (nu2, k) not in HP['nodes']:
        h = HP['h'] / 2 ** k; out = []; j = 0
        while True:
            t = h * j
            if t > 12: break
            et = t.exp(); c = (et + 1 / et) / 2
            en = (t * nu2 / 2).exp(); cn = (en + 1 / en) / 2
            out.append((c, cn)); j += 1
        HP['nodes'][(nu2, k)] = out
    return HP['nodes'][(nu2, k)]
def _level(x):
    """v3 fix (after run 1, CB FAIL at x = 160): for large x the peak of e^{-x cosh t} has width ~ x^{-1/2}. The
    relative trapezoid error is ~ exp(x a^2 / 2 - 2 pi a / h) (strip width a), minimal value exp(-2 pi^2 / (h^2 x)),
    so also require h <= 0.8 pi sqrt(2 / (x (P+5) ln 10)). Halve h until both bounds hold."""
    hx = 0.8 * math.pi * math.sqrt(2 / (float(x) * (HP['P'] + 5) * math.log(10)))
    k = 0
    while float(HP['h']) / 2 ** k > hx: k += 1
    return k
def besselK(nu2, x):
    """K_{nu2/2}(x) = int_0^inf e^{-x cosh t} cosh(nu t) dt, trapezoid (exponentially convergent), x > 0."""
    k = _level(x); h = HP['h'] / 2 ** k; tgt = HP['logtarget']; nodes = _nodes(nu2, k)
    ex = (-x).exp()
    s = ex / 2                                         # j = 0: cosh = 1, weight 1/2
    for c, cn in nodes[1:]:
        arg = x * (c - 1)
        if arg > tgt: break
        s += (-(x * c)).exp() * cn
    else:
        raise RuntimeError('Bessel node range too short for x = %s' % x)
    return h * s
def k01(x):
    return besselK(0, x), besselK(2, x)
def digits(x, y):
    if x == y: return HP['dps']
    m = max(abs(x), abs(y))
    if m == 0: return HP['dps']
    return float(-((abs(x - y) / m).log10()))
def nstr(x, k): return format(x, f'.{k}g')

# ================================================================ W coefficients (L1 / L2 method, exact integers)
def is_prime(n): return n > 1 and all(n % d for d in range(2, math.isqrt(n) + 1))
def chi_table(p):
    c = np.full(p, -1, dtype=np.int64); c[0] = 0; c[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1; return c
def fp2_pow(A, B, e, p, nr):
    RA = np.ones_like(A); RB = np.zeros_like(B); XA, XB = A.copy(), B.copy()
    while e:
        if e & 1: RA, RB = (RA * XA + nr * RB * XB) % p, (RA * XB + RB * XA) % p
        XA, XB = (XA * XA + nr * XB * XB) % p, (2 * XA * XB) % p
        e >>= 1
    return RA, RB
def twisted_data(p):          # copied from L1 (same algorithm), plus a rounding-residual check
    chi = chi_table(p); nr = next(x for x in range(2, p) if chi[x] == -1)
    X = np.arange(p)
    g = chi[(X * X - nr) % p].astype(float); c = chi.astype(float)
    corr = np.fft.ifft(np.fft.fft(c) * np.conj(np.fft.fft(g))).real
    assert np.max(np.abs(corr - np.rint(corr))) < 1e-6, ('FFT rounding', p)
    ap = -np.rint(corr).astype(np.int64)
    assert np.all(np.abs(ap) <= 2 * math.sqrt(p) + 1e-9) and np.all(ap % 2 == 0)
    RA, RB = fp2_pow(X.astype(np.int64), np.ones(p, dtype=np.int64), (p * p - 1) // 3, p, nr)
    keys = RA * p + RB; one = p
    others = sorted(set(keys.tolist()) - {one})
    cls = np.zeros(p, dtype=np.int64)
    if len(others) >= 1: cls[keys == others[0]] = 1
    if len(others) == 2: cls[keys == others[1]] = 2
    return ap, cls
def re_sum(vals, cls):
    S = [int(sum(int(v) for v in vals[cls == j])) for j in range(3)]
    assert S[1] == S[2], S
    return S[0] - S[1]

def euler_to_dirichlet(euler, nmax, bad=(2, 3)):
    """euler[p] = (c1, c2, c3, c4): P_p(T) = 1 - c1 T + c2 T^2 - c3 T^3 + c4 T^4. Exact integers."""
    pk = {}
    for p, (c1, c2, c3, c4) in euler.items():
        b = [1]; k = 1
        while p ** k <= nmax:
            v = c1 * b[k - 1] - (c2 * b[k - 2] if k >= 2 else 0) + (c3 * b[k - 3] if k >= 3 else 0) - (c4 * b[k - 4] if k >= 4 else 0)
            b.append(v); k += 1
        pk[p] = b
    A = [0] * (nmax + 1); A[1] = 1
    for n in range(2, nmax + 1):
        m = n; p = next(d for d in range(2, n + 1) if m % d == 0); k = 0
        while m % p == 0: m //= p; k += 1
        A[n] = 0 if p in bad else A[m] * pk[p][k]
    return A

def w_coefficients(path):
    data = {}
    for l in open(path, encoding='utf-8'):
        if l.startswith('#') or not l.strip(): continue
        t = l.split(); data[int(t[0])] = t
    nmax = max(data)
    euler = {}; weil_bad = []
    for p in sorted(data):
        t = data[p]; mu = p ** 5
        if t[1] == 'split':
            c1, c2 = int(t[2]), int(t[3])
        else:
            u = int(t[2]); ap, cls = twisted_data(p)
            c1 = -re_sum(ap ** 4 - 3 * p * ap ** 2 + p * p, cls) - 1
            assert (c1 * c1 - u) % 2 == 0
            c2 = (c1 * c1 - u) // 2
            c1 = -c1                                   # descent '-' (twist by chi_{-3}; chi_{-3}(p) = -1)
        r = np.roots([1, -c1, c2, -mu * c1, mu * mu])  # Weil check, every prime
        if max(abs(abs(z) / p ** 2.5 - 1) for z in r) > 1e-6: weil_bad.append(p)
        euler[p] = (c1, c2, mu * c1, mu * mu)
    A = euler_to_dirichlet(euler, nmax)
    return A, nmax, weil_bad

# ================================================================ control f = eta(2z)^12 = 4.6.a.a
def f_coefficients(nmax):
    M = nmax // 2 + 1
    P = [0] * (M + 1)                                  # prod (1 - x^n), pentagonal theorem
    k = 0
    while True:
        e1, e2 = k * (3 * k - 1) // 2, k * (3 * k + 1) // 2
        if e1 > M: break
        sg = -1 if k % 2 else 1
        P[e1] += sg
        if k and e2 <= M: P[e2] += sg
        k += 1
    def mul(a, b):
        out = [0] * (M + 1)
        nzb = [(j, bj) for j, bj in enumerate(b) if bj]
        for i, ai in enumerate(a):
            if ai:
                for j, bj in nzb:
                    if i + j > M: break
                    out[i + j] += ai * bj
        return out
    P2 = mul(P, P); P4 = mul(P2, P2); P8 = mul(P4, P4); P12 = mul(P8, P4)
    A = [0] * (nmax + 1)
    for j in range(M + 1):
        if 2 * j + 1 <= nmax: A[2 * j + 1] = P12[j]
    return A
def chi_5(n): return (0, 1, -1, -1, 1)[n % 5]      # Legendre symbol (n/5), even, conductor 5

# ================================================================ Lambda / L in closed form
def kpair(n, N, t0):
    key = (n, N, str(t0))
    kc = HP['kcache']
    if key not in kc:
        Y = 4 * HP['pi'] * (D(n) / D(N).sqrt() * t0).sqrt()
        K0, K1 = k01(Y)
        kc[key] = (Y, K0, K1)
    return kc[key]
def G4(s, n, N, t0):
    Y, K0, K1 = kpair(n, N, t0)
    I = Y * K1
    for m in range(1, s):
        I = Y ** (2 * m + 1) * K1 + 2 * m * Y ** (2 * m) * K0 + 4 * m * m * I
    c = D(n) / D(N).sqrt()
    return 4 * (16 * HP['pi'] ** 2) ** (-s) * c ** (-s) * I
def upper_gamma_int(s, z):
    term = D(1); tot = D(1)
    for j in range(1, s):
        term = term * z / j; tot += term
    return math.factorial(s - 1) * (-z).exp() * tot
def G2(s, n, N, t0):
    c = D(n) / D(N).sqrt()
    return (2 * HP['pi'] * c) ** (-s) * upper_gamma_int(s, 2 * HP['pi'] * c * t0)
def Lam(A, N, eps, s, deg, t0=D(1), nmax=None):
    G = G4 if deg == 4 else G2
    nmax = nmax or (len(A) - 1)
    tot = D(0); t1 = 1 / t0
    for n in range(1, nmax + 1):
        if A[n]: tot += A[n] * (G(s, n, N, t0) + eps * G(K_WT - s, n, N, t1))
    return tot
def L_of(A, N, eps, s, deg, t0=D(1), nmax=None):
    pi = HP['pi']; g = math.factorial(s - 1)
    gam = (2 * pi) ** (-2 * s) * g * g if deg == 4 else (2 * pi) ** (-s) * g
    return Lam(A, N, eps, s, deg, t0, nmax) / (D(N).sqrt() ** s * gam)

def pick_eps(A, N, deg, nmax=None):
    d = {}
    for e in (1, -1):
        d[e] = min(digits(Lam(A, N, e, s, deg, D(1), nmax), Lam(A, N, e, s, deg, T0_ALT, nmax)) for s in (4, 5))
    best = max(d, key=d.get)
    ok = d[best] >= NEED_DIGITS and d[-best] < 10
    return best, {k: round(v, 1) for k, v in d.items()}, ok

# ================================================================ rational recognition (two ways)
def cf_best(x, maxden=MAXDEN):
    h0, h1, k0, k1 = 0, 1, 1, 0; y = x; best = None
    for _ in range(300):
        a = int(y.to_integral_value(rounding=ROUND_FLOOR)); h0, h1 = h1, a * h1 + h0; k0, k1 = k1, a * k1 + k0
        if k1 > maxden: break
        best = (h1, k1, digits(x, D(h1) / D(k1)))
        fr = y - a
        if fr == 0: break
        y = 1 / fr
    return best
def lattice_rat(x, scale_digits=NEED_DIGITS + 5):
    """Shortest vector of the 2-D lattice spanned by (1, 0, X), (0, 1, S), X = round(x S): Lagrange reduction (= LLL in
    dimension 2) in exact integers. Returns -b/a for the shortest (a, b, aX + bS)."""
    S = 10 ** scale_digits; X = int((x * S).to_integral_value())
    u = [1, 0, X]; v = [0, 1, S]
    dot = lambda p, q: p[0] * q[0] + p[1] * q[1] + p[2] * q[2]
    if dot(u, u) < dot(v, v): u, v = v, u
    for _ in range(10000):
        nv = dot(v, v); mu = (2 * dot(u, v) + nv) // (2 * nv)
        u = [ui - mu * vi for ui, vi in zip(u, v)]
        if dot(u, u) >= nv: break
        u, v = v, u
    a, b = v[0], v[1]
    if a == 0: return None
    fr = Fraction(-b, a)
    return fr if fr.denominator <= MAXDEN else None
def recognise(x, label):
    out = {}
    for tag, y in (('R', x), ('sqrt3*R', x * D(3).sqrt())):
        cf = cf_best(y); lt = lattice_rat(y)
        ok = bool(cf and cf[2] >= NEED_DIGITS and lt is not None and lt.numerator == cf[0] and lt.denominator == cf[1])
        out[tag] = (ok, cf, lt)
        print(f'    {label} {tag}: CF best q<=1e6 -> {cf[0]}/{cf[1]} ({cf[2]:.1f} digits); lattice -> {lt}; {"RATIONAL" if ok else "no"}')
    return out
def factor(n):
    n = abs(n); f = []; d = 2
    while d * d <= n:
        while n % d == 0: f.append(d); n //= d
        d += 1
    if n > 1: f.append(n)
    return f

# ================================================================ main
path = sys.argv[1]
print('N2 v3 (decimal backend, adaptive Bessel step) — Deligne ratio test for L(W, s);  data:', path)
AW, NW_MAX, weil_bad = w_coefficients(path)
ap_L5 = {5: 36, 7: -32, 11: -72, 13: 28, 17: 2556, 19: -2504, 23: 720, 29: 3924, 31: -272, 37: 2284, 41: 10188,
         43: 4168, 47: -12096, 53: 10404, 59: 28152}
print(f'W: n <= {NW_MAX}; Weil failures: {weil_bad}; a_p (5..59) equal to the L5 table: {all(AW[p] == v for p, v in ap_L5.items())}')
assert not weil_bad and all(AW[p] == v for p, v in ap_L5.items())

NF = 3600                                             # N_g = 400: about 3000 terms for 60 digits
AF = f_coefficients(NF)
print('f = eta(2z)^12: a_1..a_9 =', AF[1:10])
assert AF[1:10] == [1, 0, -12, 0, 54, 0, -88, 0, -99]
AFC = [a * chi_5(n) for n, a in enumerate(AF)]
AG = [0] * (NF + 1)                                    # Dirichlet convolution L(f) L(f chi_5)
for d in range(1, NF + 1):
    if AF[d]:
        for e in range(1, NF // d + 1):
            if AFC[e]: AG[d * e] += AF[d] * AFC[e]
print(f'coefficients ready ({time.time() - T_START:.0f} s)')

verdict = {}
for dps in DPS_LIST:
    set_dps(dps)
    print(f'\n================ dps = {dps} ================')
    # CB : Bessel layer
    pi = HP['pi']
    cb = []
    for x in (D('0.5'), D(2), D(20), D(160)):
        ex = (pi / (2 * x)).sqrt() * (-x).exp()
        cb.append(min(digits(besselK(1, x), ex), digits(besselK(3, x), ex * (1 + 1 / x))))
    as10 = [(D(1), '0.4210244382', '0.6019072302'), (D(2), '0.1138938727', '0.1398658818')]
    as_ok = all(abs(besselK(0, x) - D(a)) < D('6e-11') and abs(besselK(2, x) - D(b)) < D('6e-11') for x, a, b in as10)
    okCB = min(cb) >= dps - 3 and as_ok
    print(f'CB Bessel: K_1/2, K_3/2 digits {[round(c, 1) for c in cb]}; A&S 10-digit values {as_ok} -> {okCB}')
    # C0 + C1 : f (N = 4) and f chi_5 (N = 100), degree 2
    epsF, dF, okF = pick_eps(AF[:401], 4, 2); epsFC, dFC, okFC = pick_eps(AFC[:401], 100, 2)
    print(f'C0 f: eps={epsF} {dF} {okF};  f chi_5: eps={epsFC} {dFC} {okFC}')
    Lf = {s: L_of(AF[:401], 4, epsF, s, 2) for s in (3, 4, 5)}
    Lfc = {s: L_of(AFC[:401], 100, epsFC, s, 2) for s in (3, 4, 5)}
    print('   L(f,3..5) =', [nstr(Lf[s], 25) for s in (3, 4, 5)])
    print('   L(f chi_5,3..5) =', [nstr(Lfc[s], 25) for s in (3, 4, 5)])
    Rf = Lf[5] / (pi ** 2 * Lf[3]); c1 = recognise(Rf, 'C1 R_f'); okC1 = c1['R'][0]
    Rfc = Lfc[5] / (pi ** 2 * Lfc[3]); recognise(Rfc, '   R_fchi5 (info)')
    # C2 : g, degree 4, N = 400, same path as W
    epsG, dG, okG = pick_eps(AG, 400, 4)
    print(f'C0 g: eps={epsG} {dG} {okG}   (expected eps_f * eps_fchi = {epsF * epsFC})  [{time.time() - T_START:.0f} s]')
    Lg = {s: L_of(AG, 400, epsG, s, 4) for s in (3, 4, 5)}
    dprod = {s: round(digits(Lg[s], Lf[s] * Lfc[s]), 1) for s in (3, 4, 5)}
    okC2a = min(dprod.values()) >= NEED_DIGITS; print('C2(a) digits L_g = L_f L_fchi:', dprod, okC2a)
    Rg = Lg[5] / (pi ** 4 * Lg[3]); c2 = recognise(Rg, 'C2 R_g'); okC2b = c2['R'][0] or c2['sqrt3*R'][0]
    # W
    epsW, dW, okW0 = pick_eps(AW, 1296, 4)
    print(f'C0 W: eps={epsW} {dW} {okW0}  [{time.time() - T_START:.0f} s]')
    LW = {s: L_of(AW, 1296, epsW, s, 4) for s in (3, 4, 5)}
    LW4000 = {s: L_of(AW, 1296, epsW, s, 4, nmax=4000) for s in (3, 5)}
    LWalt = {s: L_of(AW, 1296, epsW, s, 4, t0=T0_ALT) for s in (3, 5)}
    for s in (3, 4, 5): print(f'  L(W,{s}) = {nstr(LW[s], dps - 5)}')
    print('  digits n<=4000 vs 4999:', {s: round(digits(LW[s], LW4000[s]), 1) for s in (3, 5)},
          ' t0=1 vs 1.1:', {s: round(digits(LW[s], LWalt[s]), 1) for s in (3, 5)})
    okC3 = abs(LW[3] - D('2.2413552032')) < D('1e-9'); print('C3 L(W,3) vs L4 FLOAT:', okC3)
    R = LW[5] / (pi ** 4 * LW[3]); print('  R =', nstr(R, dps - 5))
    cw = recognise(R, 'W R'); R4000 = LW4000[5] / (pi ** 4 * LW4000[3]); cw4 = recognise(R4000, 'W R(n<=4000)')
    controls = okCB and okF and okFC and okC1 and okG and okC2a and okC2b and okW0 and okC3
    print('CONTROLS:', 'PASS' if controls else 'FAIL', {'CB': okCB, 'C0': okF and okFC and okG and okW0, 'C1': okC1,
          'C2a': okC2a, 'C2b': okC2b, 'C3': okC3})
    hit = None
    for tag in ('R', 'sqrt3*R'):
        if cw[tag][0] and cw4[tag][0] and cw[tag][1][:2] == cw4[tag][1][:2]: hit = (tag, cw[tag][1][:2])
    verdict[dps] = (controls, hit)

print('\n================ verdict ================')
same = len({v[1] for v in verdict.values()}) == 1
ctrl = all(v[0] for v in verdict.values())
hit = verdict[DPS_LIST[-1]][1]
if not ctrl:
    print('W ratio test: NOT EVALUATED (a control FAILED — fix the method first; no claim on W)')
elif hit and same:
    tag, (p, q) = hit
    print(f'W ratio test: PASS   {tag} = {p}/{q}   [numerical]   num factors {factor(p)}  den factors {factor(q)}')
else:
    print('W ratio test: FAIL (no p/q with q <= 1e6 stable in dps / n_max)', verdict)
print(f'run time {time.time() - T_START:.0f} s')
