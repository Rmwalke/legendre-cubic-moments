# GPT साठी handoff — BSD/Legendre प्रकल्प, संशोधन-भाग (28 ऑक्टोबर 2026, Claude कडून)

> **दादांनी GPT ला द्यायचा पहिला संदेश:**
> "सोबतचा zip फक्त वाचा. आधी `MASTER/00_NEW_CHAT_PROMPT_MR.md`, मग हा `N_next/02_GPT_HANDOFF_PROMPT_MR.md`, मग `N_next/01_PROGRESS_LOG_MR.md` चा शेवटचा भाग वाचा. परवानगीशिवाय काहीही चालवू नका. 'पुढचं काम' मधून सुरू करा."

## १ नियम (बंधनकारक; `MASTER/00_NEW_CHAT_PROMPT_MR.md` §2 प्रमाणे)
- दादांना "दादा" म्हणायचं. उत्तर मराठीत, गणिती शब्द इंग्रजीत. Be scientific: ना नकारात्मक, ना सकारात्मक.
- **प्रत्येक दाव्याला खूण:** [सिद्ध] [sketch] [संख्यात्मक] [अंदाज] [ज्ञात literature] [माहीत नाही].
- **PASS/FAIL निकष गणनेपूर्वी ठरवायचे.** FAIL आणि आपल्या चुका जपून ठेवायच्या (आजचे FAIL outputs zip मध्ये आहेत).
- **Exploration आणि confirmation वेगळे ठेवायचे:** exploration मध्ये सापडलेला संबंध कोणताही दावा नाही. तो नंतर वेगळ्या precision किंवा quadrature ने confirm करायचा.
- Literature तपासल्याशिवाय "नवीन" किंवा "breakthrough" हे शब्द नाहीत. ऑगस्टमध्ये असे दोन दावे नंतर ज्ञात निघाले (N6 पाहा).
- **नियम 8:** हा प्रकल्प इतर प्रकल्पांशी (Paley θ, LPS, Navier–Stokes "Gauss", पंचांग, Ulam, "claude gone mad") जोडायचा नाही.
- **जड गणना:** तुकड्या-तुकड्याने करायची, किंवा laptop साठी offline, resumable runner द्यायचा.
- **AI-assistance statement:** यापुढे GPT वापरलं, तर preprint v2 मध्ये त्याचाही उल्लेख करायचा.

## २ 28 ऑक्टोबरचे निकाल (या chat मध्ये; तपशील N3–N19 मध्ये)
| # | निकाल | खूण |
|---|---|---|
| N4 | L(W,5)/(π⁴L(W,3)) = 1/216 | [संख्यात्मक, 57 अंक] |
| N8 | Legendre curve, F_q(t^{1/d}): आपल्या point counts ने L = (1−qT)^{d−2} ⇒ rank d−2 (Ulmer चा BSD theorem) | [ज्ञात literature + संख्यात्मक] |
| N6 | कालक्रम: Legendre धागा 24–25 ऑगस्ट; नोंदी 28 ऑगस्ट 20:44 ला संपतात. V = 2(O²−E²) = a_p(16.3.c.a). D₂′ = D − 1 सिद्ध | [सिद्ध] / [ज्ञात] |
| N12 | Cubic-cover forms λ^e(1−λ)θ₃^{2k+4} हे **noncongruence** आहेत (unbounded 3-denominators); W हा Scholl representation चा descent असावा | [संख्यात्मक] / [sketch] |
| N11, N13, N18 | **L(W,3) = π⁴μ₊/2916, L(W,4) = π⁶μ_C(1,3)/157464, L(W,5) = π⁸μ₊/629856.** इथे μ = ∫₀¹(λ^c ± λ^{−c})F^jF(1−λ)^{4−j}dλ चे 2×2 determinants (c = 1/3, 2/3) | [संख्यात्मक, **110 अंक**] |
| N14, N15 | **W′ = W⊗χ₋₃: N = 432, ε = −1, P₃ = 1−3T ⇒ L(W′,3) = 0.** L(W′,4) आणि L(W′,5) त्याच determinants मधून (c⁺ ↔ c⁻ अदलाबदल, Deligne चा twist-नियम) | [संख्यात्मक, 110 अंक] |
| N16 | L′(W′,3) = 2.478248659786283973711631814697856615678111892355775339… ; periods चा rational गुणक नाही | [संख्यात्मक] |
| LMFDB | degree 4: conductor 432 ला "No matches"; 1296 मध्ये weight 5 चा एकच (36.6.b.a, वेगळा) | [database, 28 ऑक्टोबर 2026] |

## ३ उघडे प्रश्न / पुढचं काम (प्राधान्यक्रमाने)
1. **Bloch–Kato अर्थ (मुख्य):** 2916 = 2²3⁶, 157464 = 2³3⁹, 629856 = 2⁵3⁹, 69984 = 2⁵3⁷, 1679616 = 2⁸3⁸.
   - या संख्या आपल्या normalization वर अवलंबून आहेत: λ^c, F = ₂F₁, [0,1]-cycle.
   - आधी integral Betti आणि de Rham lattices निश्चित करायचे (Scholl motive), मग Tamagawa factors (2, 3) शी तुलना.
   - **PASS/FAIL आधी लिहायचे.**
2. **k = 2, cubic:** g = 12.4.a.a साठी m = 1 चा period-संबंध सापडला नाही. Eisenstein/Tate भाग असावा [अंदाज].
3. **Prior-art (MathSciNet / zbMATH उपलब्ध असेल तर):**
   - non-GL₂ Scholl representations;
   - weight-6 noncongruence forms चे critical values;
   - conductor 1296 आणि 432 असलेले weight-5 degree-4 L-functions;
   - paramodular weight Sym⁴⊗det².
4. **PARI/GP स्वतंत्र तपासणी (N5):** `N5_PARI` runner. दादांकडे gp.exe आहे का, हे अजून पक्कं झालेलं नाही.
5. **Preprint v2 (दादांच्या निर्णयानंतर):** Obs. 6.3 (1/216), Obs. 6.4 (period determinants), W′ (432, ε = −1), Scholl-ओळख [sketch], AI statement मध्ये GPT.

## ४ फाइल्स कशा वापरायच्या
- **Machinery:** सर्व scripts Python `decimal` + numpy वर आहेत; mpmath लागत नाही. चालवण्याची पद्धत: `python -I <script> <args>`.
- **Data आणि मुख्य script:**
  - coefficients: `N_next/N17_W_an_upto_20000.txt` (a₁…a₂₀₀₀₀; sha256 7873fbf2…)
  - periods: N11 (dps 70) किंवा N18 (dps 100, सुमारे 17 मिनिटं).
- **Explorations:** `N_next/explorations/` (exploration scripts; त्यांच्या निकालांवर दावा नाही).
- **FAIL outputs (मुद्दाम जपलेले):** `N2_output_run1_CB_FAIL.txt`, `N11_output_run1_FAIL.txt`, `N16_output_run1_D3_unverified.txt`, N18 (H3 निकष-चूक, N19 पाहा).
