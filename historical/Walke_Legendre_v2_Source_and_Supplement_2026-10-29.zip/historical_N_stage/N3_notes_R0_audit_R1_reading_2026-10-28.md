# N3 — R0 (मार्ग B चं prior-art audit) आणि R1 (L-stage scripts वाचन) — 28 ऑक्टोबर 2026

खुणा: [सिद्ध] [sketch] [संख्यात्मक] [अंदाज] [ज्ञात literature] [माहीत नाही]

---

## R0 — prior-art audit

**पद्धत:** web search (arXiv, journals, talks).
**मर्यादा:** MathSciNet आणि zbMATH उपलब्ध नव्हते. म्हणून "to the best of our knowledge" हीच भाषा वापरायची.

### १. Critical values / Deligne periods ची संख्यात्मक चाचणी ही पद्धत आधीपासून ज्ञात आहे [ज्ञात literature]

| काम | काय केलं आहे | आपल्याशी संबंध |
|---|---|---|
| Deligne (1979), *Valeurs de fonctions L et périodes d'intégrales* | Conjecture: L(M, m) ∈ (2πi)^{m·d±} c±(M) Q | R ∈ Q ही अपेक्षा इथून येते |
| Dummigan–Watkins, *Critical values of symmetric power L-functions* | L(Symⁿ E, m) ÷ Deligne period ⇒ rational; त्याचे prime factors Tamagawa / Ш शी जुळवले | आपल्या "पुढच्या पायरी"चं (Bloch–Kato) थेट मॉडेल |
| D. Roberts (2017 talk), hypergeometric L-functions | Central point वर Deligne conjecture संख्यात्मक तपासलं (Magma). उदाहरण: degree 4, weight 3, Hodge (1,1,1,1) | Weight 5 चं किंवा {0,0,5,5} चं उदाहरण नाही |
| H. Spencer, arXiv 2601.21934 (जानेवारी 2026) | Curves चे motivic pieces; L(C^τ, 1)/Ω rational/integral test | फक्त weight 1. Ratio L(m)/L(m′) नाही |
| Rogers–Wan–Zucker (1303.2259); D. Bao (2608.26514, 2026) | Weight 3–5 forms चे critical L-values elliptic-integral moments म्हणून | Levels 3–18; degree 4 नाही |
| Broadhurst (1604.03057) | Feynman integrals, Kloosterman moments, L-values (weights 3, 4, 6) | {0,0,5,5} नाही |
| Ibukiyama–Katsurada, JMSJ 66 | Sym⁴ L-function चे exact critical values आणि vector-valued Siegel forms | वेगळा object (Sym⁴ of one form) |

- **निष्कर्ष:** "Ratio test" ही पद्धत नवीन म्हणता येणार नाही. ती ज्ञात कामाला श्रेय देऊन वापरायची.

### २. Object W (degree 4, weight 5, Hodge {0,0,5,5}, N = 1296) — कुठेही आढळला नाही [ज्ञात literature, शोधापुरतं]
- **Weiss (arXiv 1802.08537), Thm 3.3(v):** weight (k, 2) च्या Siegel forms साठी HT weights {0,0,k−1,k−1}.
  - हे आपल्या k = 6 (Sym⁴ ⊗ det²) शी सुसंगत आहे.
  - पण त्यात उदाहरणं किंवा tables नाहीत.
- **Cléry–van der Geer (1709.01748):**
  - S_{4,2}(Γ₂) = 0.
  - j < 12 साठी S_{j,2}(Γ₂[2]) = 0.
  - Paramodular level त्यात नाही.
- **LMFDB** (L5 मध्ये आधीच तपासलं): conductor 1296 वर c5e2 प्रकारचा एकच L-function आहे, 36.6.b.a, आणि तो वेगळा आहे.
- **Spencer / Roberts / Dummigan–Watkins:** त्यांच्यात degree-4, {0,0,5,5} चं उदाहरण नाही.
- **Spinor L-values चे automorphic algebraicity theorems** (Harris आणि नंतरचे): मला सापडलेले सर्व cohomological weights साठी आहेत. Non-cohomological weight (j, 2) साठी असा theorem सापडला नाही [माहीत नाही].
- ⇒ **Audit: PASS.** W साठी ही चाचणी आधी प्रकाशित झालेली आढळली नाही (to the best of our knowledge).

### ३. सैद्धांतिक नोंदी
- **Deligne conjecture W ला लागू होतो [sketch]:** W भूमितीतून आला आहे (cubic-twisted Legendre family च्या Sym⁴ चा H¹ भाग, आणि त्याचा descent). म्हणून Deligne conjecture थेट motive ला लागू होतो. Automorphy (Conj. 6.4) गृहीत धरावी लागत नाही.
- **Periods:** Hodge {(5,0)², (0,5)²} आहे आणि (p,p) भाग नाही ⇒ d⁺ = d⁻ = 2. s = 3 आणि s = 5 दोन्ही odd आहेत ⇒ एकच period c⁻ ⇒ R := L(W,5)/(π⁴ L(W,3)) ∈ Q अपेक्षित [ज्ञात conjecture; W ला लागू होणं: अंदाज].
- **चाचणीची ताकद (प्रामाणिक मर्यादा):**
  - दोन weight-6 forms चा गुणाकार f·g सुद्धा ही चाचणी पास करतो (R = R_f R_g). पण H21 च्या D-test ने f ⊕ g ही शक्यता वगळली आहे.
  - Motivic नसलेला एखादा "random" degree-4 L-function ही चाचणी पास करणार नाही.
  - म्हणून PASS म्हणजे "W ची rational period structure अपेक्षेप्रमाणे आहे" इतकाच अर्थ. Automorphy चा पुरावा नाही.
- **L(W, 4):** याला c⁺ लागतो. नंतर c⁺c⁻ ~ δ(W) (det W) या Deligne संबंधातून L(W,3)·L(W,4) ची चाचणी शक्य असेल [अंदाज, नंतर].

### ४. बाजूचं निरीक्षण: W = ρ_f ⊗ τ (weight-6 form ⊗ 2-dim Artin) ही शक्यता वगळली जाते [sketch + संख्यात्मक]
- **ही शक्यता का तपासली:** Hodge {0,5} ⊗ {0,0} = {0,0,5,5} होतं, म्हणून "non-cohomological" W हा असा tensor असू शकेल का, हा नैसर्गिक प्रश्न आहे.
- **Moments ची खालची मर्यादा:** असा tensor असता, तर normalized trace चे moments असे असते:
  - E[a⁴] = E[a_f⁴]·E[|χ_τ|⁴] ≥ 2·2 = 4;
  - E[a⁶] ≥ 5·5 = 25.
  - **कारण:** τ irreducible असल्यामुळे ⟨τ⊗τ, τ⊗τ⟩ ≥ 2 आणि ⟨τ^{⊗3}, τ^{⊗3}⟩ ≥ 5.
  - SU(2) connected आहे, म्हणून even moments साठी f आणि τ स्वतंत्र मानता येतात.
  - CM f असेल तर E[a⁴] ≥ 6 येतं.
- **प्रत्यक्ष data:** H21 (V, p ≤ 40000) मध्ये moments 2.843 आणि 12.98 आहेत. USp(4) ची अपेक्षा 3 आणि 14 आहे. म्हणजे tensor च्या ≥ 4 आणि ≥ 25 या मर्यादांपासून data खूप दूर आहे.
- **τ|_K reducible असेल तर:** मग V reducible होईल. पण D-test नुसार V irreducible आहे.
- ⇒ W हा "form ⊗ Artin" नाही. हे Conj. 6.4 ला (खरा USp(4)-प्रकार) आणखी आधार देतं.
- Preprint मध्ये टाकण्यापूर्वी हा युक्तिवाद एकदा स्वतंत्रपणे तपासायचा.

---

## R1 — L-stage scripts वाचन (L1–L4; एकही चालवला नाही)

| प्रश्न | उत्तर |
|---|---|
| a_n कसे मिळतात? | **Split p:** H13 laptop data मधले s₁, s₂ (exact). **Inert p:** L1 twisted Lefschetz नुसार c₁ = −Re Σ ρ(ν)(a′⁴ − 3p a′² + p²) − 1 आणि c₂ = (c₁² − u)/2. यात μ = +p⁵, आणि descent "−" मुळे inert p वर c₁ ↦ −c₁. **2 आणि 3:** Euler factor 1. मग multiplicative recursion. |
| किती? | n ≤ 4999 (p ≤ 4999 data). 2 \| n किंवा 3 \| n असेल तर a_n = 0. |
| Integers आहेत का? | होय. सर्व integer recursion आहे ⇒ coefficient field Q. L2 मध्ये ते float64 मध्ये साठवले, पण \|a_n\| ≪ 2⁵³ असल्यामुळे ते सुरक्षित आहे. (s₂ ~ 4·10¹⁸ आहे, पण तो फक्त p ≤ 70 साठी, म्हणजे p² ≤ 4999 असेल तिथे, वापरला जातो.) |
| 30 अंकांसाठी किती a_n? | n-वा term ~ \|a_n\| e^{−2.094√n} (t₀ = 1; 4π/√36 = 2.094). 30 अंकांसाठी n ≈ 2000, 50 अंकांसाठी n ≈ 4000. उपलब्ध 4999 terms मधून कमाल सुमारे 55 अंक. ⇒ **laptop runner ची गरज नाही.** |
| L4 चं अचूकपण | scipy `quad` आणि double precision ⇒ जास्तीत जास्त ~10 अंक. 30 अंकांच्या चाचणीसाठी अपुरं. |
| Code बद्दल नोंद | L2, L3, L4 एकमेकांचा source `exec` करतात (fragile). N2 self-contained आहे. |

---

## N2 script — लिहिला, **चालवला नाही**
फाइल: `N2_check_LW_critical_ratio_FLOAT_2026-10-28.py`

### पद्धत
- **Numerical quadrature नाही.** Integer s साठी closed form वापरला:
  - I_m(Y) = ∫_Y^∞ y^{2m+1} K₀(y) dy;
  - I₀ = Y K₁(Y);
  - I_m = Y^{2m+1} K₁ + 2m Y^{2m} K₀ + 4m² I_{m−1}.
  - त्यामुळे फक्त K₀ आणि K₁ ची mpmath मध्ये, 40 आणि 60 अंकांवर, गणना लागते.
- **FE ची high-precision तपासणी:** split point t₀ = 1 आणि t₀ = 1.1 वर समान Λ आलं पाहिजे.
- **Rational ओळखणं:** continued fraction आणि PSLQ, दोन स्वतंत्र मार्ग. त्याशिवाय dps 40 → 60 आणि n ≤ 4000 → 4999 या बदलांवर निकाल स्थिर राहिला पाहिजे.

### Controls

| Control | काय तपासतो |
|---|---|
| C0 | ε ची निवड: t₀-स्वातंत्र्य ≥ 30 अंक; दुसऱ्या ε ने ते मोडलं पाहिजे |
| C1 | f = 4.6.a.a = η(2z)¹²: R_f ∈ Q |
| C2 | g = L(f)·L(f⊗χ₅) **एकाच degree-4 Dirichlet series म्हणून** (N = 400), W सारख्याच code मार्गाने. (a) L_g = L_f·L_{fχ} (≥ 30 अंक); (b) R_g ∈ Q |
| C3 | L(W, 3) = 2.2413552032 (L4) ± 10⁻⁹ |

### N1 च्या योजनेतला बदल (गणनेपूर्वी ठरवला)
- N1 मध्ये C2 साठी f ⊗ χ₋₃ घ्यायचा होता. पण χ₋₃ odd आहे:
  - ε(f⊗χ₋₃) = ε(f)·χ₋₃(4)·τ(χ)²/3 = −ε(f).
  - ε(f) = +1 [sketch: Fricke eigenvalue −1, (−1)^{k/2} = −1].
  - ⇒ ε(f⊗χ₋₃) = −1 ⇒ L(f⊗χ₋₃, 3) = 0 अपरिहार्यपणे.
  - ⇒ ratio ला अर्थ उरत नाही.
- **बदल:** even character χ₅ घेतला (5 आणि 4 coprime), ज्याने ε = +1 मिळतो. Hodge {0,0,5,5} तसेच राहतात.

### PASS/FAIL निकष
- Script च्या सुरुवातीला लिहिले आहेत. ते N1 R2 प्रमाणेच आहेत.
- Controls FAIL झाले, तर W चा निकाल "NOT EVALUATED" छापला जातो.

### खर्चाचा अंदाज
- सुमारे 10⁵ Bessel evaluations ⇒ काही मिनिटं.
- इथे (cloud workspace) किंवा laptop वर चालेल. Network लागत नाही.
- लागणारं: numpy, mpmath.

---

## पुढे
1. दादांच्या परवानगीनंतर N2 चालवायचा. Output `N2_output.txt` मध्ये जाईल; मग N4 notes.
2. PASS आलं तर R चे prime factors Bloch–Kato / Tamagawa (2, 3) शी तुलना करायचे, Dummigan–Watkins च्या धर्तीवर.
3. R3 (मार्ग A) चे PASS/FAIL निकष लिहायचे.

## Sources
- Deligne, *Values of L-functions and periods of integrals* (English notes): http://virtualmath1.stanford.edu/~conrad/BSDseminar/refs/Deligneconj.pdf
- Dummigan–Watkins: https://magma.maths.usyd.edu.au/~watkins/papers/sp1.pdf
- Roberts (MATRIX 2017): https://www.matrix-inst.org.au/wp_Matrix2016/wp-content/uploads/2016/04/Roberts-1.pdf
- Spencer, arXiv 2601.21934: https://arxiv.org/pdf/2601.21934
- Weiss, arXiv 1802.08537: https://arxiv.org/pdf/1802.08537
- Cléry–van der Geer, arXiv 1709.01748: https://arxiv.org/abs/1709.01748
- Rogers–Wan–Zucker, arXiv 1303.2259: https://arxiv.org/pdf/1303.2259
- Bao, arXiv 2608.26514: https://arxiv.org/pdf/2608.26514
- Broadhurst, arXiv 1604.03057: https://ar5iv.arxiv.org/html/1604.03057
- Ibukiyama–Katsurada, JMSJ 66: https://projecteuclid.org/journals/journal-of-the-mathematical-society-of-japan/volume-66/issue-1/Exact-critical-values-of-the-symmetric-fourth-L-function-and/10.2969/jmsj/06610139.full
