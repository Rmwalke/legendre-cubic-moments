# N8 — Legendre curve: function fields वर BSD ची rank-बाजू आपल्या स्वतःच्या गणनेने — 28 ऑक्टोबर 2026

खुणा: [सिद्ध] [sketch] [संख्यात्मक] [अंदाज] [ज्ञात literature] [माहीत नाही]

- **Script:** `N7_check_Legendre_function_field_BSD_rank_FLOAT_2026-10-28.py`
- **Output:** `N7_output.txt` (5 सेकंद, इथेच चालवलं)
- **दर्जा:** **[ज्ञात literature: Ulmer, JNT 136 (2014)]** आहे. आपली गणना ही त्याची स्वतंत्र संख्यात्मक पुष्टी आहे. **नवीन दावा नाही.**

## १ काय तपासलं
- **Curve:** E: y² = x(x+1)(x+t), t = u^d. ही K = F_q(u) वर घेतली, q = p^{2f} (म्हणजे μ_d ⊂ F_q). ही curve आपल्या E_λ चा x ↦ −x twist आहे.
- **L-function:**
  - L(E/K, T) हा polynomial आहे; त्याचं degree = deg N − 4 [ज्ञात theory: Grothendieck].
  - log L = Σ A_n Tⁿ/n, जिथे A_n = Σ_{x∈P¹(F_{qⁿ})} a_x.
  - A_n आपण थेट मोजले: a_x = −Σχ(X(X+1)(X+x^d)), additive FFT वापरून, आणि प्रत्येक आकडा exact integer मध्ये तपासून.
- **Bad fibres:**
  - u = 0 आणि ∞: I_{2d}, split.
  - u^d = 1: I₂.
  - ⇒ d सम असेल तर deg N = d + 2, म्हणजे deg L = d − 2.
- **Ulmer चा theorem:** d = p^f + 1 असताना rank = d − 2 आणि BSD सिद्ध. ⇒ अपेक्षा: L(T) = (1 − qT)^{d−2}, म्हणजेच A_n = −(d−2)qⁿ.

## २ निकाल (PASS/FAIL गणनेपूर्वी ठरवलेले)
| केस | p, q, d | अपेक्षित rank | निकाल |
|---|---|---|---|
| C1 (control) | 5, 25, 1 | 0 (L = 1) | PASS (A_n = 0, n ≤ 3) |
| C2 (control) | 5, 25, 2 | 0 (L = 1) | PASS |
| U1 | 3, 9, 4 | 2 | **PASS:** L = 1 − 18T + 81T² = (1 − 9T)² (पूर्ण degree) |
| U2 | 5, 25, 6 | 4 | **PASS:** L = (1 − 25T)⁴ (पूर्ण degree) |
| U3 | 7, 49, 8 | 6 | **PASS:** n ≤ 3. Functional equation आणि e₃ ≠ 0 मुळे पूर्ण L ठरतो [sketch] |
| U4 | 3, 81, 10 | 8 | PASS, पण **अंशतः** (n ≤ 3; पूर्णसाठी n = 4 लागतो) |
| U5 | 11, 121, 12 | 10 | PASS, पण **अंशतः** (n ≤ 2) |
| E1 (explore) | 5, 25, 4 | — | L = 1 + 14T + 625T²: Riemann hypothesis \|α\| = 25 पाळतो, L(1/q) ≠ 0 ⇒ analytic rank 0 (दावा नाही) |

- **Integrity:** प्रत्येक |a_x| ≤ 2√Q. चांगल्या fibres वर a ≡ 2 (mod 4) (full 2-torsion). FFT residual < 10⁻⁶.

## ३ अर्थ
- **[संख्यात्मक + ज्ञात theorem]:** आपल्या family वर, function fields मध्ये, ord_{T=1/q} L = d − 2 = rank (Ulmer). म्हणजे **BSD ची rank-बाजू (analytic rank = algebraic rank)** आपल्या स्वतःच्या point counts ने तिथे दिसते, आणि rank 2, 4, 6, … पर्यंत.
- **Q वर असं का होत नाही:** इथे L(T) = (1 − qT)^{d−2} इतकं साधं येतं, कारण d = p^f + 1 असताना Gauss sums "pure" होतात (Shafarevich–Tate / Ulmer यंत्रणा) [ज्ञात literature]. Q वर, rank ≥ 2 साठी, अशी कोणतीही यंत्रणा ज्ञात नाही. Clay प्रश्नाचा अडथळा तोच आहे.
- **आपल्या preprint शी नातं [sketch]:**
  - इथले A_n हे χ-twisted **first** moments आहेत.
  - Preprint मधले twisted moments तेच यंत्र Sym^k वर लावल्यावर येतात.
  - म्हणून आपला W हा या function-field चित्राच्या Sym⁴ / Bloch–Kato बाजूला आहे.

## ४ मर्यादा
- U4 आणि U5 अपूर्ण आहेत: पूर्णसाठी |F| = 3¹⁶ किंवा 11¹⁰ लागेल, जे इथे जड आहे. Laptop वर करता येईल.
- BSD चा leading-coefficient भाग (Reg, |Ш|) तपासलेला नाही. त्यासाठी Ulmer च्या explicit points ची heights लागतील.
