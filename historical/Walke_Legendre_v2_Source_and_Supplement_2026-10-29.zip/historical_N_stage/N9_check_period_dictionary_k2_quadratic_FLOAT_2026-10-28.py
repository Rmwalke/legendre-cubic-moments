"""N9 (FLOAT, Python decimal; no mpmath) — R5 stage (a): the "period dictionary" on a KNOWN case.
 Elliptic-period integrals of the Legendre family  ->  critical L-values of a modular form.
   F(x) := 2F1(1/2,1/2;1;x) = 1/AGM(1, sqrt(1-x))  (= (2/pi) K(sqrt x)).
   I_j := int_0^1 lambda^{-1/2} F(lambda)^j F(1-lambda)^{2-j} d lambda,   j = 0, 1, 2   (quadratic twist, Sym^2).
 Derivation BEFORE running [sketch; classical facts: F(lambda) = theta_3^2, d lambda/d tau = i pi lambda(1-lambda) theta_3^4,
   tau = i y, y = F(1-lambda)/F(lambda)]:
   I_j = pi * int_0^inf G(iy) y^{m-1} dy,  m = 3 - j,  G = lambda^{1/2}(1-lambda) theta_3^8 = theta_2^2 theta_3^2 theta_4^4.
   If G(tau) = 4 f(tau/4) with f = 8.4.a.a = eta(2z)^4 eta(4z)^4, then
   I_j / (pi^{1-m} L(f, m)) = 4 Gamma(m) 2^m = 64, 16, 8   for m = 3, 2, 1.
 PASS/FAIL fixed before running:
   Q1 (exact): theta_2^2 theta_3^2 theta_4^4 / (4 q^{1/2}) = sum_k a_{2k+1} q^k  (q = e^{i pi tau}) for k <= 300, exact integers.
   Q2 (numerical): the three ratios equal 64, 16, 8 to >= 35 digits; quadrature error estimate (h vs h/2) >= 40 digits.
   Q3 (method control): the same quadrature reproduces F's own normalisation int_0^1 F(x) dx = 4G/pi ... skipped (not a
      classical constant we can state with certainty) -> replaced by: int_0^1 x^{-1/2}(1-x)^{-1/2} dx = pi (exact).
 Usage: python -I N9_...py
"""
import math, time
from decimal import Decimal as D, getcontext
DPS = 50
getcontext().prec = DPS + 15
T0 = time.time()

def pi_dec():
    P = getcontext().prec; scale = 10 ** (P + 10)
    def atan_inv(x):
        total = term = scale // x; x2 = x * x; k = 1; sg = 1
        while term:
            term //= x2; k += 2; sg = -sg; total += sg * (term // k)
        return total
    return D(16 * atan_inv(5) - 4 * atan_inv(239)) / D(scale)
PI = pi_dec()
EPS = D(10) ** (-(DPS + 10))
def agm(a, b):
    while abs(a - b) > EPS * a:
        a, b = (a + b) / 2, (a * b).sqrt()
    return (a + b) / 2
def F(x, one_minus_x):           # pass 1-x separately for accuracy near x = 1
    return 1 / agm(D(1), one_minus_x.sqrt())

def tanh_sinh(fn, level):
    """int_0^1 fn(x, 1-x) dx by tanh-sinh; x = 1/(1+e^{-2u}), u = (pi/2) sinh t; dx/dt = pi x(1-x) cosh t."""
    h = D(1) / D(2 ** level); total = D(0); k = 0
    while True:
        done = True
        for sgn in ((1,) if k == 0 else (1, -1)):
            t = h * k * sgn
            et = t.exp(); ch = (et + 1 / et) / 2; sh = (et - 1 / et) / 2
            u = PI / 2 * sh
            e2 = (-2 * u).exp(); x = 1 / (1 + e2); omx = e2 / (1 + e2)
            if x == 0 or omx == 0: continue
            w = PI * x * omx * ch
            term = fn(x, omx) * w
            total += term
            if abs(term) > D(10) ** (-(DPS + 12)): done = False
        if done and k > 10: break
        k += 1
    return total * h

# ---- Q3 control: int_0^1 x^{-1/2}(1-x)^{-1/2} dx = pi
c3 = [tanh_sinh(lambda x, o: 1 / (x * o).sqrt(), L) for L in (6, 7)]
dig = lambda a, b: float(-((abs(a - b) / abs(b)).log10())) if a != b else DPS
print(f'Q3 control (Beta(1/2,1/2) = pi): digits {dig(c3[1], PI):.1f}  (h vs h/2: {dig(c3[0], c3[1]):.1f})')

# ---- 8.4.a.a coefficients: eta(2z)^4 eta(4z)^4 = q prod (1-q^{2n})^4 (1-q^{4n})^4
M = 700
L_ = M // 2 + 2; P = [0] * L_; P[0] = 1
for n in range(1, L_):
    for _ in range(4):
        for i in range(L_ - 1, n - 1, -1): P[i] -= P[i - n]
    if 2 * n < L_:
        for _ in range(4):
            for i in range(L_ - 1, 2 * n - 1, -1): P[i] -= P[i - 2 * n]
a = [0] * (M + 1)
for j in range(L_):
    if 2 * j + 1 <= M: a[2 * j + 1] = P[j]
assert a[1:12] == [1, 0, -4, 0, -2, 0, 24, 0, -11, 0, -44]

# ---- Q1 exact: theta_2^2 theta_3^2 theta_4^4 / (4 q^{1/2}) vs sum a_{2k+1} q^k   (q = e^{i pi tau})
K = 300
def mul(A, B):
    C = [0] * (K + 1)
    for i, x in enumerate(A):
        if x:
            for j in range(K + 1 - i):
                if B[j]: C[i + j] += x * B[j]
    return C
th3 = [0] * (K + 1); th4 = [0] * (K + 1); th2h = [0] * (K + 1)   # theta_2/(2 q^{1/4}) = sum_{n>=0} q^{n(n+1)}
for n in range(-30, 31):
    e = n * n
    if e <= K: th3[e] += 1; th4[e] += (-1) ** (n % 2)
for n in range(0, 30):
    e = n * (n + 1)
    if e <= K: th2h[e] += 1
G = mul(mul(th2h, th2h), mul(mul(th3, th3), mul(mul(th4, th4), mul(th4, th4))))   # theta_2^2/(4 q^{1/2}) * ...
okQ1 = all(G[k] == a[2 * k + 1] for k in range(K + 1) if 2 * k + 1 <= M)
print('Q1 exact q-series identity theta_2^2 theta_3^2 theta_4^4 = 4 f(tau/4):', okQ1)

# ---- L(f, m), m = 1..3, by the degree-2 closed form (N = 8, weight 4: Lambda(s) = N^{s/2}(2pi)^{-s}Gamma(s)L(s))
def upper_gamma_int(s, z):
    term = D(1); tot = D(1)
    for j in range(1, s):
        term = term * z / j; tot += term
    return math.factorial(s - 1) * (-z).exp() * tot
def Lam(N, eps, s, t0, kwt=4, nmax=600):
    sq = D(N).sqrt(); tot = D(0)
    for n in range(1, nmax + 1):
        if a[n]:
            c = D(n) / sq
            tot += a[n] * ((2 * PI * c) ** (-s) * upper_gamma_int(s, 2 * PI * c * t0)
                           + eps * (2 * PI * c) ** (-(kwt - s)) * upper_gamma_int(kwt - s, 2 * PI * c / t0))
    return tot
eps = max((1, -1), key=lambda e: dig(Lam(8, e, 3, D(1)) if e == 1 else Lam(8, e, 1, D(1)), Lam(8, e, 3, D('1.1')) if e == 1 else Lam(8, e, 1, D('1.1'))))
# robust epsilon choice at s = 1 (non-central)
d1 = {e: dig(Lam(8, e, 1, D(1)), Lam(8, e, 1, D('1.1'))) for e in (1, -1)}
eps = max(d1, key=d1.get)
print('epsilon(8.4.a.a) =', eps, {k: round(v, 1) for k, v in d1.items()})
Lf = {m: Lam(8, eps, m, D(1)) / (D(8).sqrt() ** m * (2 * PI) ** (-m) * math.factorial(m - 1)) for m in (1, 2, 3)}
for m in (1, 2, 3): print(f'  L(f,{m}) = {format(Lf[m], ".30g")}')

# ---- Q2 the integrals
res = {}
for j in (0, 1, 2):
    m = 3 - j
    fn = lambda x, o, j=j: (1 / x.sqrt()) * F(x, o) ** j * F(o, x) ** (2 - j)
    I6, I7 = tanh_sinh(fn, 6), tanh_sinh(fn, 7)
    ratio = I7 / (PI ** (1 - m) * Lf[m])
    pred = 4 * math.factorial(m - 1) * 2 ** m
    res[m] = (dig(I6, I7), dig(ratio, D(pred)))
    print(f'  j={j} m={m}: I = {format(I7, ".30g")}  ratio = {format(ratio, ".30g")}  pred {pred}:'
          f' {res[m][1]:.1f} digits (quadrature h/h2: {res[m][0]:.1f})')
okQ2 = all(r[1] >= 35 and r[0] >= 40 for r in res.values())
print('Q2:', okQ2, ' Q1:', okQ1, f' time {time.time() - T0:.0f}s')
print('VERDICT stage (a):', 'PASS' if okQ1 and okQ2 else 'FAIL')
