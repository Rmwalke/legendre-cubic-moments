@echo off
rem N5 runner (PARI/GP). Offline. Writes N5_output.txt next to this file.
cd /d "%~dp0"
set "GP="
where gp >nul 2>nul && set "GP=gp"
if not defined GP (
  for /d %%D in ("%ProgramFiles%\*pari*" "%ProgramFiles(x86)%\*pari*" "%LOCALAPPDATA%\Programs\*pari*" "C:\*pari*") do (
    for %%F in ("%%~D\gp.exe" "%%~D\gp-*.exe") do if exist "%%~F" set "GP=%%~F"
  )
)
if not defined GP (
  echo PARI/GP gp.exe sapadla nahi. README_MR.txt madhla "haatane chalavna" haa marg vapra.
  pause
  exit /b 1
)
echo Using: %GP%
echo Running N5 (kahi second te kahi minute)...
"%GP%" -q -f N5_check_LW_critical_ratio_PARI_FLOAT_2026-10-28.gp > N5_output.txt 2>&1
type N5_output.txt
echo.
echo Zala. N5_output.txt Claude la dya.
pause
