N5 — PARI/GP ने स्वतंत्र तपासणी (R2b), 28 ऑक्टोबर 2026

हेतू
  N2 मध्ये आलेला निकाल R = L(W,5) / (π⁴·L(W,3)) = 1/216, PARI/GP च्या स्वतःच्या L-function engine ने पुन्हा तपासणं.
  PARI चा code N2 पेक्षा पूर्णपणे वेगळा आहे. N2 आणि N5 यांच्यात सामायिक फक्त W चे exact integer a_n आहेत
  (N5_W_an_upto_4999.txt).
  Network लागत नाही. चालायला काही सेकंद ते काही मिनिटं लागतील.

१. PARI/GP install आहे का, ते तपासा
  - Windows: Start menu मध्ये "PARI" किंवा "gp" शोधा, किंवा File Manager मध्ये gp.exe शोधा.
    ते उघडल्यावर "GP/PARI CALCULATOR Version 2.xx" अशी ओळ दिसली, तर PARI/GP install आहे. त्या version चा क्रमांक Claude ला सांगा.
  - Version 2.13 किंवा नवीन असावं. (mfinit 2.11 पासून आहे. ते नसलं तरी script चालतो, फक्त एक जादा तपासणी वगळली जाते.)

२. सोपा मार्ग (one-click)
  - हा पूर्ण folder एका ठिकाणी unzip करा.
  - Windows: RUN_WINDOWS_double_click.bat वर double-click करा.
  - Mac/Linux: RUN_MAC_LINUX_double_click.command वर double-click करा. (Mac ने अडवलं तर: right-click → Open.)
  - निकाल याच folder मध्ये N5_output.txt मध्ये येईल. ती फाइल Claude ला द्या.

३. हाताने चालवणं (runner ला gp सापडला नाही तर)
  - gp उघडा.
  - हा folder gp मध्ये set करा. Windows वर path मध्ये / वापरा, \ नाही:
        cd("C:/Users/तुमचे_नाव/Downloads/N5_PARI")
    (cd() चालत नसेल, तर हा folder gp.exe असलेल्या folder मध्ये copy करा.)
  - मग टाइप करा:
        \r N5_check_LW_critical_ratio_PARI_FLOAT_2026-10-28.gp
  - Screen वर आलेला सगळा मजकूर copy करून Claude ला द्या.

PASS/FAIL (गणनेपूर्वी ठरवलेले; तपशील .gp फाइलच्या सुरुवातीला)
  P1  चारही L-functions साठी functional equation (lfuncheckfeq ≤ −100 bits)
  P2  controls: 4.6.a.a चा ratio 1/8; f·(f⊗χ₅) चा ratio 1/200
  P3  L(W,3) आणि L(W,5) N2 शी ≥ 30 अंक जुळतात
  P4  R_W = 1/216

फाइल्स
  N5_check_LW_critical_ratio_PARI_FLOAT_2026-10-28.gp  — मुख्य script (PARI/GP)
  N5_W_an_upto_4999.txt                                — W चे a_1..a_4999 (exact integers; sha256 37df237f…)
  N5_export_W_an_2026-10-28.py                         — वरची a_n फाइल कशी बनवली तो Python code (पुन्हा चालवायची गरज नाही)
  RUN_WINDOWS_double_click.bat / RUN_MAC_LINUX_double_click.command — one-click runners
