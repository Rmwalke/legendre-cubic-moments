#!/bin/sh
# N5 runner (PARI/GP). Offline. Writes N5_output.txt next to this file.
cd "$(dirname "$0")" || exit 1
GP=$(command -v gp 2>/dev/null)
for c in /opt/homebrew/bin/gp /usr/local/bin/gp /usr/bin/gp /Applications/PARI*/gp; do
  [ -z "$GP" ] && [ -x "$c" ] && GP="$c"
done
if [ -z "$GP" ]; then echo "PARI/GP (gp) sapadla nahi. README_MR.txt pahaa."; exit 1; fi
echo "Using: $GP"
"$GP" -q -f N5_check_LW_critical_ratio_PARI_FLOAT_2026-10-28.gp > N5_output.txt 2>&1
cat N5_output.txt
echo "Zala. N5_output.txt Claude la dya."
