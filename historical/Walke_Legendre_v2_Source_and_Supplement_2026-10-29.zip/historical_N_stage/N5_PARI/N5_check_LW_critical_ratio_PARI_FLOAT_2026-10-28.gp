\\ N5 (PARI/GP, multiprecision FLOAT) - independent check of the N2 v3 result
\\     R := L(W,5) / (Pi^4 L(W,3)) = 1/216 ?     (N2: 50-57 digits, Python decimal backend)
\\ Independent of N2: PARI's own L-function engine (lfun, lfuncheckfeq, lfunmul), PARI's own eta() for the
\\   control form f = eta(2z)^12 = 4.6.a.a (cross-checked with mfinit when available).
\\ Shared with N2: only the exact integer coefficients of W (file N5_W_an_upto_4999.txt).
\\ W data: degree 4, Gamma_C(s)^2 = Gamma_R(s)^2 Gamma_R(s+1)^2 -> Vga [0,0,1,1], k = 6, N = 1296, eps = +1, self-dual.
\\
\\ PASS/FAIL fixed BEFORE running:
\\  P1  lfuncheckfeq(., t = 1.1) <= -100 (bits) for f, f x (./5), g = f * (f x (./5)) [lfunmul], W
\\  P2  controls: R_f = L(f,5)/(Pi^2 L(f,3)) = 1/8 and R_g = L(g,5)/(Pi^4 L(g,3)) = 1/200
\\      (bestappr(., 10^6) equal and |error| < 10^-30)
\\  P3  L(W,3) and L(W,5) equal the N2 values to >= 30 digits
\\  P4  bestappr(R_W, 10^6) == 1/216 and |R_W - 1/216| < 10^-30
\\  PASS iff P1-P4. If a control fails: no claim on W.
\\ Usage:  gp -q -f N5_check_LW_critical_ratio_PARI_FLOAT_2026-10-28.gp > N5_output.txt

print("N5 - PARI/GP version ", version());
T0 = getabstime();
A = readvec("N5_W_an_upto_4999.txt");
print("W coefficients read: ", #A, "   a_5, a_7, a_59 = ", [A[5], A[7], A[59]]);
if (#A != 4999 || A[5] != 36 || A[7] != -32 || A[59] != 28152, error("coefficient file mismatch"));

M = 4000;
EV = Vec(eta(x + O(x^(M\2 + 2)))^12);
AF = vector(M, n, if (n % 2, EV[(n-1)/2 + 1], 0));
print("f = eta(2z)^12: a_1..a_9 = ", AF[1..9]);
if (AF[1..9] != [1,0,-12,0,54,0,-88,0,-99], error("f coefficients"));
mfcheck() = my(mf = mfinit([4,6],1), F = mfeigenbasis(mf)[1]); mfcoefs(F, 60)[2..61] == AF[1..60];
mfok = iferr(mfcheck(), err, -1);
print("mfinit cross-check of f (1 = equal, 0 = DIFFERENT, -1 = mfinit unavailable): ", mfok);
if (mfok == 0, error("f differs from mfinit eigenform"));

aW(n) = if (n > #A, error("W: PARI needs ", n, " coefficients, only ", #A, " available")); A[1..n];
aF(n) = if (n > M, error("f: PARI needs ", n, " coefficients")); AF[1..n];
aFC(n) = if (n > M, error("f chi5: PARI needs ", n, " coefficients")); vector(n, i, AF[i] * kronecker(i, 5));
dig(a, b) = if (a == b, default(realprecision), -log(abs(a - b) / abs(b)) / log(10));

N2L3 = 2.241355203236439605879618666060345021634663845711378470;
N2L4 = 1.077077976096331662211885414803778494282805934347963222;
N2L5 = 1.010779504775895276424758858414728530036032268915172553;

run(prec) =
{
  my(LF, LFC, LG, LW, fe, Rf, Rfc, Rg, L3, L4, L5, RW, P1, P2, P3, P4);
  default(realprecision, prec);
  print("\n==== realprecision ", prec, " ====");
  LF  = lfuncreate([aF,  0, [0,1], 6, 4, 1]);
  LFC = lfuncreate([aFC, 0, [0,1], 6, 100, 1]);
  LG  = lfunmul(LF, LFC);
  LW  = lfuncreate([aW,  0, [0,0,1,1], 6, 1296, 1]);
  fe = [lfuncheckfeq(LF, 11/10), lfuncheckfeq(LFC, 11/10), lfuncheckfeq(LG, 11/10), lfuncheckfeq(LW, 11/10)];
  print("P1 lfuncheckfeq bits [f, f chi5, g, W] = ", fe);
  P1 = vecmax(fe) <= -100;
  Rf  = lfun(LF, 5)  / (Pi^2 * lfun(LF, 3));
  Rfc = lfun(LFC, 5) / (Pi^2 * lfun(LFC, 3));
  Rg  = lfun(LG, 5)  / (Pi^4 * lfun(LG, 3));
  print("   R_f = ", Rf, "  bestappr ", bestappr(Rf, 10^6));
  print("   R_fchi5 (info) = ", Rfc, "  bestappr ", bestappr(Rfc, 10^6));
  print("   R_g = ", Rg, "  bestappr ", bestappr(Rg, 10^6));
  P2 = bestappr(Rf, 10^6) == 1/8 && abs(Rf - 1/8) < 10^-30 && bestappr(Rg, 10^6) == 1/200 && abs(Rg - 1/200) < 10^-30;
  print("P2 controls R_f = 1/8, R_g = 1/200: ", P2);
  L3 = lfun(LW, 3); L4 = lfun(LW, 4); L5 = lfun(LW, 5);
  print("   L(W,3) = ", L3, "   digits vs N2: ", dig(L3, N2L3));
  print("   L(W,4) = ", L4, "   digits vs N2 (info): ", dig(L4, N2L4));
  print("   L(W,5) = ", L5, "   digits vs N2: ", dig(L5, N2L5));
  P3 = dig(L3, N2L3) >= 30 && dig(L5, N2L5) >= 30;
  print("P3 L(W,3), L(W,5) = N2 to >= 30 digits: ", P3);
  RW = L5 / (Pi^4 * L3);
  print("   R_W = ", RW, "  bestappr ", bestappr(RW, 10^6), "  digits vs 1/216: ", dig(RW, 1/216.));
  P4 = bestappr(RW, 10^6) == 1/216 && abs(RW - 1/216) < 10^-30;
  print("P4 R_W = 1/216: ", P4);
  return([P1, P2, P3, P4]);
}

res = iferr(run(38), err, print("at realprecision 38: ", err); iferr(run(34), err2, print("at realprecision 34: ", err2); 0));
print("\n==== verdict ====");
if (type(res) == "t_INT", print("N5 VERDICT: NOT EVALUATED (PARI needed more coefficients than available - send N5_output.txt)"),
  if (res[1] && res[2] && res[3] && res[4], print("N5 VERDICT: PASS  (PARI independently confirms R = 1/216)"),
    if (!(res[1] && res[2]), print("N5 VERDICT: CONTROL FAIL [P1,P2,P3,P4] = ", res, "  - no claim on W"),
      print("N5 VERDICT: FAIL [P1,P2,P3,P4] = ", res))));
print("time: ", (getabstime() - T0) \ 1000, " s");
quit
