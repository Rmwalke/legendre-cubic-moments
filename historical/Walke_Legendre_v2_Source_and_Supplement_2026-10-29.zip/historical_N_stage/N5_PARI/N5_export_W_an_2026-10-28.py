"""N5 export — writes the exact integer Dirichlet coefficients a_1..a_4999 of L(W, s) (descent '-', mu = +p^5,
 Euler factors at 2, 3 equal to 1) to N5_W_an_upto_4999.txt, one integer per line (PARI readvec format).
 Same algorithm as L1/L2/N2 (functions copied from N2 v3; nothing is exec'd).
Usage: python -I N5_export_W_an_2026-10-28.py H13_output_data_laptop_p_upto_4999.txt
"""
import sys, math
import numpy as np

def chi_table(p):
    c = np.full(p, -1, dtype=np.int64); c[0] = 0; c[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1; return c
def fp2_pow(A, B, e, p, nr):
    RA = np.ones_like(A); RB = np.zeros_like(B); XA, XB = A.copy(), B.copy()
    while e:
        if e & 1: RA, RB = (RA * XA + nr * RB * XB) % p, (RA * XB + RB * XA) % p
        XA, XB = (XA * XA + nr * XB * XB) % p, (2 * XA * XB) % p
        e >>= 1
    return RA, RB
def twisted_data(p):
    chi = chi_table(p); nr = next(x for x in range(2, p) if chi[x] == -1)
    X = np.arange(p)
    g = chi[(X * X - nr) % p].astype(float); c = chi.astype(float)
    corr = np.fft.ifft(np.fft.fft(c) * np.conj(np.fft.fft(g))).real
    assert np.max(np.abs(corr - np.rint(corr))) < 1e-6, ('FFT rounding', p)
    ap = -np.rint(corr).astype(np.int64)
    assert np.all(np.abs(ap) <= 2 * math.sqrt(p) + 1e-9) and np.all(ap % 2 == 0)
    RA, RB = fp2_pow(X.astype(np.int64), np.ones(p, dtype=np.int64), (p * p - 1) // 3, p, nr)
    keys = RA * p + RB; one = p
    others = sorted(set(keys.tolist()) - {one})
    cls = np.zeros(p, dtype=np.int64)
    if len(others) >= 1: cls[keys == others[0]] = 1
    if len(others) == 2: cls[keys == others[1]] = 2
    return ap, cls
def re_sum(vals, cls):
    S = [int(sum(int(v) for v in vals[cls == j])) for j in range(3)]
    assert S[1] == S[2], S
    return S[0] - S[1]
def euler_to_dirichlet(euler, nmax, bad=(2, 3)):
    pk = {}
    for p, (c1, c2, c3, c4) in euler.items():
        b = [1]; k = 1
        while p ** k <= nmax:
            v = c1 * b[k - 1] - (c2 * b[k - 2] if k >= 2 else 0) + (c3 * b[k - 3] if k >= 3 else 0) - (c4 * b[k - 4] if k >= 4 else 0)
            b.append(v); k += 1
        pk[p] = b
    A = [0] * (nmax + 1); A[1] = 1
    for n in range(2, nmax + 1):
        m = n; p = next(d for d in range(2, n + 1) if m % d == 0); k = 0
        while m % p == 0: m //= p; k += 1
        A[n] = 0 if p in bad else A[m] * pk[p][k]
    return A

data = {}
for l in open(sys.argv[1], encoding='utf-8'):
    if l.startswith('#') or not l.strip(): continue
    t = l.split(); data[int(t[0])] = t
nmax = max(data); euler = {}
for p in sorted(data):
    t = data[p]; mu = p ** 5
    if t[1] == 'split':
        c1, c2 = int(t[2]), int(t[3])
    else:
        u = int(t[2]); ap, cls = twisted_data(p)
        c1 = -re_sum(ap ** 4 - 3 * p * ap ** 2 + p * p, cls) - 1
        assert (c1 * c1 - u) % 2 == 0
        c2 = (c1 * c1 - u) // 2; c1 = -c1
    euler[p] = (c1, c2, mu * c1, mu * mu)
A = euler_to_dirichlet(euler, nmax)
ap_L5 = {5: 36, 7: -32, 11: -72, 13: 28, 17: 2556, 19: -2504, 23: 720, 29: 3924, 31: -272, 37: 2284, 41: 10188,
         43: 4168, 47: -12096, 53: 10404, 59: 28152}
assert all(A[p] == v for p, v in ap_L5.items())
with open('N5_W_an_upto_4999.txt', 'w', encoding='ascii', newline='\n') as f:
    for n in range(1, nmax + 1): f.write(f'{A[n]}\n')
print(f'wrote a_1..a_{nmax}; a_p (5..59) match L5; nonzero: {sum(1 for x in A[1:] if x)}; max |a_n| = {max(abs(x) for x in A[1:])}')
