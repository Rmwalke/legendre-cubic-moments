# N12 — R5: W चा Deligne period noncongruence periods मधून — 28 ऑक्टोबर 2026

खुणा: [सिद्ध] [sketch] [संख्यात्मक] [अंदाज] [ज्ञात literature] [माहीत नाही]

**Scripts आणि outputs:**
- N9 — stage (a): quadratic twist, control. Output: `N9_output.txt`.
- N10 — stage (b): cubic twist, k = 2. पहिला प्रयत्न 2-term मध्ये FAIL. Output: `N10_output.txt`.
- Exploration scripts (scratchpad मध्ये): LLL आणि σ-paired determinant search.
- N11 — confirmation, dps 70, quadrature levels 8 आणि 9. Output: `N11_output.txt`.

---

## १ Period dictionary [sketch: classical theta-identities]
- **F:** F(λ) = ₂F₁(½,½;1;λ) = θ₃², आणि dλ/dτ = iπλ(1−λ)θ₃⁴.
- **Variable:** τ = iy, जिथे y = F(1−λ)/F(λ).
- **मूळ सूत्र:** ∫₀¹ λ^{e−1} F^j F(1−λ)^{k−j} dλ = π∫₀^∞ G(iy) y^{m−1} dy, जिथे m = k+1−j आणि G = λ^e(1−λ)θ₃^{2k+4} (weight k+2).
- ⇒ elliptic-period moments म्हणजे weight-(k+2) forms चे Mellin / L-values.

## २ Stage (a): quadratic, k = 2 — PASS [संख्यात्मक + ज्ञात literature: Rogers–Wan–Zucker प्रकार]
- **q-series:** θ₂²θ₃²θ₄⁴ = 4·f(τ/4), जिथे f = 8.4.a.a. हे exact integers ने तपासलं (300 पदं).
- **Integrals:** ∫₀¹ λ^{−1/2}F^jF(1−λ)^{2−j} = 64, 16, 8 × π^{1−m} L(f, m). ही जुळणी **63 अंकांपर्यंत** आहे.

## ३ Stage (b): cubic, k = 2
- **Noncongruence ची खूण:** λ^{1/3}(1−λ)θ₃⁸ च्या q-series चे denominators 3, 9, 81, 243, … असे वाढतात ⇒ noncongruence (Calegari–Dimitrov–Tang) [संख्यात्मक, छोटी range; ज्ञात theorem].
- **पहिला प्रयत्न (2-term) FAIL** (N10).
  - f36 ⊗ χ₋₃ साठी N = 36, 108, 324 पैकी कोणताही level बसला नाही. खरा partner g = 12.4.a.a आहे (a₃ = +3, N = 12, ε = +1; FE 63.8 अंक) — exploration मध्ये सापडला.
- **Exploration (LLL) मध्ये सापडलेले संबंध** (63 अंक):
  - (λ^{−1/3} + λ^{−2/3}) period ↔ 36.4.a.a: गुणक 3, 18/π, 144/π² (m = 1, 2, 3).
  - (λ^{−2/3} − λ^{−1/3}) ↔ 12.4.a.a: गुणक 12/π, 96/π² (m = 2, 3).
  - **m = 1 वर g साठी संबंध मिळाला नाही — उघडा** [माहीत नाही]. यात Eisenstein/Tate भाग असावा [अंदाज]. 1, π, log 2, log 3, √3 हे घटक घेऊनही संबंध मिळाला नाही.
- ⇒ k = 2 साठी "noncongruence periods = congruence L-values (algebraic गुणकांसह)" हे चित्र दिसतं. हे Scholl representation ची 2-dim, GL₂-type बाजू आहे.

## ४ Stage (c): W (k = 4) — मुख्य निकाल
- **de Rham बाजू [sketch]:**
  - Cubic cover वर weight-6 cusp forms: λ^e(1−λ)θ₃¹², जिथे e ∈ {1/3, 4/3} (ψ) आणि e ∈ {2/3, 5/3} (ψ̄).
  - ⇒ ψ-भाग 4-dim आहे. हे V शी जुळतं (Scholl rep चा new भाग).
- **Descent [sketch]:** σ: λ ↦ 1/λ ही involution η_e ↦ −η_{2−e} अशी चालते. म्हणून जोड्या 1/3 ↔ 5/3 आणि 4/3 ↔ 2/3 अशा येतात. Integrals मध्ये याचा अर्थ λ^{∓2/3} आणि λ^{∓1/3} यांची बेरीज किंवा फरक.
- **पहिला शोध (σ न वापरता): 0 hits.** त्यानंतर σ-pairing ची कल्पना आली (गणनेनंतर लक्षात आलेलं; प्रामाणिक नोंद).
- **σ-paired exploration** (1.4 कोटी tests): फक्त 6 hits, आणि सर्व एकाच संरचनेचे.

  C_c(j) := ∫₀¹ (λ^c + λ^{−c}) F^j F(1−λ)^{4−j} dλ,  μ₊(j₁, j₂) := det[[C_{2/3}(j₁), C_{2/3}(j₂)], [C_{1/3}(j₁), C_{1/3}(j₂)]]

  - **L(W, 3) = π⁴·μ₊(2,4)/2916**
  - **L(W, 5) = π⁸·μ₊(2,4)/629856**
  - शुद्ध period-संबंध: μ₊(0,2)/μ₊(2,4) = 32/3, μ₊(0,4)/μ₊(2,4) = 16, μ₋(1,3)/μ₊(2,4) = −1/2 (μ₋ म्हणजे S_c = λ^c − λ^{−c} वापरून).
  - ⇒ R = 2916/629856 = **1/216**: N4 चा निकाल स्वतंत्रपणे पुन्हा आला.
  - **Control:** एकाच period ने (determinant शिवाय) L(W,3) कधीच मिळत नाही (0 hits). हे d⁻ = 2 आणि W non-GL₂ या चित्राशी सुसंगत आहे.
- **Confirmation (N11):** निकाल खाली §६ मध्ये.

## ५ अर्थ
- **[संख्यात्मक]** W साठी Deligne च्या period conjecture ची संपूर्ण संरचना दिसते:
  - c⁻(W) = noncongruence weight-6 periods चा 2×2 determinant;
  - L(W, 3) आणि L(W, 5) हे त्याचे साधे rational × π-घात गुणक.
- **[sketch]** W हा cubic-cover noncongruence weight-6 forms च्या Scholl representation चा descent आहे. ही ओळख preprint मधल्या "Sym⁴, cubic twist" चित्राला एक नवीन, पण शास्त्रीय, भाषा देते.
- **Literature:** Scholl (1985), Atkin–Li–Long, Li–Liu–Long (2016): तिथे weight 3 / GL₂ / QM प्रकरणं आहेत. Non-GL₂ 4-dim, weight 6, आणि त्याच्या critical values चा period-determinant असं काम सापडलं नाही (to the best of our knowledge; web search पुरतं).
- **Bloch–Kato कडे पुढचं पाऊल:** 2916 = 2²·3⁶ आणि 629856 = 2⁵·3⁹. यात फक्त bad primes 2 आणि 3 येतात. पण ही संख्या आपल्या period-normalization वर अवलंबून आहे: λ^c, F, आणि [0,1] cycle. खरा Bloch–Kato प्रश्न विचारायला rational (integral) Betti आणि de Rham lattices निश्चित करावे लागतील [पुढचं काम].

## ६ Confirmation (N11) निकाल
- **Run 1: FAIL.** `N11_output_run1_FAIL.txt` मध्ये जपलं आहे. चुका दोन होत्या, आणि दोन्ही माझ्या script मधल्या होत्या:
  1. **Quadrature truncation:** weight 10⁻¹¹⁰ खाली गेल्यावर nodes थांबवले. पण λ^{−2/3} मुळे सुमारे 10⁻³⁷ योगदान राहून गेलं. त्यामुळे फक्त 31–37 अंक आले.
  2. **K1 चं चिन्ह:** S_{2/3} चं चिन्ह exploration च्या उलट लिहिलं गेलं. त्यामुळे −1/2 ऐवजी +1/2 आलं.
  - निकष आणि गणिती संबंध बदलले नाहीत.
- **Run 2 (v2): PASS** (`N11_output.txt`, 20 s)
  | चाचणी | अंक |
  |---|---|
  | K0 quadrature (level 8 vs 9) | ≥ 82.7 |
  | K1: μ₊(0,2)/μ₊(2,4) = 32/3, μ₊(0,4)/μ₊(2,4) = 16, μ₋(1,3)/μ₊(2,4) = −1/2 | 82.3, 82.4, 82.6 |
  | K2: L(W,3) = π⁴μ₊(2,4)/2916, L(W,5) = π⁸μ₊(2,4)/629856 | 54.8, 54.7 (मर्यादा: L(W) फक्त सुमारे 55 अंक, कारण a_n ≤ 4999) |
  | K3: k = 2 चे पाच control संबंध | 82.6 – 84.3 |
- μ₊(2,4) = 67.09632235820801778105117203253223057900685052056237774…

## ६b c⁺ आणि L(W, 4) (N13; exploration `explore_W4` नंतर निकष ठरवले) — PASS
- **L(W, 4) = π⁶·μ_C(1,3)/157464 = −π⁶·μ_S(0,2)/209952**, 54.3 अंक.
  - 157464 = 2³·3⁹ आणि 209952 = 2⁵·3⁸.
  - शुद्ध period-संबंध μ_S(0,2)/μ_C(1,3) = −4/3, 83.3 अंक.
- **Parity-रचना:**
  - c⁻ (s = 3, 5) ↔ {C-rows आणि सम j, किंवा S-rows आणि विषम j}
  - c⁺ (s = 4) ↔ {C-rows आणि विषम j, किंवा S-rows आणि सम j}
- ⇒ W चे **तिन्ही** स्वतंत्र critical values (s = 3, 4, 5) noncongruence period-determinants चे rational × π-घात गुणक आहेत [संख्यात्मक].
- μ_C(1,3) = 176.41243271864188051904031847163389506308878765006…

## ७ एकूण स्थिती आणि पुढे
- **[संख्यात्मक, 55 अंक]** L(W, 3) = (π⁴/2916)·det[[C_{2/3}(2), C_{2/3}(4)], [C_{1/3}(2), C_{1/3}(4)]].
  - म्हणजे W च्या central value साठी Deligne-प्रकारची rational structure: noncongruence elliptic-period moments चा determinant × π⁴ × rational.
  - Period-संबंध (K1) 82 अंकांपर्यंत टिकतात.
- **खुले प्रश्न:**
  1. k = 2 मधला g = 12.4.a.a, m = 1 चा संबंध.
  2. Rational lattices निश्चित करणं, म्हणजे 2916 चा अर्थ (Bloch–Kato).
  3. L(W, 4): c⁺ साठी हाच determinant, पण विरुद्ध parity चे cycles. म्हणजे S-rows आणि सम j, किंवा C-rows आणि विषम j तपासायचे [पुढचं, सोपं].
  4. L(W) ची precision वाढवणं (laptop वर p ≤ 20000 data). त्यामुळे K2 70+ अंकांपर्यंत नेता येईल.
- **Preprint v2 साठी** (दादांच्या निर्णयानंतर; submission चं काम GPT कडे):
  - "Observation 6.3 [numerical]: L(W,5)/(π⁴L(W,3)) = 1/216."
  - "Observation 6.4 [numerical]: L(W,3) = π⁴·μ/2916, जिथे μ हा noncongruence weight-6 periods चा determinant."
  - Scholl-representation ची ओळख [sketch] आणि literature (Scholl 1985; ALL; LLL 2016; Calegari–Dimitrov–Tang).
