# प्रगती log (जिवंत) — प्रत्येक टप्प्यानंतर अद्ययावत

नियम:
- नवीन नोंद नेहमी **शेवटी** जोडायची.
- प्रत्येक नोंदीत चार गोष्टी: तारीख, काय केलं, निकाल (खुणांसह), फाइल्स.
- शेवटचा "पुढचं काम" विभाग नेहमी चालू ठेवायचा.

---

## 2026-10-27 — E/F/G टप्पे
- E (Ahlgren–Ono D(p)), F (37a1 / 389a1 चे BSD आकडे): PASS.
- G (Q\* prior-art): FAIL (known machinery).

## 2026-10-27 / 28 — H टप्पा
- Order-n twists → family identity n = 3, 4, 6, आणि Livné sketch.
- V: USp(4).
- Laptop run (p ≤ 4999; 330 split, 337 inert): integrity PASS (H20, H21).

## 2026-10-28 — L टप्पा आणि P1
- L(W, s): N = 1296, ε = +1, L(W, 3) ≈ 2.2413552.
- Prior-art audit P1 केला.

## 2026-10-28 — प्रकाशन
- Zenodo publish झालं: DOI 10.5281/zenodo.23719224 (concept …23719223).
- ORCID link केलं.
- GPT साठी handoff zip दिला (`BSD_NEXT_ASSISTANT_HANDOFF_2026-10-28.zip`).
- दादांचा निर्णय: tokens असेपर्यंत Claude सोबत इथेच काम सुरू ठेवायचं. MASTER handoff तयार केला.

---

## 2026-10-28 — N1: journal निवड आणि कामाची विभागणी
- T&F (*Experimental Mathematics*): AI policy (26 ऑगस्ट 2026) नुसार AI ने first draft किंवा sections लिहिणं निषिद्ध. आपल्या preprint मध्ये drafting Claude च्या मदतीने झाल्याचं public disclosure आहे, म्हणून हे journal वगळलं. [ज्ञात policy]
- Springer: LLM लेखक असू शकत नाही; त्याचा वापर Methods किंवा Declarations मध्ये नोंदवायचा; drafting वर बंदी नाही; Zenodo preprint चालतो. [ज्ञात policy]
- **दादांचा निर्णय:** Springer. पहिली पसंती *Research in Number Theory* (hybrid; EiC: Balakrishnan, Luca, Ono, Sutherland). दुसरी पसंती *Ramanujan Journal*.
- **कामाची विभागणी:** submission चं सर्व काम GPT कडे. Claude सोबत फक्त संशोधन, नव्या chat मध्ये (RESEARCH handoff zip).
- दादांचा दुसरा Springer submission (वेगळा प्रकल्प) editor कडे आहे. तो या प्रकल्पाशी जोडायचा नाही (नियम 8).

---

## 2026-10-28 — R0 audit आणि R1 वाचन (नवीन RESEARCH chat)
- **R0:**
  - Critical-value / Deligne-period ची संख्यात्मक चाचणी ही पद्धत ज्ञात आहे: Dummigan–Watkins, Roberts, Spencer 2026, Rogers–Wan–Zucker, Bao 2026, Broadhurst. [ज्ञात literature]
  - W साठी (degree 4, {0,0,5,5}, N = 1296) ही चाचणी आधी प्रकाशित आढळली नाही ⇒ **audit PASS** (to the best of our knowledge; MathSciNet उपलब्ध नव्हतं).
- **बाजूचं निरीक्षण:** W = (weight-6 form) ⊗ (2-dim Artin) ही शक्यता moments मुळे वगळली जाते. अशा tensor साठी E[a⁴] ≥ 4 आणि E[a⁶] ≥ 25 हवेत; H21 मध्ये 2.84 आणि 12.98 आहेत. [sketch + संख्यात्मक]
- **R1:**
  - L1–L4 वाचले, एकही चालवला नाही.
  - a_n integers आहेत, n ≤ 4999 पर्यंत. 30 अंकांसाठी n ≈ 2000 पुरेसे; कमाल सुमारे 55 अंक ⇒ laptop ची गरज नाही.
  - L4 ची quad पद्धत फक्त ~10 अंक देते.
- **N2 script लिहिला (चालवला नाही):**
  - Closed-form Bessel integrals, mpmath, dps 40 आणि 60.
  - Controls C0–C3.
  - **C2 मध्ये बदल:** χ₋₃ ऐवजी χ₅. कारण ε(f⊗χ₋₃) = −1 ⇒ L(3) = 0 अपरिहार्यपणे.
- **फाइल्स:** `N_next/N2_check_LW_critical_ratio_FLOAT_2026-10-28.py`, `N_next/N3_notes_R0_audit_R1_reading_2026-10-28.md`.

---

## 2026-10-28 — R2: N2 चालवला (दादांची परवानगी: "Chalva")
- **Backend:** mpmath उपलब्ध नव्हता (PyPI blocked). म्हणून N2 Python `decimal` वर पुन्हा लिहिला: स्वतःचा K-Bessel trapezoid आणि lattice reduction. नवीन control CB जोडला.
- **Run 1: CB FAIL.** x = 160 वर Bessel 12–24 अंकच बरोबर आले (h स्थिर होता) ⇒ verdict NOT EVALUATED. चूक नोंदवली.
- **v3:** h आता x नुसार बदलतो ⇒ CB PASS.
- **Controls PASS:** R_f(4.6.a.a) = 1/8, R_{fχ₅} = 1/25, R_g = 1/200 = गुणाकार. ε सर्वत्र +1.
- **W:**
  - L(W,3) = 2.2413552032364396058796…
  - L(W,4) = 1.0770779760963316622…
  - L(W,5) = 1.0107795047758952764…
  - **R = L(W,5)/(π⁴L(W,3)) = 1/216 = 2⁻³3⁻³**: 50–57 अंक, dps 40/60 आणि n ≤ 4000/4999 वर स्थिर ⇒ **PASS [संख्यात्मक]**.
- **फाइल्स:** `N_next/N2_…_FLOAT_2026-10-28.py` (v3), `N2_output.txt`, `N2_output_run1_CB_FAIL.txt`, `N4_notes_LW_critical_ratio_result_2026-10-28.md`.

---

## पुढचं काम (चालू)
- [x] R0: मार्ग B चं prior-art audit — PASS (N3).
- [x] R1: L-stage scripts वाचले; N2 लिहिला आणि controls PASS.
- [x] R2: R = 1/216 — PASS [संख्यात्मक] (N4).
- [ ] R2b: PARI/GP ने स्वतंत्र तपासणी. `N5_PARI_runner_2026-10-28.zip` दादांना दिला: .gp script, W चे a_n, आणि one-click runners. PASS/FAIL P1–P4 आधी ठरवले. Script इथे चालवून पाहिलेला नाही (इथे gp नाही) ⇒ laptop वरचा `N5_output.txt` आल्यावर N7 notes.
- [x] N6: प्रकल्पाचा कालक्रम (ऑगस्ट v1–v14 → ऑक्टोबर) नोंदवला. 26 ऑगस्ट ते 26 ऑक्टोबर या काळातल्या फाइल्स [माहीत नाही].
- [x] N6 v2 (23–25 ऑगस्टच्या zip चा deep scan):
  - 85 unique फाइल्स, त्यापैकी 79 R2 मध्ये आधीच आहेत. नवीन BSD फाईल एकही नाही. फाइल्सच्या मूळ तारखा हरवल्या.
  - **D₂′ = D − 1 सिद्ध** (S₃-सममिती).
  - v12 मधली A = D तुलना पूर्ण: A = −a(p) − p. B = χ(−1)A (v12 मध्ये "सर्व primes" ही चूक होती).
  - V = a_p(16.3.c.a) = η(4z)⁶ [संख्यात्मक, p < 520].
  - BSD-पूल: Rosen–Silverman (rank 0) आणि Ulmer (function fields वर Legendre curve साठी BSD सिद्ध).
- [x] N7/N8: Legendre curve वर F_q(t^{1/d}), function-field BSD rank-बाजू (Ulmer):
  - आपल्या point counts ने L = (1 − qT)^{d−2}, म्हणजे rank 2, 4, 6. Controls rank 0. सर्व **PASS** [संख्यात्मक + ज्ञात literature].
  - U4 आणि U5 अंशतः.
- [x] N6 v3 (`claude_x.zip`, 30 जुलै – 28 ऑगस्ट):
  - 57 nested zips, 2956 फाइल्स, 746 unique; 538 नवीन, पण नवीन BSD फाईल 0.
  - **मूळ तारखा:** Legendre धागा 24 ऑगस्ट ते 25 ऑगस्ट 09:53. सर्व नोंदी 28 ऑगस्ट 20:44 ला संपतात (ChatGPT कडे हस्तांतर). 29 ऑगस्ट ते 26 ऑक्टोबर [माहीत नाही].
  - **धाग्याचं मूळ:** G_{p,1} fourth-moment गणनेत S′(m) = Frobenius trace (transcript).
  - **"Millennium" scan:** कोणत्याही Clay प्रश्नाचा उल्लेख नाही.
  - Paley-θ चा "θ ≤ 1 + √p" हा ज्ञात √p पेक्षा कमकुवत आहे (नियम 8: स्वतंत्र chat मध्ये पुनर्तपासणी सुचवली).
  - फाइल्स: `N6_inventory_claude_x_2026-10-28.csv`, `N6_hypothesis_index_claude_x_2026-10-28.txt`.
- [~] R4: L(W,4) / c⁺. **पुनर्विचार:** c⁺c⁻ हे δ(W) (शुद्ध π-घात) ने ठरत नाही. Weight-6 form साठी सुद्धा ω⁺ω⁻ ~ Petersson norm (L(ad, 1)) येतो. ⇒ "L(3)·L(4)/π^k ∈ Q" ही चाचणी अपेक्षेप्रमाणेच FAIL होईल; ती घ्यायची नाही. R4 हा R5 मध्ये विलीन.
- [x] **R5 (N9–N12):** c⁻(W) भूमितीतून.
  - **(a) Quadratic control:** periods = 64, 16, 8 × L(8.4.a.a) — 63 अंक, PASS.
  - **(b) Cubic, k = 2:** periods चं q-series noncongruence निघालं (unbounded 3-denominators).
    - N10 चा 2-term प्रयत्न FAIL.
    - Exploration: बेरीज ↔ 36.4.a.a, फरक ↔ 12.4.a.a.
    - g साठी m = 1 उघडा.
  - **(c) W:** σ-paired determinant ⇒ **L(W,3) = π⁴μ₊/2916, L(W,5) = π⁸μ₊/629856** (55 अंक); शुद्ध period-संबंध 82 अंक.
    - N11 run 1 FAIL (script bugs), run 2 PASS.
    - [संख्यात्मक]; W = Scholl rep descent [sketch].
- [x] R5b (N13): **L(W,4) = π⁶μ_C(1,3)/157464** (54 अंक). Period-संबंध −4/3 (83 अंक). PASS.
- [x] R5c (N14/N15): **W′ = W⊗χ₋₃**: N = 432, ε = −1, P₃ = 1 − 3T (FE 74 अंक, एकमेव fit).
  - ⇒ **L(W′,3) = 0** (center वर विषम order; Bloch–Kato मधला "rank ≥ 1" analogue [अंदाज]).
  - L(W′,4) आणि L(W′,5) periods मधून 80 अंकांपर्यंत (Deligne twist-नियम: c⁺ ↔ c⁻). PASS.
  - पहिला शोध (P₃ = 1) FAIL; नोंदवला.
- [x] N16: **L′(W′,3) = 2.478248659786283973711631814697856615678…** (75 अंक; closed form).
  - Simple zero.
  - Periods चा rational गुणक नाही (negative control अपेक्षेप्रमाणे).
  - Run 1 मध्ये D3 ची पडताळणी नव्हती; नोंदवलं आणि दुरुस्त केलं.
- [x] N17: a_n ≤ 20000 इथेच (22 s; F_{p²} गणना टाळली). जुन्या data शी तंतोतंत. PASS.
- [x] N18 (dps 100): सर्व period-संबंध **110 अंकांपर्यंत**.
  - Script चा VERDICT FAIL, फक्त H3 मुळे: माझ्या निकषात 50-अंकी reference होता (नोंदवलं).
- [x] LMFDB: degree 4, conductor 432 → "No matches" (दादांचा screenshot; Release 1.2.1) ⇒ W′ LMFDB मध्ये नाही.
- [ ] पुढे: rational lattices ⇒ 2916 इ. चा Bloch–Kato अर्थ; g चा m = 1 प्रश्न.
- [ ] Prior-art (R5 साठी): Scholl motives / noncongruence forms चे critical values. Web search मध्ये थेट काम सापडलं नाही; MathSciNet मध्ये पुन्हा तपासायचं.
- [ ] R5 (मोठं): c⁻(W) भूमितीतून ⇒ L(W,3)/c⁻ ⇒ Bloch–Kato तुलना (Dummigan–Watkins पद्धत).
- [ ] R3: मार्ग A — 37a1 Heegner / Gross–Zagier (PASS/FAIL निकष आधी ठरवायचे).
