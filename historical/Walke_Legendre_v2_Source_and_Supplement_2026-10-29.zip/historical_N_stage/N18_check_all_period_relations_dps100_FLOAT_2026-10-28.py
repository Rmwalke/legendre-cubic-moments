"""N18 (FLOAT) — all period relations at ~100 digits, using a_n (n <= 20000) from N17.
 Criteria fixed before running (the relations themselves are those of N11/N13/N14):
   H0  FE t0-independence (t0 = 1 vs 1.1) at s = 4, 5:  W (N=1296, eps=+1) and W' (N=432, eps=-1, P_3 = 1-3T)  >= 90 digits.
   H1  L(W,3)  = pi^4 muC(2,4)/2916     L(W,4) = pi^6 muC(1,3)/157464     L(W,5) = pi^8 muC(2,4)/629856
       L(W',4) = pi^6 muC(2,4)/69984    L(W',5) = pi^8 muC(1,3)/1679616                       each >= 90 digits
   H2  pure periods: muC(0,2)/muC(2,4) = 32/3, muC(0,4)/muC(2,4) = 16, muS(1,3)/muC(2,4) = -1/2, muS(0,2)/muC(1,3) = -4/3  >= 95
   H3  L(W',3) = 0 (|.| < 1e-90) and L'(W',3) (N16 value 2.47824865978628397371163...) reproduced to >= 70 digits.
Usage: python -I N18_...py N17_W_an_upto_20000.txt
"""
import sys, math, time
T0 = time.time()
an = [0] + [int(l) for l in open(sys.argv[1])]
NM = len(an) - 1
n2 = open('N2_check_LW_critical_ratio_FLOAT_2026-10-28.py').read().split('# ================================================================ main')[0]
ns = {'__name__': 'n2'}; exec(compile(n2, 'n2', 'exec'), ns)
chi3 = lambda n: (0, 1, -1)[n % 3]
At = [0] * (NM + 1)
for n in range(1, NM + 1):
    v, m = 0, n
    while m % 3 == 0: m //= 3; v += 1
    At[n] = an[m] * chi3(m) * 3 ** v
ns['set_dps'](100); D = ns['D']; dg = ns['digits']
h0 = {}
for nm, A, N, e in (('W', an, 1296, 1), ("W'", At, 432, -1)):
    h0[nm] = min(dg(ns['Lam'](A, N, e, s, 4, D(1)), ns['Lam'](A, N, e, s, 4, D('1.1'))) for s in (4, 5))
print('H0 FE digits', {k: round(v, 1) for k, v in h0.items()}, f'[{time.time() - T0:.0f}s]', flush=True)
LW = {s: ns['L_of'](an, 1296, 1, s, 4) for s in (3, 4, 5)}
LT = {s: ns['L_of'](At, 432, -1, s, 4) for s in (3, 4, 5)}
for s in (3, 4, 5): print(f'  L(W,{s}) = {format(LW[s], ".95g")}')
for s in (4, 5): print(f"  L(W',{s}) = {format(LT[s], '.95g')}")
# central derivative of W' (N16 closed form)
HP, kpair = ns['HP'], ns['kpair']
def IJ(s, Y, K0, K1):
    lY = Y.ln(); I = Y * K1; J = Y * K1 * lY + K0
    for m in range(1, s):
        Jn = Y ** (2 * m + 1) * K1 * lY + 2 * m * (Y ** (2 * m) * K0 * lY + 2 * m * J + I) + Y ** (2 * m) * K0 + 2 * m * I
        I = Y ** (2 * m + 1) * K1 + 2 * m * Y ** (2 * m) * K0 + 4 * m * m * I; J = Jn
    return I, J
def dG(s, n, N, t0):
    Y, K0, K1 = kpair(n, N, t0); I, J = IJ(s, Y, K0, K1); c = D(n) / D(N).sqrt(); pi = HP['pi']
    return 4 * (16 * pi ** 2 * c) ** (-s) * (2 * J - (16 * pi ** 2 * c).ln() * I)
dL = sum(At[n] * (dG(3, n, 432, D(1)) + dG(3, n, 432, D(1))) for n in range(1, NM + 1) if At[n])
Lp = dL / (D(432).sqrt() ** 3 * (2 * HP['pi']) ** (-6) * 4)
h3 = (abs(LT[3]) < D(10) ** -90, dg(Lp, D('2.4782486597862839737116318146978566156781118923558')))
print(f"H3 L(W',3)=0: {h3[0]};  L'(W',3) = {format(Lp, '.95g')}  (vs N16: {h3[1]:.1f} digits)  [{time.time() - T0:.0f}s]", flush=True)
# periods at dps 100 (N11 machinery, levels 9/10)
src = open('N11_check_W_Deligne_period_determinant_FLOAT_2026-10-28.py').read().split('mu = lambda A, B')[0]
src = src.replace('DPS = 70;', 'DPS = 100;').replace('integral(8, ex, j, 4), integral(9, ex, j, 4)', 'integral(9, ex, j, 4), integral(10, ex, j, 4)')
pn = {}; exec(src, pn); V, PI, Dp, dig = pn['V'], pn['PI'], pn['D'], pn['dig']
mu = lambda X, Y, j1, j2: V[(X, j1)] * V[(Y, j2)] - V[(X, j2)] * V[(Y, j1)]
mC24, mC13, mC02, mC04 = mu('C2/3', 'C1/3', 2, 4), mu('C2/3', 'C1/3', 1, 3), mu('C2/3', 'C1/3', 0, 2), mu('C2/3', 'C1/3', 0, 4)
mS13, mS02 = mu('S2/3', 'S1/3', 1, 3), mu('S2/3', 'S1/3', 0, 2)
P = lambda x: Dp(str(x))
h1 = [dig(PI ** 4 * mC24 / 2916, P(LW[3])), dig(PI ** 6 * mC13 / 157464, P(LW[4])), dig(PI ** 8 * mC24 / 629856, P(LW[5])),
      dig(PI ** 6 * mC24 / 69984, P(LT[4])), dig(PI ** 8 * mC13 / 1679616, P(LT[5]))]
h2 = [dig(mC02 / mC24, Dp(32) / 3), dig(mC04 / mC24, Dp(16)), dig(mS13 / mC24, Dp(-1) / 2), dig(mS02 / mC13, Dp(-4) / 3)]
print('H1 eight-in-five L-value relations: digits', [round(x, 1) for x in h1])
print('H2 pure period relations: digits', [round(x, 1) for x in h2])
ok = min(h0.values()) >= 90 and min(h1) >= 90 and min(h2) >= 95 and h3[0] and h3[1] >= 70
print('VERDICT:', 'PASS' if ok else 'FAIL', f'  time {time.time() - T0:.0f}s')
