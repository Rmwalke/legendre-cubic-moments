"""N16 v2 (run 1: D3 lacked the high-precision confirmation step -> spurious float hits; fixed)
 N16 (FLOAT) — the central derivative L'(W', 3), W' = W (x) chi_{-3} (N = 432, eps = -1, so L(W',3) = 0).
 Closed form (no quadrature in t), integration by parts:
   J_m(Y) := int_Y^inf y^{2m+1} K_0(y) ln y dy,  J_0 = Y K_1 ln Y + K_0,
   J_m = Y^{2m+1} K_1 ln Y + 2m (Y^{2m} K_0 ln Y + 2m J_{m-1} + I_{m-1}) + Y^{2m} K_0 + 2m I_{m-1}   (I_m as in N2).
   dG/ds (s; c, t0) = 4 (16 pi^2 c)^{-s} [2 J_{s-1}(Y) - ln(16 pi^2 c) I_{s-1}(Y)],  Y = 4 pi sqrt(c t0).
   eps = -1:  Lambda'(3) = sum a_n [G'(3; c_n, t0) + G'(3; c_n, 1/t0)],  L'(3) = Lambda'(3) / (N^{3/2} (2pi)^{-6} Gamma(3)^2).
 Criteria fixed before running:
   D1  t0-independence of Lambda'(3) (t0 = 1 vs 1.1) >= 50 digits at dps 70; the derivative must be NONZERO.
   D2  control of the J-recursion: J_m(Y) vs a direct tanh-sinh quadrature at Y = 2, m = 0..2, >= 50 digits.
   D3  (negative control; expectation, not a claim) L'(W',3) pi^e / (b * period determinant) is NOT a rational with q <= 1e6
       for e in -12..12, b in {1, sqrt3}, determinants muC/muS of N11: Beilinson-Bloch predicts a height/regulator there.
 Usage: python -I N16_...py H13_output_data_laptop_p_upto_4999.txt
"""
import sys, math
from fractions import Fraction
n2 = open('N2_check_LW_critical_ratio_FLOAT_2026-10-28.py').read().split('# ================================================================ main')[0]
ns = {'__name__': 'n2'}; exec(compile(n2, 'n2', 'exec'), ns)
AW, NM, _ = ns['w_coefficients'](sys.argv[1]); chi3 = lambda n: (0, 1, -1)[n % 3]
A = [0] * (NM + 1)
for n in range(1, NM + 1):
    v, m = 0, n
    while m % 3 == 0: m //= 3; v += 1
    A[n] = AW[m] * chi3(m) * 3 ** v
ns['set_dps'](70); D = ns['D']; HP = ns['HP']; dg = ns['digits']; kpair = ns['kpair']
def IJ(s, Y, K0, K1):
    lY = Y.ln(); I = Y * K1; J = Y * K1 * lY + K0
    for m in range(1, s):
        Jn = Y ** (2 * m + 1) * K1 * lY + 2 * m * (Y ** (2 * m) * K0 * lY + 2 * m * J + I) + Y ** (2 * m) * K0 + 2 * m * I
        I = Y ** (2 * m + 1) * K1 + 2 * m * Y ** (2 * m) * K0 + 4 * m * m * I
        J = Jn
    return I, J
def dG(s, n, N, t0):
    Y, K0, K1 = kpair(n, N, t0); I, J = IJ(s, Y, K0, K1)
    c = D(n) / D(N).sqrt(); pi = HP['pi']
    return 4 * (16 * pi ** 2 * c) ** (-s) * (2 * J - (16 * pi ** 2 * c).ln() * I)
def dLam3(N, t0):
    return sum(A[n] * (dG(3, n, N, t0) + dG(3, n, N, 1 / t0)) for n in range(1, NM + 1) if A[n])
d1 = dLam3(432, D(1)); d2 = dLam3(432, D('1.1'))
pi = HP['pi']
Lp = d1 / (D(432).sqrt() ** 3 * (2 * pi) ** (-6) * 4)
print(f"D1 Lambda'(3): t0=1 vs 1.1 agree to {dg(d1, d2):.1f} digits;  L'(W',3) = {format(Lp, '.50g')}")
# D2: direct quadrature check of J_m at Y = 2
def quad_J(m, Y, level=8):
    # int_Y^inf y^{2m+1} K0(y) ln y dy  with y = Y + u, u in (0, inf) via exp-sinh: u = exp(pi/2 sinh t)
    h = D(1) / D(2 ** level); tot = D(0); k = -int(6 / float(h))
    while k <= int(6 / float(h)):
        t = h * k; et = t.exp(); sh = (et - 1 / et) / 2; ch = (et + 1 / et) / 2
        u = (pi / 2 * sh).exp(); y = Y + u
        if y < 400:
            K0 = ns['besselK'](0, y)
            tot += y ** (2 * m + 1) * K0 * y.ln() * u * pi / 2 * ch * h
        k += 1
    return tot
Y = D(2); K0, K1 = ns['besselK'](0, Y), ns['besselK'](2, Y)
d2c = []
for s in (1, 2, 3):
    I, J = IJ(s, Y, K0, K1); q = quad_J(s - 1, Y); d2c.append(dg(J, q))
print('D2 J-recursion vs quadrature (m = 0, 1, 2): digits', [round(x, 1) for x in d2c])
# D3 negative control
src = open('N11_check_W_Deligne_period_determinant_FLOAT_2026-10-28.py').read().split('mu = lambda A, B')[0]
pn = {}; exec(src, pn); V, PI = pn['V'], pn['PI']; Dp = pn['D']
mu = lambda X, Y_, j1, j2: V[(X, j1)] * V[(Y_, j2)] - V[(X, j2)] * V[(Y_, j1)]
dets = {f'{X},{Y_},{j1}{j2}': mu(X, Y_, j1, j2) for X in ('C2/3', 'S2/3') for Y_ in ('C1/3', 'S1/3') for j1 in range(5) for j2 in range(j1 + 1, 5)}
hits = []
for nm, m_ in dets.items():
    for e in range(-12, 13):
        for b in (1, math.sqrt(3)):
            xf = float(Lp) * math.pi ** e / (b * float(m_)); fr = Fraction(xf).limit_denominator(10 ** 6)
            if fr.numerator and abs(float(fr) - xf) < 1e-12 * abs(xf):
                xd = Dp(str(Lp)) * PI ** e / ((Dp(3).sqrt() if b != 1 else Dp(1)) * m_)   # v2: 35-digit Decimal confirmation (missing in run 1)
                if pn['dig'](xd, Dp(fr.numerator) / Dp(fr.denominator)) >= 35: hits.append((nm, e, b, str(fr)))
print('D3 negative control (expect none): rational hits', hits)
ok = dg(d1, d2) >= 50 and abs(Lp) > D(10) ** -10 and min(d2c) >= 50
print('VERDICT D1+D2:', 'PASS' if ok else 'FAIL', '| D3:', 'as expected (none)' if not hits else 'UNEXPECTED hits — investigate')
