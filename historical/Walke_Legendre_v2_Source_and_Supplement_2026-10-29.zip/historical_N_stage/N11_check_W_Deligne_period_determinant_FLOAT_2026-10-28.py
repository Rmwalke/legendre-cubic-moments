"""N11 v2 (run 1 FAILED: quadrature truncated at w < 1e-110 and K1 sign convention of S mistyped; both fixed, criteria unchanged)
 N11 (FLOAT, Python decimal) — CONFIRMATION run (criteria fixed from the N10-exploration, before this run).
 R5 stage (c): Deligne period for W from weight-6 NONCONGRUENCE periods of the cubic Legendre cover.
   F(x) = 2F1(1/2,1/2;1;x) = 1/AGM(1, sqrt(1-x)),  C_c(j) := int_0^1 (lambda^c + lambda^{-c}) F(lambda)^j F(1-lambda)^{4-j} d lambda,
   S_c(j) := int_0^1 (sign_c)(lambda^c - lambda^{-c}) [v2: S_{2/3} = lambda^{-2/3} - lambda^{2/3}, S_{1/3} = lambda^{1/3} - lambda^{-1/3}, as in the exploration] F(lambda)^j F(1-lambda)^{4-j} d lambda   (c = 1/3, 2/3; j = 0..4).
   Origin [sketch]: weight-6 cusp forms lambda^e (1-lambda) theta_3^12 on the cubic cover (e = 1/3, 4/3 | 2/3, 5/3), periods
   int_0^1 lambda^{e-1} F^j F(1-lambda)^{4-j}; the descent involution sigma: lambda -> 1/lambda acts by eta_e -> -eta_{2-e},
   so the sigma-paired combinations are lambda^{-2/3} +- lambda^{2/3} and lambda^{-1/3} +- lambda^{1/3}.
   mu+(j1,j2) := det [[C_{2/3}(j1), C_{2/3}(j2)], [C_{1/3}(j1), C_{1/3}(j2)]];  mu-(1,3) := det with S in place of C.
 Criteria (from exploration; this run uses higher precision dps 70 and quadrature levels 8/9, independent of N10's 6/7):
   K0  quadrature: level 8 vs 9 agree to >= 60 digits for all 20 integrals.
   K1  pure period relations (no L-values):  mu+(0,2)/mu+(2,4) = 32/3,  mu+(0,4)/mu+(2,4) = 16,  mu-(1,3)/mu+(2,4) = -1/2
       to >= 60 digits.
   K2  L(W,3) = pi^4 mu+(2,4)/2916  and  L(W,5) = pi^8 mu+(2,4)/629856  to >= 50 digits (L(W,s) from N2: ~55 digits).
   K3  control (k = 2, from N10-exploration): with c_k2(j) := int_0^1 (lambda^{-1/3} + lambda^{-2/3}) F^j F(1-lambda)^{2-j},
       s_k2(j) := int_0^1 (lambda^{-2/3} - lambda^{-1/3}) F^j F(1-lambda)^{2-j}:
       c_k2(2) = 3 L(f36,1),  c_k2(1) = 18 L(f36,2)/pi,  c_k2(0) = 144 L(f36,3)/pi^2;
       s_k2(1) = 12 L(g,2)/pi,  s_k2(0) = 96 L(g,3)/pi^2  (f36 = 36.4.a.a, g = 12.4.a.a) to >= 55 digits.
       (m = 1 for g has NO relation found — recorded as open; not part of the criteria.)
 A PASS is [numerical]. It supports Deligne's conjecture for W; it is not a proof.
"""
import math, time
from decimal import Decimal as D, getcontext
DPS = 70; getcontext().prec = DPS + 15; T0 = time.time()
def pi_dec():
    P = getcontext().prec; scale = 10 ** (P + 10)
    def atan_inv(x):
        total = term = scale // x; x2 = x * x; k = 1; sg = 1
        while term:
            term //= x2; k += 2; sg = -sg; total += sg * (term // k)
        return total
    return D(16 * atan_inv(5) - 4 * atan_inv(239)) / D(scale)
PI = pi_dec(); EPS = D(10) ** (-(DPS + 10))
def agm(a, b):
    while abs(a - b) > EPS * a: a, b = (a + b) / 2, (a * b).sqrt()
    return (a + b) / 2
def F(x, omx): return 1 / agm(D(1), omx.sqrt())
NODES = {}
def nodes(level):
    if level in NODES: return NODES[level]
    h = D(1) / D(2 ** level); out = []; k = 0
    while True:
        done = True
        for sgn in ((1,) if k == 0 else (1, -1)):
            t = h * k * sgn; et = t.exp(); ch = (et + 1 / et) / 2; sh = (et - 1 / et) / 2
            e2 = (-2 * (PI / 2 * sh)).exp(); x = 1 / (1 + e2); omx = e2 / (1 + e2)
            if x == 0 or omx == 0: continue
            w = PI * x * omx * ch * h
            if w > D(10) ** (-(3 * DPS + 60)): done = False   # v2: lambda^{-2/3} needs lambda down to ~1e-(3 DPS)
            out.append((x, omx, w, x.ln(), F(x, omx), F(omx, x)))
        if done and k > 10: break
        k += 1
    NODES[level] = out; return out
def integral(level, expo_list, j, kk):
    """sum over signs: int_0^1 (sum_i s_i lambda^{e_i}) F^j F'^{kk-j}"""
    tot = D(0)
    for x, omx, w, lnx, Fx, Fo in nodes(level):
        g = sum(s * (lnx * e).exp() for s, e in expo_list)
        tot += g * Fx ** j * Fo ** (kk - j) * w
    return tot
dig = lambda a, b: float(-((abs(a - b) / abs(b)).log10())) if a != b else DPS
third = D(1) / 3; two3 = D(2) / 3
spec = {'C2/3': [(1, two3), (1, -two3)], 'C1/3': [(1, third), (1, -third)],
        'S2/3': [(1, -two3), (-1, two3)], 'S1/3': [(1, third), (-1, -third)]}   # v2: = exploration rows (l^-2/3 - l^2/3, l^1/3 - l^-1/3)
V = {}; k0 = []
for nm, ex in spec.items():
    for j in range(5):
        a8, a9 = integral(8, ex, j, 4), integral(9, ex, j, 4)
        V[(nm, j)] = a9; k0.append(dig(a8, a9))
print(f'K0 quadrature (level 8 vs 9): min {min(k0):.1f} digits  [{time.time() - T0:.0f}s]')
mu = lambda A, B, j1, j2: V[(A, j1)] * V[(B, j2)] - V[(A, j2)] * V[(B, j1)]
m24 = mu('C2/3', 'C1/3', 2, 4); m02 = mu('C2/3', 'C1/3', 0, 2); m04 = mu('C2/3', 'C1/3', 0, 4); mm13 = mu('S2/3', 'S1/3', 1, 3)
k1 = [dig(m02 / m24, D(32) / 3), dig(m04 / m24, D(16)), dig(mm13 / m24, D(-1) / 2)]
print('K1 pure period ratios (32/3, 16, -1/2): digits', [round(x, 1) for x in k1])
LW3 = D('2.241355203236439605879618666060345021634663845711378470')
LW5 = D('1.010779504775895276424758858414728530036032268915172553')
k2 = [dig(PI ** 4 * m24 / 2916, LW3), dig(PI ** 8 * m24 / 629856, LW5)]
print('K2 L(W,3), L(W,5) from the determinant: digits', [round(x, 1) for x in k2])
print('   mu+(2,4) =', format(m24, '.60g'))
# ---- K3 control (k = 2)
def eta_prod(spec_, N=1500):
    lead = sum(m * e for m, e in spec_); s = lead // 24
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec_:
        for nn in range(1, N // m + 1):
            for _ in range(abs(e)):
                if e > 0:
                    for i in range(N, m * nn - 1, -1): P[i] -= P[i - m * nn]
                else:
                    for i in range(m * nn, N + 1): P[i] += P[i - m * nn]
    return ([0] * s + P)[:N + 1]
f36 = [x - 3 * y for x, y in zip(eta_prod([(6, 14), (2, -3), (18, -3)]), eta_prod([(2, 3), (6, 2), (18, 3)]))]
chi3 = lambda n: (0, 1, -1)[n % 3]
g = [0] * len(f36)
for n in range(1, len(f36)):
    v, m = 0, n
    while m % 3 == 0: m //= 3; v += 1
    g[n] = f36[m] * chi3(m) * 3 ** v
def upper_gamma_int(s, z):
    term = D(1); tot = D(1)
    for j in range(1, s): term = term * z / j; tot += term
    return math.factorial(s - 1) * (-z).exp() * tot
def Lval(a, N, eps, s, kwt=4):
    sq = D(N).sqrt(); tot = D(0)
    for n in range(1, len(a)):
        if a[n]:
            c = D(n) / sq
            tot += a[n] * ((2 * PI * c) ** (-s) * upper_gamma_int(s, 2 * PI * c) + eps * (2 * PI * c) ** (-(kwt - s)) * upper_gamma_int(kwt - s, 2 * PI * c))
    return tot / (sq ** s * (2 * PI) ** (-s) * math.factorial(s - 1))
ck = {j: integral(9, [(1, -third), (1, -two3)], j, 2) for j in range(3)}
sk = {j: integral(9, [(1, -two3), (-1, -third)], j, 2) for j in range(3)}
k3 = [dig(ck[2], 3 * Lval(f36, 36, 1, 1)), dig(ck[1], 18 * Lval(f36, 36, 1, 2) / PI), dig(ck[0], 144 * Lval(f36, 36, 1, 3) / PI ** 2),
      dig(sk[1], 12 * Lval(g, 12, 1, 2) / PI), dig(sk[0], 96 * Lval(g, 12, 1, 3) / PI ** 2)]
print('K3 control k=2 (five relations): digits', [round(x, 1) for x in k3])
ok = min(k0) >= 60 and min(k1) >= 60 and min(k2) >= 50 and min(k3) >= 55
print('VERDICT:', 'PASS' if ok else 'FAIL', f'  time {time.time() - T0:.0f}s')
