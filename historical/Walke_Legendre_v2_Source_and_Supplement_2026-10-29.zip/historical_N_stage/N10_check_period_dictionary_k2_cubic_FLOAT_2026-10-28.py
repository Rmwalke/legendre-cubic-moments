"""N10 (FLOAT, Python decimal) — R5 stage (b): cubic twist, k = 2. Noncongruence periods vs a congruence L-function.
 I(alpha, j) := int_0^1 lambda^{alpha-1} F(lambda)^j F(1-lambda)^{2-j} d lambda,  alpha in {1/3, 2/3}, j = 0, 1, 2.
 By the N9 dictionary  I(alpha, j) = pi * int_0^inf G_alpha(iy) y^{m-1} dy,  m = 3 - j,
 G_alpha = lambda^alpha (1-lambda) theta_3^8 — weight-4 forms whose q-series have UNBOUNDED 3-power denominators
 (explore output) => noncongruence (Calegari–Dimitrov–Tang) [numerical, small range].
 Expectation [sketch/conjecture: Scholl; Deligne]: the psi-part of H^1(U, Sym^2 F (x) L_psi) has the same Galois
 representation as h in {36.4.a.a, 36.4.a.a (x) chi_{-3}} (L1, preprint), so L(h, m) should be an algebraic multiple
 of pi^e * (a combination of) I(1/3, 3-m), I(2/3, 3-m).
 PASS/FAIL fixed before running:
   P0  levels: f36 has eps found by the t0-test (>= 40 digits); f36 (x) chi_{-3}: level N in {36, 108, 324} found the same way.
   P1  for every m in {1,2,3}: some h, e in {-3..3}, alpha, and b in {1, 2^{1/3}, 2^{2/3}} x {1, sqrt 3} give
       L(h,m) pi^e / (b I(alpha, 3-m)) = p/q with q <= 10^4, >= 35 digits, the SAME (h, alpha, b) pattern for all m
       (e may depend on m).   Otherwise: 2-term FAIL -> report (then a multi-term LLL search is the next step).
 Usage: python -I N10_...py
"""
import math, time, itertools
from decimal import Decimal as D, getcontext, ROUND_FLOOR
DPS = 50; getcontext().prec = DPS + 15; T0 = time.time()
def pi_dec():
    P = getcontext().prec; scale = 10 ** (P + 10)
    def atan_inv(x):
        total = term = scale // x; x2 = x * x; k = 1; sg = 1
        while term:
            term //= x2; k += 2; sg = -sg; total += sg * (term // k)
        return total
    return D(16 * atan_inv(5) - 4 * atan_inv(239)) / D(scale)
PI = pi_dec(); EPS = D(10) ** (-(DPS + 10))
def agm(a, b):
    while abs(a - b) > EPS * a: a, b = (a + b) / 2, (a * b).sqrt()
    return (a + b) / 2
def F(x, omx): return 1 / agm(D(1), omx.sqrt())
def tanh_sinh(fn, level):
    h = D(1) / D(2 ** level); total = D(0); k = 0
    while True:
        done = True
        for sgn in ((1,) if k == 0 else (1, -1)):
            t = h * k * sgn; et = t.exp(); ch = (et + 1 / et) / 2; sh = (et - 1 / et) / 2
            e2 = (-2 * (PI / 2 * sh)).exp(); x = 1 / (1 + e2); omx = e2 / (1 + e2)
            if x == 0 or omx == 0: continue
            term = fn(x, omx) * PI * x * omx * ch; total += term
            if abs(term) > D(10) ** (-(DPS + 12)): done = False
        if done and k > 10: break
        k += 1
    return total * h
dig = lambda a, b: float(-((abs(a - b) / abs(b)).log10())) if a != b else DPS
def cbrt(x): return (x.ln() / 3).exp()

# ---- 36.4.a.a (L1 eta expression) and its chi_{-3} twist
NM = 1500
def eta_prod(spec, N=NM):
    lead = sum(m * e for m, e in spec); s = lead // 24
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec:
        for nn in range(1, N // m + 1):
            for _ in range(abs(e)):
                if e > 0:
                    for i in range(N, m * nn - 1, -1): P[i] -= P[i - m * nn]
                else:
                    for i in range(m * nn, N + 1): P[i] += P[i - m * nn]
    return ([0] * s + P)[:N + 1]
f36 = [x - 3 * y for x, y in zip(eta_prod([(6, 14), (2, -3), (18, -3)]), eta_prod([(2, 3), (6, 2), (18, 3)]))]
assert f36[1:8] == [1, 0, 0, 0, 18, 0, 8]
chi3 = lambda n: (0, 1, -1)[n % 3]
f36t = [a * chi3(n) for n, a in enumerate(f36)]
print(f'coefficients ready ({time.time() - T0:.0f}s)')

def upper_gamma_int(s, z):
    term = D(1); tot = D(1)
    for j in range(1, s): term = term * z / j; tot += term
    return math.factorial(s - 1) * (-z).exp() * tot
def Lam(a, N, eps, s, t0, kwt=4):
    sq = D(N).sqrt(); tot = D(0)
    for n in range(1, len(a)):
        if a[n]:
            c = D(n) / sq
            tot += a[n] * ((2 * PI * c) ** (-s) * upper_gamma_int(s, 2 * PI * c * t0)
                           + eps * (2 * PI * c) ** (-(kwt - s)) * upper_gamma_int(kwt - s, 2 * PI * c / t0))
    return tot
def fe_fit(a, Ns):
    best = None
    for N in Ns:
        for e in (1, -1):
            dd = min(dig(Lam(a, N, e, s, D(1)), Lam(a, N, e, s, D('1.15'))) for s in (1, 2))
            if best is None or dd > best[0]: best = (dd, N, e)
    return best
P0 = {}
for name, a in (('f36', f36), ('f36(x)chi-3', f36t)):
    dd, N, e = fe_fit(a, (36, 108, 324))
    P0[name] = (N, e, dd); print(f'P0 {name}: N={N} eps={e} FE digits {dd:.1f}')
Lval = {}
for name, a in (('f36', f36), ('f36(x)chi-3', f36t)):
    N, e, _ = P0[name]
    for m in (1, 2, 3):
        Lval[(name, m)] = Lam(a, N, e, m, D(1)) / (D(N).sqrt() ** m * (2 * PI) ** (-m) * math.factorial(m - 1))
        print(f'  L({name},{m}) = {format(Lval[(name, m)], ".25g")}')

# ---- periods
I = {}
for alpha in (D(1) / 3, D(2) / 3):
    for j in (0, 1, 2):
        fn = lambda x, o, j=j, al=alpha: (x.ln() * (al - 1)).exp() * F(x, o) ** j * F(o, x) ** (2 - j)
        a6, a7 = tanh_sinh(fn, 6), tanh_sinh(fn, 7)
        I[(str(alpha)[:4], j)] = a7
        print(f'  I(alpha={str(alpha)[:5]}, j={j}) = {format(a7, ".30g")}   (h/h2 {dig(a6, a7):.1f} digits)')

# ---- 2-term recognition
def cf_best(x, maxden=10 ** 4):
    h0, h1, k0, k1 = 0, 1, 1, 0; y = x; best = None
    for _ in range(200):
        a_ = int(y.to_integral_value(rounding=ROUND_FLOOR)); h0, h1 = h1, a_ * h1 + h0; k0, k1 = k1, a_ * k1 + k0
        if k1 > maxden: break
        best = (h1, k1, dig(x, D(h1) / D(k1)) if h1 else 0)
        fr = y - a_
        if fr == 0: break
        y = 1 / fr
    return best
c2 = cbrt(D(2)); s3 = D(3).sqrt()
B = {'1': D(1), '2^(1/3)': c2, '2^(2/3)': c2 * c2, 'sqrt3': s3, '2^(1/3)sqrt3': c2 * s3, '2^(2/3)sqrt3': c2 * c2 * s3}
hits = []
for name in ('f36', 'f36(x)chi-3'):
    for al in ('0.33', '0.66'):
        for bn, bv in B.items():
            row = {}
            for m in (1, 2, 3):
                for e in range(-3, 4):
                    x = Lval[(name, m)] * PI ** e / (bv * I[(al, 3 - m)])
                    cf = cf_best(abs(x))
                    if cf and cf[2] >= 35: row[m] = (e, ('-' if x < 0 else '') + f'{cf[0]}/{cf[1]}')
            if row: hits.append((name, al, bn, row))
for h in hits: print('  HIT', h)
pattern_ok = any(len(h[3]) == 3 for h in hits)
print('P1:', 'PASS' if pattern_ok else 'FAIL (no 2-term relation for all m)', f' time {time.time() - T0:.0f}s')
