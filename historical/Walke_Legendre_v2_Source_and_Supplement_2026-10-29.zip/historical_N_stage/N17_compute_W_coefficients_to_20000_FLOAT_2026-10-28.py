"""N17 (FLOAT: FFT, outputs exact integers) — Dirichlet coefficients of L(W, s) for n <= NMAX (default 20000), cheaply:
   split p (p = 1 mod 3):  only s1 = TrV(p) is needed for p > sqrt(NMAX):  over F_p,
        a(l) = -sum_x chi(x(x-1)(x-l)) (FFT correlation),  M_k = Re sum_{l != 0,1} rho(l) a(l)^k  (rho cubic character),
        t2 = -M2 - 1 - p,   s1 = TrV(p) = -M4 - 1 - 3p t2 - 3p - 2p^2        (H13 definitions)
   inert p (p = 2 mod 3): c1 by the L1 twisted-Lefschetz trace (N2 code), descent '-' => coefficient -c1.
   p <= sqrt(NMAX): full Euler factors from the H13 laptop data (s2, u), exactly as in N2.
 Criteria fixed before running:
   E1  for every split p <= 4999 the new s1 equals the H13 laptop value exactly; every inert c1 as in N2 (same code).
   E2  Weil: |s1| <= 4 p^{5/2} for all split p; |c1| <= 4 p^{5/2} for all inert p.
   E3  a_n (n <= 4999) identical to the N5 export file N5_W_an_upto_4999.txt (sha256 37df237f...).
 Output: N17_W_an_upto_<NMAX>.txt (one integer per line) and a short log.
Usage: python -I N17_...py H13_output_data_laptop_p_upto_4999.txt ../N5_PARI/N5_W_an_upto_4999.txt [NMAX]
"""
import sys, math, time, hashlib
import numpy as np
T0 = time.time()
H13, N5, NMAX = sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 20000
src = open('N2_check_LW_critical_ratio_FLOAT_2026-10-28.py').read().split('def w_coefficients')[0]
src = src.split('# ================================================================ W coefficients')[1].split('\n', 1)[1]
ns = {'np': np, 'math': math}; exec('import math\nimport numpy as np\n' + src, ns)
twisted_data, re_sum, euler_to_dirichlet, is_prime = ns['twisted_data'], ns['re_sum'], ns['euler_to_dirichlet'], ns['is_prime']
def prim_root(p):
    m = p - 1; fac = []; d = 2
    while d * d <= m:
        if m % d == 0:
            fac.append(d)
            while m % d == 0: m //= d
        d += 1
    if m > 1: fac.append(m)
    g = 2
    while any(pow(g, (p - 1) // f, p) == 1 for f in fac): g += 1
    return g
def split_s1(p):
    x = np.arange(p)
    chi = np.full(p, -1, dtype=np.int64); chi[0] = 0; chi[(np.arange(1, p, dtype=np.int64) ** 2) % p] = 1
    c = chi * chi[(x - 1) % p]                                   # chi(x(x-1))
    corr = np.fft.ifft(np.conj(np.fft.fft(c.astype(float))) * np.fft.fft(chi.astype(float))).real   # sum_x c(x) chi(x + t)
    assert np.max(np.abs(corr - np.rint(corr))) < 1e-6
    # a(l) = -sum_x chi(x(x-1)(x-l)) = -sum_x c(x) chi(x - l) = -corr[-l]
    a = -np.rint(corr).astype(np.int64)[(-x) % p]
    g = prim_root(p); cls = np.zeros(p, dtype=np.int64); v = 1
    for k in range(p - 1): cls[v] = k % 3; v = v * g % p
    mask = np.ones(p, bool); mask[0] = False; mask[1] = False
    M = {}
    for k in (2, 4):
        vals = a.astype(object) ** k
        S = [sum(int(t) for t in vals[mask & (cls == j)]) for j in range(3)]
        assert S[1] == S[2], ('symmetry', p, k)
        M[k] = S[0] - S[1]
    t2 = -M[2] - 1 - p
    return -M[4] - 1 - 3 * p * t2 - 3 * p - 2 * p * p
# H13 data (exact) for small primes and for the E1 comparison
h13 = {}
for l in open(H13, encoding='utf-8'):
    if l.startswith('#') or not l.strip(): continue
    t = l.split(); h13[int(t[0])] = t
euler = {}; e1_bad = []; weil_bad = []; ninert = nsplit = 0
for p in range(5, NMAX + 1):
    if not is_prime(p): continue
    mu = p ** 5
    if p % 3 == 1:
        s1 = split_s1(p); nsplit += 1
        if p in h13 and int(h13[p][2]) != s1: e1_bad.append(p)
        if abs(s1) > 4 * p ** 2.5: weil_bad.append(p)
        if p * p <= NMAX: c1, c2 = int(h13[p][2]), int(h13[p][3])
        else: c1, c2 = s1, 0                                     # c2 unused when p^2 > NMAX
    else:
        ap, cls = twisted_data(p); ninert += 1
        c1 = -re_sum(ap ** 4 - 3 * p * ap ** 2 + p * p, cls) - 1
        if p * p <= NMAX:
            u = int(h13[p][2]); assert (c1 * c1 - u) % 2 == 0; c2 = (c1 * c1 - u) // 2
        else: c2 = 0
        if abs(c1) > 4 * p ** 2.5: weil_bad.append(p)
        c1 = -c1
    euler[p] = (c1, c2, mu * c1, mu * mu)
    if p % 2000 < 6: print(f'  p ~ {p}  [{time.time() - T0:.0f}s]', flush=True)
A = euler_to_dirichlet(euler, NMAX)
old = [int(l) for l in open(N5)]
e3 = A[1:len(old) + 1] == old
out = f'N17_W_an_upto_{NMAX}.txt'
with open(out, 'w', newline='\n') as f:
    for n in range(1, NMAX + 1): f.write(f'{A[n]}\n')
h = hashlib.sha256(open(out, 'rb').read()).hexdigest()
print(f'split {nsplit}, inert {ninert};  E1 mismatches vs H13: {e1_bad};  E2 Weil failures: {weil_bad};  E3 (n<=4999 = N5 file): {e3}')
print(f'wrote {out} sha256 {h[:16]}...  time {time.time() - T0:.0f}s')
print('VERDICT:', 'PASS' if not e1_bad and not weil_bad and e3 else 'FAIL')
