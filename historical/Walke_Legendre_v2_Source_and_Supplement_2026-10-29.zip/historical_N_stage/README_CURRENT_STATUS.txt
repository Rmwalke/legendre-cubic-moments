Historical exploratory source/log archive, preserved unchanged.
Consult the current manuscript, not the conjectural labels in these files.
N12 row-sign correction and N18 failed precision test are addressed in the
current manuscript/finite-period addendum. Built-in central zero under a
symmetrized sign-minus evaluator is not an analytic-rank or Selmer theorem.
Conductor432/1296, bad local factors, periods and special-value interpretations
are unproved. Function-field observations are not a classical elliptic BSD
proof overQ. No scripts in this directory were run for this handoff.
