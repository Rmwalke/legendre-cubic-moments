"""N7 (FLOAT: additive FFT; all outputs rounded to exact integers and checked) — BSD (rank part) over function fields
for the Legendre curve, by our own point counts.   [known literature: Ulmer, J. Number Theory 136 (2014)]

 E: y^2 = x(x+1)(x+t)  over K = F_q(u), t = u^d   (= our E_lambda up to the twist x -> -x).
 Ulmer: for q = p^{2f} (so mu_d in F_q) and d = p^f + 1:  rank E(K) = d - 2, BSD holds.
 L-function (Grothendieck): L(E/K, T) is a polynomial of degree deg(N) - 4, and
     log L(T) = sum_{n>=1} A_n T^n / n,    A_n := sum_{x in P^1(F_{q^n})} a_x(q^n),
 a_x = -sum_X chi(X(X+1)(X+x^d)) at finite x (this also gives +1/-1/0 at split/nonsplit/additive fibres of this
 model, which is minimal at all finite places); at infinity a_inf = +1 if d is even (I_2d, split), 0 if d is odd (additive).
 deg N = d + 2 (d even), d + 3 (d odd)  =>  deg L = d - 2 (d even), d - 1 (d odd).
 If L(T) = (1 - qT)^{d-2} then A_n = -(d-2) q^n, and ord_{T=1/q} L = d - 2 = Ulmer's rank (analytic = algebraic rank).

 PASS/FAIL fixed BEFORE running:
  C1 (d = 1, rank 0, deg L = 0):  A_n = 0 for n = 1..3 (p = 5, q = 25).
  C2 (d = 2, rank 0, deg L = 0):  A_n = 0 for n = 1..3 (p = 5, q = 25).
  U1 p=3, f=1: q=9,  d=4  (deg 2): A_n = -2 q^n,  n = 1..2  (full degree)
  U2 p=5, f=1: q=25, d=6  (deg 4): A_n = -4 q^n,  n = 1..4  (full degree)
  U3 p=7, f=1: q=49, d=8  (deg 6): A_n = -6 q^n,  n = 1..3  (half degree; the functional equation fixes the rest
                                                     once e_3 != 0, which forces sign +1)  [sketch]
  U4 p=3, f=2: q=81, d=10 (deg 8): n = 1..3 only  -> PARTIAL (n = 4 needs |F| = 3^16, too large here)
  U5 p=11,f=1: q=121,d=12 (deg 10): n = 1..2 only -> PARTIAL
  E1 (explore, no claim): p=5, q=25, d=4 (d | q-1 but d != p^f+1): print L(T) and its order at T = 1/q.
  Integrity: every |a_x| <= 2 sqrt(Q), every a_x at a good fibre is = 2 mod 4 (full 2-torsion, Q = 1 mod 4),
             FFT residuals < 1e-6.
 A PASS is [numerical] agreement with a [known] theorem; no new claim.
Usage: python -I N7_check_Legendre_function_field_BSD_rank_FLOAT_2026-10-28.py
"""
import math, time
import numpy as np

def field(p, m):
    """F_{p^m}: elements = integers 0..p^m-1 (base-p digits = coefficients). Returns (log, antilog) via a primitive poly."""
    Q = p ** m
    pw = [p ** i for i in range(m)]
    rng = np.random.default_rng(1)
    while True:
        low = [int(c) for c in rng.integers(0, p, size=m)]   # x^m = -(low[0] + low[1] x + ... )
        if low[0] == 0: continue
        state = [0] * m; state[0] = 1                          # the element 1
        antilog = np.empty(Q - 1, dtype=np.int64); ok = True
        for k in range(Q - 1):
            idx = sum(s * w for s, w in zip(state, pw))
            if k > 0 and idx == 1: ok = False; break
            antilog[k] = idx
            top = state[-1]; state = [0] + state[:-1]          # multiply by x
            if top: state = [(s - top * c) % p for s, c in zip(state, low)]
        if ok and sum(s * w for s, w in zip(state, pw)) == 1:
            log = np.full(Q, -1, dtype=np.int64); log[antilog] = np.arange(Q - 1)
            return log, antilog
def A_n(p, m, d):
    Q = p ** m
    log, antilog = field(p, m)
    chi = np.zeros(Q, dtype=np.float64); nz = log >= 0; chi[nz] = np.where(log[nz] % 2 == 0, 1.0, -1.0)
    X = np.arange(Q); d0 = X % p; Xp1 = X - d0 + (d0 + 1) % p             # index of X + 1
    c = chi * chi[Xp1]                                                     # chi(X(X+1))
    shp = (p,) * m
    corr = np.fft.ifftn(np.conj(np.fft.fftn(c.reshape(shp))) * np.fft.fftn(chi.reshape(shp))).real.reshape(Q)
    assert np.max(np.abs(corr - np.rint(corr))) < 1e-6
    a = -np.rint(corr).astype(np.int64)                                    # a[t] = -sum_X chi(X(X+1)(X+t))
    assert np.all(np.abs(a) <= 2 * math.sqrt(Q) + 1e-9)
    # good fibres t not in {0, 1}: a = 2 mod 4
    good = np.ones(Q, bool); good[0] = False; good[1] = False
    assert np.all(a[good] % 4 == 2), 'parity'
    u_pow = antilog[(d * np.arange(Q - 1)) % (Q - 1)]                      # u^d for u = g^k
    total = int(a[0]) + int(a[u_pow].sum()) + (1 if d % 2 == 0 else 0)
    return total
def L_from_A(A, deg):
    """Newton: power sums s_n = -A_n of inverse roots... L(T) = exp(sum A_n T^n / n) truncated to degree deg."""
    e = [1]
    for k in range(1, deg + 1):
        s = sum(e[k - i] * A[i - 1] for i in range(1, k + 1))
        assert s % k == 0
        e.append(s // k)
    return e                     # L(T) = sum e_k T^k   (exact integers)

T0 = time.time(); results = {}
def case(tag, p, f, d, nmax, expect_rank=None, explore=False):
    q = p ** (2 * f)
    deg = d - 2 if d % 2 == 0 else d - 1
    A = [A_n(p, 2 * f * n, d) for n in range(1, nmax + 1)]
    exp = [-(d - 2) * q ** n for n in range(1, nmax + 1)] if expect_rank is not None and expect_rank > 0 else [0] * nmax
    line = f'{tag}: p={p} f={f} q={q} d={d} deg L={deg}  A_n={A}'
    if explore:
        if nmax >= deg:
            e = L_from_A(A, deg); coeffs = e
            # order of vanishing at T = 1/q: divide by (1 - qT) repeatedly
            poly = np.poly1d(coeffs[::-1]); r = 0
            P = list(coeffs)
            while len(P) > 1:
                # synthetic division of sum P_k T^k by (1 - qT): root T = 1/q  <=> sum P_k q^{-k} = 0
                if sum(Fr * (q ** (len(P) - 1 - k)) for k, Fr in enumerate(P)) != 0: break
                # divide: P(T) = (1 - qT) R(T)
                R = [0] * (len(P) - 1); R[0] = P[0]
                for k in range(1, len(P) - 1): R[k] = P[k] + q * R[k - 1]
                P = R; r += 1
            line += f'  L(T) coeffs={coeffs}  ord_(T=1/q)={r}  (explore, no claim)'
        print(line); return
    ok = A == exp
    if nmax >= deg and expect_rank is not None:
        e = L_from_A(A, deg); line += f'  L(T) coeffs={e}'
    status = ('PASS' if ok else 'FAIL') + ('' if nmax >= deg or deg == 0 or tag == 'U3' else ' (PARTIAL: n<deg)')
    print(line, ' expected', exp, '->', status, f'[{time.time() - T0:.0f}s]')
    results[tag] = ok

print('N7 — Legendre curve over F_q(t^{1/d}): own point counts vs Ulmer (rank d-2) and BSD rank part')
case('C1', 5, 1, 1, 3, expect_rank=0)
case('C2', 5, 1, 2, 3, expect_rank=0)
case('U1', 3, 1, 4, 2, expect_rank=2)
case('U2', 5, 1, 6, 4, expect_rank=4)
case('U3', 7, 1, 8, 3, expect_rank=6)
case('U4', 3, 2, 10, 3, expect_rank=8)
case('U5', 11, 1, 12, 2, expect_rank=10)
case('E1', 5, 1, 4, 2, explore=True)
print('VERDICT:', 'PASS' if all(results.values()) else 'FAIL', results, f'total {time.time() - T0:.0f}s')
