# Explore: exact q-expansions of G(alpha, t) = lambda^alpha (1-lambda)^(t+1) theta_3^8 / 16^alpha, alpha = 1/3, 2/3,
# lambda = 16 q u(q), q = e^{i pi tau}; written as q^alpha * series(q) with Fraction coefficients. Compare with 36.4.a.a.
from fractions import Fraction as Fr
K = 40
def mul(A, B):
    C = [Fr(0)] * (K + 1)
    for i, x in enumerate(A):
        if x:
            for j in range(K + 1 - i):
                if B[j]: C[i + j] += x * B[j]
    return C
def powser(A, alpha):            # A[0] = 1; A^alpha via log-derivative recursion: C' A = alpha A' C
    C = [Fr(0)] * (K + 1); C[0] = Fr(1)
    for n in range(1, K + 1):
        s = Fr(0)
        for k in range(1, n + 1):
            s += (alpha * k - (n - k)) * A[k] * C[n - k]
        C[n] = s / n
    return C
th3 = [Fr(0)] * (K + 1); th2h = [Fr(0)] * (K + 1)
for n in range(-10, 11):
    if n * n <= K: th3[n * n] += 1
for n in range(0, 10):
    if n * (n + 1) <= K: th2h[n * (n + 1)] += 1
t3_4 = mul(mul(th3, th3), mul(th3, th3)); t2_4 = mul(mul(th2h, th2h), mul(th2h, th2h))
# u = theta_2^4/(16 q theta_3^4) = t2_4 / t3_4
inv = powser(t3_4, Fr(-1)); u = mul(t2_4, inv)
lam = [Fr(0)] + [16 * x for x in u[:K]]          # lambda as series in q
oml = [Fr(1) - (lam[0] if True else 0)] + [-x for x in lam[1:]]
t3_8 = mul(t3_4, t3_4)
for alpha in (Fr(1, 3), Fr(2, 3)):
    G = mul(mul(powser(u, alpha), oml), t3_8)    # = lambda^alpha (1-lambda) theta3^8 / (16^alpha q^alpha)
    print('alpha', alpha, ' q^alpha *', [str(x) for x in G[:12]])
# 36.4.a.a from the L1 eta expression: f = eta(6z)^14/(eta(2z)^3 eta(18z)^3) - 3 eta(2z)^3 eta(6z)^2 eta(18z)^3
N = 120
def eta_prod(spec):
    lead = sum(m * e for m, e in spec); s = lead // 24
    P = [0] * (N + 1); P[0] = 1
    for m, e in spec:
        for nn in range(1, N // m + 1):
            for _ in range(abs(e)):
                if e > 0:
                    for i in range(N, m * nn - 1, -1): P[i] -= P[i - m * nn]
                else:
                    for i in range(m * nn, N + 1): P[i] += P[i - m * nn]
    return ([0] * s + P)[:N + 1]
f = [x - 3 * y for x, y in zip(eta_prod([(6, 14), (2, -3), (18, -3)]), eta_prod([(2, 3), (6, 2), (18, 3)]))]
print('36.4.a.a a_1..a_40:', f[1:41])
