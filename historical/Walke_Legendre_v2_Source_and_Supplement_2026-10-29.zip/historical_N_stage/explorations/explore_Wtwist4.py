import itertools, math, pickle
from fractions import Fraction
src = open('/home/claude/N_next/N11_check_W_Deligne_period_determinant_FLOAT_2026-10-28.py').read().split('mu = lambda A, B')[0]
src = src.replace('a8, a9 = integral(8, ex, j, 4), integral(9, ex, j, 4)', 'a8 = a9 = integral(8, ex, j, 4)')
exec(src)
Lt = {int(k): D(v) for k, v in pickle.load(open('/tmp/claude-0/-home-claude/379625b9-01c2-5349-b899-5a0cd1cdbf8b/scratchpad/Ltwist60.pkl', 'rb')).items()}
c2 = (D(2).ln() / 3).exp(); s3 = D(3).sqrt()
Bf = {'1': D(1), 'r3': s3, 'c2': c2, 'c4': c2 * c2, 'r3c2': s3 * c2, 'r3c4': s3 * c2 * c2}
def quick(xf):
    fr = Fraction(xf).limit_denominator(10 ** 8)
    return fr if fr.numerator and abs(float(fr) - xf) < 1e-12 * abs(xf) else None
hits = []
for A, B in itertools.product(('C2/3', 'S2/3'), ('C1/3', 'S1/3')):
    for j1, j2 in itertools.combinations(range(5), 2):
        mu = V[(A, j1)] * V[(B, j2)] - V[(A, j2)] * V[(B, j1)]
        for s in (4, 5):
            for e in range(-14, 15):
                for bn, bv in Bf.items():
                    xf = float(Lt[s]) * math.pi ** e / (float(bv) * float(mu)); fr = quick(xf)
                    if fr is None: continue
                    d_ = dig(Lt[s] * PI ** e / (bv * mu), D(fr.numerator) / D(fr.denominator))
                    if d_ >= 35: hits.append((A, B, (j1, j2), f'Ltw({s})', e, bn, str(fr), round(d_, 1)))
for h in hits: print('HIT', h)
print('hits', len(hits))
