# EXPLORE (no claim), fast: float prefilter then 50-digit confirmation.
import itertools, pickle, math
from fractions import Fraction
exec(open('/home/claude/N_next/N10_check_period_dictionary_k2_cubic_FLOAT_2026-10-28.py').read().split('# ---- 36.4.a.a')[0])
P = {k: D(v) for k, v in pickle.load(open('/tmp/claude-0/-home-claude/379625b9-01c2-5349-b899-5a0cd1cdbf8b/scratchpad/W_periods.pkl', 'rb')).items()}
LW3 = D('2.241355203236439605879618666060345021634663845711378470'); LW5 = D('1.010779504775895276424758858414728530036032268915172553')
c2 = cbrt(D(2)); s3 = D(3).sqrt()
Bf = {'1': D(1), 'r3': s3, 'c2': c2, 'c4': c2 * c2, 'r3c2': s3 * c2, 'r3c4': s3 * c2 * c2}
K = {'1': D(1), '2': D(2), '1/2': D(1) / 2, '4': D(4), '1/4': D(1) / 4, 'c2': c2, '1/c2': 1 / c2, 'c4': c2 * c2, '1/c4': 1 / (c2 * c2),
     '16^1/3': cbrt(D(16)), '1/16^1/3': 1 / cbrt(D(16)), '8': D(8), '1/8': D(1) / 8, '16': D(16), '1/16': D(1) / 16}
def quick(xf):
    fr = Fraction(xf).limit_denominator(10 ** 6)
    return fr if fr.numerator != 0 and abs(float(fr) - xf) < 1e-12 * abs(xf) else None
hits = []; cnt = 0
rows_variants = []
# sigma-paired rows (and, for completeness, the un-paired ones)
pairings = {'sigma': ((('1/3', 0), ('2/3', 1)), (('1/3', 1), ('2/3', 0))), 'same-a': ((('1/3', 0), ('2/3', 0)), (('1/3', 1), ('2/3', 1)))}
for pn, ((A1, B1), (A2, B2)) in pairings.items():
    for (k1n, k1), (k2n, k2) in itertools.product(K.items(), repeat=2):
        for s1, s2 in itertools.product((1, -1, 0), repeat=2):
            r1 = [P[A1 + (j,)] + s1 * k1 * P[B1 + (j,)] for j in range(5)]
            r2 = [P[A2 + (j,)] + s2 * k2 * P[B2 + (j,)] for j in range(5)]
            for j1, j2 in itertools.combinations(range(5), 2):
                mu = r1[j1] * r2[j2] - r1[j2] * r2[j1]
                if mu == 0: continue
                muf = float(mu)
                for Ln, Lv in (('L3', LW3), ('L5', LW5)):
                    for e in range(-14, 15):
                        for bn, bv in Bf.items():
                            cnt += 1
                            xf = float(Lv) * math.pi ** e / (float(bv) * muf)
                            fr = quick(xf)
                            if fr is None: continue
                            x = Lv * PI ** e / (bv * mu); d_ = dig(x, D(fr.numerator) / D(fr.denominator))
                            if d_ >= 35: hits.append((pn, k1n, s1, k2n, s2, (j1, j2), Ln, e, bn, str(fr), round(d_, 1)))
print('tests', cnt, 'hits', len(hits))
for h in hits[:60]: print('HIT', h)
