# EXPLORE: W x chi_{-3} with a nontrivial Euler factor at 3:  P_3(T) = 1 - c1 T (+ c2 T^2), N = 2^4 3^b.
import sys, itertools
sys.argv = ['x', '/tmp/claude-0/-home-claude/379625b9-01c2-5349-b899-5a0cd1cdbf8b/scratchpad/zip_in/MASTER/H21_laptop_run/H13_output_data_laptop_p_upto_4999.txt']
n2 = open('/home/claude/N_next/N2_check_LW_critical_ratio_FLOAT_2026-10-28.py').read().split('# ================================================================ main')[0]
ns = {'__name__': 'n2'}; exec(compile(n2, 'n2', 'exec'), ns)
AW, NM, _ = ns['w_coefficients'](sys.argv[1]); chi3 = lambda n: (0, 1, -1)[n % 3]
base = [a * chi3(n) for n, a in enumerate(AW)]
ns['set_dps'](30); D = ns['D']; dig = ns['digits']
def with3(c1, c2):
    b = [1]; k = 1                      # 1/(1 - c1 T + c2 T^2) at T = 3^{-s}
    while 3 ** k <= NM:
        b.append(c1 * b[k - 1] - (c2 * b[k - 2] if k >= 2 else 0)); k += 1
    A = [0] * (NM + 1)
    for n in range(1, NM + 1):
        v, m = 0, n
        while m % 3 == 0: m //= 3; v += 1
        A[n] = base[m] * b[v]
    return A
cands = [(c, 0) for c in (1, -1, 3, -3, 9, -9, 27, -27, 81, -81, 243, -243)]
cands += [(c1, c2) for c2 in (243, -243, 81, 729, 3 ** 5 * 9) for c1 in range(-60, 61, 3)]
res = []
for b3 in range(0, 7):
    N = 16 * 3 ** b3
    for c1, c2 in cands:
        A = with3(c1, c2)
        for e in (1, -1):
            d_ = min(dig(ns['Lam'](A, N, e, s, 4, D(1)), ns['Lam'](A, N, e, s, 4, D('1.1'))) for s in (4, 5))
            res.append((round(d_, 1), N, c1, c2, e))
res.sort(reverse=True); print('best:', res[:6])
