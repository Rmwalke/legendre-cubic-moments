# EXPLORE (no claim): weight-6 noncongruence periods P(alpha,a,j) vs L(W,3), L(W,5) (values from N2, 51 digits).
import itertools, time
exec(open('/home/claude/N_next/N10_check_period_dictionary_k2_cubic_FLOAT_2026-10-28.py').read().split('# ---- 36.4.a.a')[0])
LW3 = D('2.241355203236439605879618666060345021634663845711378470')
LW5 = D('1.010779504775895276424758858414728530036032268915172553')
P = {}
for al in ('1/3', '2/3'):
    alv = D(1) / 3 if al == '1/3' else D(2) / 3
    for a in (0, 1):
        for j in range(5):
            fn = lambda x, o, j=j, e=alv + a - 1: (x.ln() * e).exp() * F(x, o) ** j * F(o, x) ** (4 - j)
            v6, v7 = tanh_sinh(fn, 6), tanh_sinh(fn, 7)
            P[(al, a, j)] = v7
            print(f'P({al},{a},{j}) = {format(v7, ".25g")}  (h/h2 {dig(v6, v7):.1f})', flush=True)
def cf_best(x, maxden=10 ** 6):
    from decimal import ROUND_FLOOR
    h0, h1, k0, k1 = 0, 1, 1, 0; y = x; best = None
    for _ in range(200):
        a_ = int(y.to_integral_value(rounding=ROUND_FLOOR)); h0, h1 = h1, a_ * h1 + h0; k0, k1 = k1, a_ * k1 + k0
        if k1 > maxden: break
        best = (h1, k1, dig(x, D(h1) / D(k1)) if h1 else 0)
        fr = y - a_
        if fr == 0: break
        y = 1 / fr
    return best
c2 = cbrt(D(2)); s3 = D(3).sqrt()
Bf = {'1': D(1), 'r3': s3, 'c2': c2, 'c4': c2 * c2, 'r3c2': s3 * c2, 'r3c4': s3 * c2 * c2}
comb = {'+': lambda a, j: P[('1/3', a, j)] + P[('2/3', a, j)], '-': lambda a, j: P[('1/3', a, j)] - P[('2/3', a, j)],
        '1/3': lambda a, j: P[('1/3', a, j)], '2/3': lambda a, j: P[('2/3', a, j)]}
hits = []
for s, fn in comb.items():
    for j1, j2 in itertools.combinations(range(5), 2):
        mu = fn(0, j1) * fn(1, j2) - fn(0, j2) * fn(1, j1)
        for Ln, Lv in (('L3', LW3), ('L5', LW5)):
            for e in range(-12, 13):
                for bn, bv in Bf.items():
                    x = Lv * PI ** e / (bv * mu)
                    cf = cf_best(abs(x))
                    if cf and cf[2] >= 35: hits.append((s, (j1, j2), Ln, e, bn, ('-' if x < 0 else '') + f'{cf[0]}/{cf[1]}', round(cf[2], 1)))
for h in hits: print('HIT', h)
print('hits:', len(hits))
# single-period (non-determinant) control: L(W,3) vs a single P combination (should NOT work if W is not GL2-type)
single = []
for s, fn in comb.items():
    for a in (0, 1):
        for j in range(5):
            for e in range(-12, 13):
                x = LW3 * PI ** e / fn(a, j); cf = cf_best(abs(x))
                if cf and cf[2] >= 35: single.append((s, a, j, e))
print('single-period hits (expect none):', single)
