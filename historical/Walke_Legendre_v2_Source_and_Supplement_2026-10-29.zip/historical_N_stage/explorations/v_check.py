# Own light check (exact integers): V(p) = sum_z f(z) T(z), f(z) = chi(z) chi(z-1), T(z) = sum_y chi(y(y-1)(y-z))
# compare with (i) 2(O^2 - E^2), p = O^2 + E^2, O odd;  (ii) coefficient of q^p in eta(4z)^6 = q prod (1 - q^{4n})^6
import math
def isprime(n): return n > 1 and all(n % d for d in range(2, math.isqrt(n) + 1))
def chi_tab(p):
    c = [-1] * p; c[0] = 0
    for x in range(1, p): c[x * x % p] = 1
    return c
M = 520
# eta(4z)^6 coefficients: prod (1-x^n)^6 in x = q^4, times q
P = [0] * (M // 4 + 2); P[0] = 1
for n in range(1, len(P)):
    for _ in range(6):
        for i in range(len(P) - 1, n - 1, -1): P[i] -= P[i - n]
eta6 = {4 * j + 1: P[j] for j in range(len(P)) if 4 * j + 1 <= M}
bad = []; rows = []
for p in range(5, M):
    if not isprime(p): continue
    c = chi_tab(p)
    T = [sum(c[y * (y - 1) * (y - z) % p] for y in range(p)) for z in range(p)]
    V = sum(c[z] * c[(z - 1) % p] * T[z] for z in range(p))
    e = eta6.get(p, 0)
    if p % 4 == 1:
        O = next(o for o in range(1, math.isqrt(p) + 1, 2) if math.isqrt(p - o * o) ** 2 == p - o * o)
        E2 = p - O * O; tw = 2 * (O * O - E2)
    else:
        tw = None
    ok = (V == e) and (tw is None or tw == V)
    rows.append((p, V, tw, e))
    if not ok: bad.append((p, V, tw, e))
print('primes 5..', M, ':', len(rows), ' mismatches:', bad[:10])
print('first rows (p, V, 2(O^2-E^2), eta(4z)^6 coeff):', rows[:10])
