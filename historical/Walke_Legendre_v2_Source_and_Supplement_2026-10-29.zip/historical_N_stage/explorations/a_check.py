# Own light check (exact integers), v12 pending item: A := sum_z chi(z) T(z)^2  vs  Ahlgren-Ono  -a(p) - p,
# a(n) = coefficients of eta(2z)^4 eta(4z)^4 = 8.4.a.a.  Also B := sum chi(z-1) T^2 = chi(-1) A,  C := sum f T^2 = A - 1 ?
import math
def isprime(n): return n > 1 and all(n % d for d in range(2, math.isqrt(n) + 1))
M = 400
# eta(2z)^4 eta(4z)^4 = q prod (1-q^{2n})^4 (1-q^{4n})^4 ; in x = q^2: x^0..: prod (1-x^n)^4 (1-x^{2n})^4, then a(2j+1) = coef x^j
L = M // 2 + 2
P = [0] * L; P[0] = 1
for n in range(1, L):
    for _ in range(4):
        for i in range(L - 1, n - 1, -1): P[i] -= P[i - n]
    if 2 * n < L:
        for _ in range(4):
            for i in range(L - 1, 2 * n - 1, -1): P[i] -= P[i - 2 * n]
a = {2 * j + 1: P[j] for j in range(L) if 2 * j + 1 <= M}
assert [a[k] for k in (1, 3, 5, 7, 9, 11, 13)] == [1, -4, -2, 24, -11, -44, 22]
bad = []
for p in range(5, M):
    if not isprime(p): continue
    c = [-1] * p; c[0] = 0
    for x in range(1, p): c[x * x % p] = 1
    T = [sum(c[y * (y - 1) * (y - z) % p] for y in range(p)) for z in range(p)]
    A = sum(c[z] * T[z] ** 2 for z in range(p))
    B = sum(c[(z - 1) % p] * T[z] ** 2 for z in range(p))
    C = sum(c[z] * c[(z - 1) % p] * T[z] ** 2 for z in range(p))
    chim1 = 1 if p % 4 == 1 else -1
    if not (A == -a[p] - p and B == chim1 * A and C == A - 1): bad.append((p, A, -a[p] - p, B, C))
print('primes 5..', M, ' mismatches:', bad[:8])
