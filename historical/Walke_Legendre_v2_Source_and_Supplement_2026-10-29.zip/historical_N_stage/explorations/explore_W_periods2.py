# EXPLORE (no claim): sigma-paired rows  r1 = P(1/3,0,.) s1*k1 P(2/3,1,.),  r2 = P(1/3,1,.) s2*k2 P(2/3,0,.)
import itertools, pickle
exec(open('/home/claude/N_next/N10_check_period_dictionary_k2_cubic_FLOAT_2026-10-28.py').read().split('# ---- 36.4.a.a')[0])
LW3 = D('2.241355203236439605879618666060345021634663845711378470')
LW5 = D('1.010779504775895276424758858414728530036032268915172553')
P = {}
for al in ('1/3', '2/3'):
    alv = D(1) / 3 if al == '1/3' else D(2) / 3
    for a in (0, 1):
        for j in range(5):
            fn = lambda x, o, j=j, e=alv + a - 1: (x.ln() * e).exp() * F(x, o) ** j * F(o, x) ** (4 - j)
            P[(al, a, j)] = tanh_sinh(fn, 7)
pickle.dump({k: str(v) for k, v in P.items()}, open('/tmp/claude-0/-home-claude/379625b9-01c2-5349-b899-5a0cd1cdbf8b/scratchpad/W_periods.pkl', 'wb'))
from decimal import ROUND_FLOOR
def cf_best(x, maxden=10 ** 6):
    h0, h1, k0, k1 = 0, 1, 1, 0; y = x; best = None
    for _ in range(200):
        a_ = int(y.to_integral_value(rounding=ROUND_FLOOR)); h0, h1 = h1, a_ * h1 + h0; k0, k1 = k1, a_ * k1 + k0
        if k1 > maxden: break
        best = (h1, k1, dig(x, D(h1) / D(k1)) if h1 else 0)
        fr = y - a_
        if fr == 0: break
        y = 1 / fr
    return best
c2 = cbrt(D(2)); s3 = D(3).sqrt()
Bf = {'1': D(1), 'r3': s3, 'c2': c2, 'c4': c2 * c2, 'r3c2': s3 * c2, 'r3c4': s3 * c2 * c2}
K = {'1': D(1), '2': D(2), '1/2': D(1) / 2, '4': D(4), '1/4': D(1) / 4, 'c2': c2, '1/c2': 1 / c2, 'c4': c2 * c2, '1/c4': 1 / (c2 * c2),
     '16^1/3': cbrt(D(16)), '1/16^1/3': 1 / cbrt(D(16))}
hits = []
for (k1n, k1), (k2n, k2) in itertools.product(K.items(), repeat=2):
    for s1, s2 in itertools.product((1, -1), repeat=2):
        r1 = [P[('1/3', 0, j)] + s1 * k1 * P[('2/3', 1, j)] for j in range(5)]
        r2 = [P[('1/3', 1, j)] + s2 * k2 * P[('2/3', 0, j)] for j in range(5)]
        for j1, j2 in itertools.combinations(range(5), 2):
            mu = r1[j1] * r2[j2] - r1[j2] * r2[j1]
            if mu == 0: continue
            for Ln, Lv in (('L3', LW3), ('L5', LW5)):
                for e in range(-12, 13):
                    for bn, bv in Bf.items():
                        x = Lv * PI ** e / (bv * mu); cf = cf_best(abs(x))
                        if cf and cf[2] >= 35:
                            hits.append((k1n, s1, k2n, s2, (j1, j2), Ln, e, bn, ('-' if x < 0 else '') + f'{cf[0]}/{cf[1]}', round(cf[2], 1)))
for h in hits: print('HIT', h)
print('hits:', len(hits))
