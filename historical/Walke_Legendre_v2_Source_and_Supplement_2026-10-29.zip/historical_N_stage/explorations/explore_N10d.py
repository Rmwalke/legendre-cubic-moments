exec(open('/tmp/claude-0/-home-claude/379625b9-01c2-5349-b899-5a0cd1cdbf8b/scratchpad/tools/explore_N10b.py').read().split('c2 = cbrt(D(2)); s3')[0])
x = (I[('0.33', 2)] - I[('0.66', 2)]); L1 = Lval[('g', 1)]
s3 = D(3).sqrt(); ln2 = D(2).ln(); ln3 = D(3).ln()
cands = {'1': D(1), 'pi': PI, '1/pi': 1 / PI, 'sqrt3': s3, 'pi*sqrt3': PI * s3, 'pi/sqrt3': PI / s3, 'ln2': ln2, 'ln3': ln3,
         'pi^2': PI ** 2, 'sqrt3*ln3': s3 * ln3}
import itertools
for k in (1, 2):
    for combo in itertools.combinations(cands, k):
        xs = [x, L1] + [cands[c] for c in combo]
        co, r = relation(xs, digits=45)
        if co[0] and max(abs(c) for c in co) < 10 ** 6 and r < D(10) ** (-35):
            print('  REL', ['I-', 'L(g,1)'] + list(combo), co, f'{float(r):.1e}')
# also the same for the sum at m=1 (control: should need nothing extra)
xs = [I[('0.33', 2)] + I[('0.66', 2)], Lval[('f36', 1)]]
print('  control sum:', relation(xs, digits=45))
