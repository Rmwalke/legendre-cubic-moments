# EXPLORE: L(W x chi_{-3}, s): conductor/eps by FE (decimal closed form from N2), then mixed-row determinants.
import sys, math, itertools
from fractions import Fraction
sys.argv = ['x', '/tmp/claude-0/-home-claude/379625b9-01c2-5349-b899-5a0cd1cdbf8b/scratchpad/zip_in/MASTER/H21_laptop_run/H13_output_data_laptop_p_upto_4999.txt']
n2 = open('/home/claude/N_next/N2_check_LW_critical_ratio_FLOAT_2026-10-28.py').read().split('# ================================================================ main')[0]
ns = {'__name__': 'n2'}; exec(compile(n2, 'n2', 'exec'), ns)
AW, _, _ = ns['w_coefficients'](sys.argv[1])
chi3 = lambda n: (0, 1, -1)[n % 3]
AT = [a * chi3(n) for n, a in enumerate(AW)]
ns['set_dps'](30); D = ns['D']
dig = ns['digits']
res = []
for a2 in range(0, 9):
    for b3 in range(0, 9):
        N = 2 ** a2 * 3 ** b3
        if N < 100 or N > 200000: continue
        for e in (1, -1):
            try:
                d_ = min(dig(ns['Lam'](AT, N, e, s, 4, D(1)), ns['Lam'](AT, N, e, s, 4, D('1.1'))) for s in (4, 5))
            except Exception as ex: continue
            res.append((d_, N, a2, b3, e))
res.sort(reverse=True); print('best FE fits (digits, N, 2^a, 3^b, eps):', res[:4])
d_, N, a2, b3, e = res[0]
ns['set_dps'](60); D = ns['D']; ns['HP']['kcache'].clear()
Lt = {s: ns['L_of'](AT, N, e, s, 4) for s in (3, 4, 5)}
for s in (3, 4, 5): print(f'L(W x chi,{s}) = {format(Lt[s], ".50g")}')
open('/tmp/claude-0/-home-claude/379625b9-01c2-5349-b899-5a0cd1cdbf8b/scratchpad/Ltwist.txt', 'w').write(repr((N, e, {s: str(v) for s, v in Lt.items()})))
