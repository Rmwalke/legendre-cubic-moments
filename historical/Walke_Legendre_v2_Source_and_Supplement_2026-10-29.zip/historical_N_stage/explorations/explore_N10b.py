# EXPLORE (no claim): (1) find the newform g with g (x) chi_{-3} = f36 (a_3 = +-3, level 12/36);
# (2) multi-term integer relations between L(h,m) pi^e and the cubic periods I(1/3,3-m), I(2/3,3-m), with 2^{1/3} factors.
import sys, math, itertools
sys.argv = ['x']
src = open('/home/claude/N_next/N10_check_period_dictionary_k2_cubic_FLOAT_2026-10-28.py').read().split('# ---- 2-term recognition')[0]
src = src.replace("for name, a in (('f36', f36), ('f36(x)chi-3', f36t)):\n    dd, N, e = fe_fit(a, (36, 108, 324))", "for name, a in (('f36', f36),):\n    dd, N, e = fe_fit(a, (36,))")
src = src.replace("for name, a in (('f36', f36), ('f36(x)chi-3', f36t)):\n    N, e, _ = P0[name]", "for name, a in (('f36', f36),):\n    N, e, _ = P0[name]")
ns = {}; exec(compile(src, 'n10', 'exec'), ns)
D, PI, Lam, fe_fit, dig, f36, chi3, cbrt, I, Lval = (ns[k] for k in ('D', 'PI', 'Lam', 'fe_fit', 'dig', 'f36', 'chi3', 'cbrt', 'I', 'Lval'))
NM = len(f36) - 1
for a3 in (3, -3):
    g = [0] * (NM + 1)
    for n in range(1, NM + 1):
        v, m = 0, n
        while m % 3 == 0: m //= 3; v += 1
        g[n] = f36[m] * chi3(m) * a3 ** v
    best = fe_fit(g, (12, 36, 108))
    print('a3 =', a3, 'g_1..g_12 =', g[1:13], ' FE fit (digits, N, eps):', (round(best[0], 1), best[1], best[2]))
    if best[0] > 40:
        N, e = best[1], best[2]
        for m in (1, 2, 3):
            Lval[('g', m)] = Lam(g, N, e, m, D(1)) / (D(N).sqrt() ** m * (2 * PI) ** (-m) * math.factorial(m - 1))
            print(f'   L(g,{m}) = {format(Lval[("g", m)], ".25g")}')
# ---- small exact LLL (integers) for relation finding
from fractions import Fraction as Fr
def lll(B, delta=Fr(3, 4)):
    B = [list(b) for b in B]; n = len(B)
    def dot(u, v): return sum(x * y for x, y in zip(u, v))
    def gs():
        Bs = []; mu = [[Fr(0)] * n for _ in range(n)]
        for i in range(n):
            v = [Fr(x) for x in B[i]]
            for j in range(i):
                mu[i][j] = Fr(dot(B[i], Bs[j])) / dot(Bs[j], Bs[j]); v = [a - mu[i][j] * b for a, b in zip(v, Bs[j])]
            Bs.append(v)
        return Bs, mu
    Bs, mu = gs(); k = 1
    while k < n:
        for j in range(k - 1, -1, -1):
            q = round(mu[k][j])
            if q: B[k] = [a - q * b for a, b in zip(B[k], B[j])]; Bs, mu = gs()
        if dot(Bs[k], Bs[k]) >= (delta - mu[k][k - 1] ** 2) * dot(Bs[k - 1], Bs[k - 1]): k += 1
        else: B[k], B[k - 1] = B[k - 1], B[k]; Bs, mu = gs(); k = max(k - 1, 1)
    return B
def relation(xs, digits=40):
    S = 10 ** digits; n = len(xs)
    B = [[1 if i == j else 0 for j in range(n)] + [int((x * S).to_integral_value())] for i, x in enumerate(xs)]
    R = lll(B)[0]; coeffs = R[:n]; resid = R[n]
    return coeffs, abs(sum(c * x for c, x in zip(coeffs, xs)))
c2 = cbrt(D(2)); s3 = D(3).sqrt()
for h in ('f36', 'g'):
    if (h, 1) not in Lval: continue
    for m in (1, 2, 3):
        for e in range(-3, 4):
            xs = [Lval[(h, m)] * PI ** e, I[('0.33', 3 - m)], I[('0.66', 3 - m)], c2 * I[('0.33', 3 - m)], c2 * I[('0.66', 3 - m)],
                  c2 * c2 * I[('0.33', 3 - m)], c2 * c2 * I[('0.66', 3 - m)]]
            co, r = relation(xs)
            if co[0] != 0 and max(abs(c) for c in co) < 10 ** 5 and r < D(10) ** (-30):
                print(f'  RELATION h={h} m={m} e={e}: coeffs {co}  resid {float(r):.1e}')
print('done')
