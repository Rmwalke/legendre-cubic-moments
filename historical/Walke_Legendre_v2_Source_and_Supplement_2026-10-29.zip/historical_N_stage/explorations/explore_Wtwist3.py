import sys, math, itertools, pickle
from fractions import Fraction
sys.argv = ['x', '/tmp/claude-0/-home-claude/379625b9-01c2-5349-b899-5a0cd1cdbf8b/scratchpad/zip_in/MASTER/H21_laptop_run/H13_output_data_laptop_p_upto_4999.txt']
n2 = open('/home/claude/N_next/N2_check_LW_critical_ratio_FLOAT_2026-10-28.py').read().split('# ================================================================ main')[0]
ns = {'__name__': 'n2'}; exec(compile(n2, 'n2', 'exec'), ns)
AW, NM, _ = ns['w_coefficients'](sys.argv[1]); chi3 = lambda n: (0, 1, -1)[n % 3]
A = [0] * (NM + 1)
for n in range(1, NM + 1):
    v, m = 0, n
    while m % 3 == 0: m //= 3; v += 1
    A[n] = AW[m] * chi3(m) * 3 ** v
out = {}
for dps in (40, 60):
    ns['set_dps'](dps); D = ns['D']
    fe = {s: ns['digits'](ns['Lam'](A, 432, -1, s, 4, D(1)), ns['Lam'](A, 432, -1, s, 4, D('1.1'))) for s in (4, 5)}
    L = {s: ns['L_of'](A, 432, -1, s, 4) for s in (3, 4, 5)}
    out[dps] = L; print(dps, 'FE digits', {k: round(v, 1) for k, v in fe.items()}, {s: format(L[s], '.45g') for s in L})
print('stability 40 vs 60:', {s: round(ns['digits'](out[40][s], out[60][s]), 1) for s in (4, 5)})
pickle.dump({s: str(v) for s, v in out[60].items()}, open('/tmp/claude-0/-home-claude/379625b9-01c2-5349-b899-5a0cd1cdbf8b/scratchpad/Ltwist60.pkl', 'wb'))
