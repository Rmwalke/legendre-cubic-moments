import sys
exec(open('/tmp/claude-0/-home-claude/379625b9-01c2-5349-b899-5a0cd1cdbf8b/scratchpad/tools/explore_N10b.py').read().split('c2 = cbrt(D(2)); s3')[0])
x = (I[('0.33', 2)] - I[('0.66', 2)])
print('I-(j=2) =', format(x, '.40g'))
print('L(g,1)  =', format(Lval[('g', 1)], '.40g'))
s3 = D(3).sqrt(); c2 = cbrt(D(2))
for nm, b in (('1', D(1)), ('sqrt3', s3), ('pi', PI), ('pi/sqrt3', PI / s3), ('sqrt3*pi', s3 * PI), ('1/pi', 1 / PI), ('2^(1/3)', c2)):
    r = x / (Lval[('g', 1)] * b)
    co, res = relation([r, D(1)], digits=40)
    print(f'  (I-)/(L(g,1)*{nm}) = {format(r, ".30g")}  rel {co} resid {float(res):.1e}')
