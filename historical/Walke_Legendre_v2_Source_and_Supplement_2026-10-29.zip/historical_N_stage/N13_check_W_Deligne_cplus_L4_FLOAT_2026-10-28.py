"""N13 (FLOAT) — CONFIRMATION of the c^+ relation for L(W,4) (found in exploration explore_W4, criteria fixed now).
 Uses the N11 v2 period machinery (dps 70, tanh-sinh levels 8/9; imported by reading N11's source up to its checks).
   muC(1,3) := det[[C_{2/3}(1), C_{2/3}(3)], [C_{1/3}(1), C_{1/3}(3)]],  muS(0,2) := det[[S_{2/3}(0), S_{2/3}(2)], [S_{1/3}(0), S_{1/3}(2)]]
 Criteria:
   K4  L(W,4) = pi^6 muC(1,3)/157464  and  L(W,4) = -pi^6 muS(0,2)/209952   to >= 50 digits (L(W,4) from N2, ~55 digits)
   K5  pure periods: muS(0,2)/muC(1,3) = -4/3   to >= 60 digits
   K6  parity bookkeeping: c^- (L3, L5) <-> {C even j, S odd j};  c^+ (L4) <-> {C odd j, S even j}  (as observed)
 [numerical]; supports Deligne's conjecture for W at s = 4 (period c^+). Not a proof.
"""
src = open('N11_check_W_Deligne_period_determinant_FLOAT_2026-10-28.py').read().split('mu = lambda A, B')[0]
exec(src)
mu = lambda A, B, j1, j2: V[(A, j1)] * V[(B, j2)] - V[(A, j2)] * V[(B, j1)]
LW4 = D('1.077077976096331662211885414803778494282805934347963222')
mC13 = mu('C2/3', 'C1/3', 1, 3); mS02 = mu('S2/3', 'S1/3', 0, 2)
k4 = [dig(PI ** 6 * mC13 / 157464, LW4), dig(-PI ** 6 * mS02 / 209952, LW4)]
k5 = dig(mS02 / mC13, D(-4) / 3)
print('K4 L(W,4) from c+ determinants: digits', [round(x, 1) for x in k4])
print('K5 muS(0,2)/muC(1,3) = -4/3: digits', round(k5, 1))
print('   muC(1,3) =', format(mC13, '.60g'))
print('VERDICT:', 'PASS' if min(k0) >= 60 and min(k4) >= 50 and k5 >= 60 else 'FAIL')
