# N1 — संशोधन योजना (नव्या chat साठी) — 2026-10-28

व्याप्ती: फक्त संशोधन. Submission चं काम GPT कडे आहे (00 prompt, §6 पाहा).

---

## मार्ग B (मुख्य): L(W, s) वर Deligne period / rationality test

### पार्श्वभूमी
- W: degree 4 आणि weight 5. Hodge {0,0,5,5}, म्हणजे h^{0,5} = h^{5,0} = 2.
- L(W, s) चे गुणधर्म: N = 1296, ε = +1, Γ-factor Γ_C(s)², functional equation s ↔ 6 − s. [संख्यात्मक, L-stage]

### Critical integers
- L∞(s) = Γ_C(s)² ला s ≤ 0 वर pole आहे, आणि L∞(6 − s) ला s ≥ 6 वर. म्हणून critical integers s = 1, …, 5. [ज्ञात theory; W ला लागू होणं: अंदाज]
- FE मुळे L(1) ↔ L(5) आणि L(2) ↔ L(4) जोडलेले आहेत.
- म्हणून स्वतंत्र values तीन: L(W, 3) (central), L(W, 4), L(W, 5).
- L(W, 4) आणि L(W, 5) साठी Dirichlet series absolutely converge होते, कारण Re s > 3.5. L(W, 3) ला FE लागते (आधीपासून आहे).

### Deligne ची अपेक्षा [ज्ञात conjecture; W ला लागू होणं: अंदाज]
- L(M, m) ∈ (2πi)^{d±·m} · c^{±}(M) · Q, जिथे ± = (−1)^m आणि d⁺ = d⁻ = 2.
- s = 3 आणि s = 5 ला parity सारखी आहे, म्हणून period एकच येतो.
- म्हणून अपेक्षा: **R := L(W, 5) / (π⁴ · L(W, 3)) ∈ Q** (चिन्ह आणि 2 च्या घातांसह).
- Coefficient field Q आहे असं गृहीत धरलं आहे (a_n integers). R1 मध्ये हे तपासायचं.
- L(W, 4) ला दुसरा period c⁻ लागतो. त्यासाठी हा test थेट लागू होत नाही. हा प्रश्न नंतर पाहायचा.

### R0: prior-art audit (गणनेपूर्वी)
- Paramodular / Siegel spin L-values आणि Deligne periods:
  - Böcherer, Dummigan, Ryan–Tornaría (paramodular L-values).
  - Harder (congruences).
  - Bergström–Faber–van der Geer (Siegel modular forms numerics).
  - Non-cohomological weights वर काही लिहिलं आहे का, ते शोधायचं.
- Hypergeometric / Calabi–Yau motives चे critical values: Long, Tu, Roberts–Rodriguez-Villegas, Zudilin (L-value identities).
- Rigid CY आणि degree-4 CY motives च्या periods: Candelas, de la Ossa, van Straten ("attractor points"), Golyshev.
- **PASS (audit):** W किंवा त्याच्याशी जुळणाऱ्या object साठी ही चाचणी आधी प्रकाशित नाही. "To the best of our knowledge" या शब्दांतच नोंदवायचं.

### R1: तयारी
- L-stage मधले L2, L3 आणि L4 scripts **फक्त वाचायचे**. त्यातून तीन गोष्टी समजून घ्यायच्या:
  - a_n कसे मिळतात.
  - किती a_n उपलब्ध आहेत.
  - ते integers आहेत का.
- नवीन script लिहायचा: `N2_check_LW_critical_ratio_FLOAT_<date>.py`, mpmath वापरून आणि precision ≥ 50 अंक.
- पहिला मोठा प्रश्न: 30 अंकांसाठी किती a_n लागतील याचा अंदाज (√N = 36 आणि K₀ चा decay वापरून).
  - गणना काही मिनिटांपेक्षा जास्त चालणार असेल, तर laptop runner द्यायचा (नियम 5).

### Controls: आधी PASS व्हायलाच हवेत
- **C1 (degree 2):** f = 4.6.a.a (weight 6). R_f := L(f, 5)/(π² L(f, 3)) ∈ Q असायला हवं (Manin / Shimura). [ज्ञात literature]
- **C2 (degree 4):** L(f, s) · L(f ⊗ χ_{−3}, s), ज्याला Hodge {0,0,5,5} आहे. L(5)/(π⁴ L(3)) ∈ Q · (साधा algebraic factor) असायला हवं.
  - हा factor Gauss sum किंवा √3 असू शकतो, म्हणून PSLQ basis मध्ये √3 घ्यायचा.
- C1 किंवा C2 FAIL झाला, तर W वरचा निकाल गृहीत धरायचा नाही. आधी method दुरुस्त करायची.

### R2: PASS/FAIL निकष (W) — गणनेपूर्वी ठरवलेले
- **PASS:** R (आणि ±√3 · R) साठी छेद ≤ 10⁶ असलेलं rational सापडलं, आणि ते ≥ 30 अंकांपर्यंत टिकलं. तपासणीसाठी दोन स्वतंत्र मार्ग वापरायचे:
  - continued fraction;
  - mpmath.pslq / identify.
  - शिवाय precision 40 → 60 वाढवल्यावरही निकाल बदलता कामा नये.
- **FAIL:** छेद ≤ 10⁶ असलेलं rational सापडलं नाही. हाही नोंदवण्याजोगा निकाल आहे. कारण तीनपैकी एक असेल:
  - period structure वेगळी आहे;
  - coefficient field Q नाही;
  - Γ-factor / ε मध्ये चूक आहे.
  - पुढची पायरी: तिन्ही कारणं स्वतंत्रपणे तपासायची.
- **खुणा:** PASS आलं तरी निकालाची खूण [संख्यात्मक] राहील, सिद्ध नाही.

### हे BSD शी कसं जोडलेलं आहे
- Bloch–Kato हे BSD चं सर्वसाधारण रूप आहे. Critical values चे periods हा त्याचा पहिला थर आहे. [ज्ञात theory]
- Rational संख्या सापडली, तर पुढचा प्रश्न: तिचे prime factors (2, 3, 5, …) Bloch–Kato Selmer / Tamagawa factors शी जुळतात का? [पुढचा अंदाज]

---

## मार्ग A (समांतर, शिकण्यासाठी): 37a1 चा rank-1 पुरावा प्रत्यक्ष गणनेने
- **A1:** Heegner hypothesis पाळणारा K = Q(√D) निवडायचा, आणि y_K ∈ E(K) ची गणना करायची (modular parametrization, complex numerics).
- **A2: Gross–Zagier.** ĥ(y_K) आणि L′(E/K, 1) = L′(E, 1) · L(E^D, 1) यांचा संबंध तपासायचा, ठरलेल्या constants सह.
  - **PASS:** relative error < 1e−10.
- **A3: Index.** [E(K) : Z·y_K] काढायचा, आणि Kolyvagin च्या bound वरून Ш(E/Q) = 1 शी सुसंगतता तपासायची (F-stage च्या BSD आकड्यांसोबत).
- **A4: 389a1.** तिथे y_K torsion होतो. Kolyvagin system कुठे अपुरा पडतो, ते लिहून काढायचं. [ज्ञात literature]
- **साधनं:** pip ने cypari2 / PARI (`ellheegner`) वापरता येईल का ते तपासायचं. शक्य झाल्यास PARI चा निकाल स्वतंत्र Python numerics ने पुन्हा तपासायचा.
- **खुणा:** हा मार्ग [ज्ञात literature] आहे; यातून नवीन दावा करायचा नाही.

---

## क्रम
R0 (audit) → R1 (scripts वाचणं आणि control C1) → C2 → R2. मार्ग A समांतर चालेल, जेव्हा B मध्ये laptop runner ची वाट पाहावी लागेल.
