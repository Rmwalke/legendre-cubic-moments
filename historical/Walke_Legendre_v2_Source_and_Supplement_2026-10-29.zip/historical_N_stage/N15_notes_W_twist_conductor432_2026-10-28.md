# N15 — W′ := W ⊗ χ₋₃: conductor 432, ε = −1, आणि periods — 28 ऑक्टोबर 2026

खुणा: [सिद्ध] [sketch] [संख्यात्मक] [अंदाज] [ज्ञात literature] [माहीत नाही]

**Scripts आणि outputs:**
- Explorations (scratchpad मध्ये): `explore_Wtwist`, `explore_Wtwist2`, `explore_Wtwist3`, `explore_Wtwist4`.
- Confirmation: `N14_check_W_twist_conductor432_periods_FLOAT_2026-10-28.py` → `N14_output.txt` (**PASS**).

## १ प्रवास (FAIL सकट)
1. **पहिला प्रयत्न:** 3 वर Euler factor 1 ठेवून, N = 2^a·3^b ≤ 2·10⁵ मध्ये शोधलं. **FAIL:** सर्वोत्तम fit फक्त 5 अंकांचा.
2. **3 वरचे Euler factors शोधले:** 1 − c₁T (+ c₂T²) प्रकारचे सुमारे 3500 उमेदवार. **एकमेव fit:** N = 432 = 2⁴·3³, P₃(T) = 1 − 3T, ε = −1. हा 40 अंकांपर्यंत जुळला; पुढचा उमेदवार फक्त 6.3 अंकांचा.
3. **N14 confirmation** (dps 70):

| चाचणी | निकाल |
|---|---|
| T1: FE (N = 432, ε = −1) | **74.2 अंक**; पर्याय (ε = +1; N = 144, 1296, 3888) कमाल 3.8 अंक |
| T2: L(W′, 3) | **= 0** (ε = −1 मुळे अपरिहार्य) |
| T3: L(W′,4) = π⁶ μ_C(2,4)/69984 | **80.7 अंक** |
| T3: L(W′,5) = π⁸ μ_C(1,3)/1679616 | **80.4 अंक** |

- L(W′, 4) = 0.92172038242778742429328741574163284922…
- L(W′, 5) = 0.99659376873719756002903938692598644091…

## २ अर्थ
- **[संख्यात्मक]** W′ हा conductor 432, sign −1 असलेला degree-4, weight-5 L-function आहे. 3 वर त्याला (1 − 3T) असा unramified-भाग असलेला Euler factor आहे.
- **Deligne चा twist-नियम [ज्ञात theory]:** χ₋₃ odd आहे, म्हणून c^±(W′) ~ c^∓(W) व्हायला हवं. आपल्या आकड्यांमध्ये नेमकं हेच दिसतं:
  - L(W′, 4) (सम s) येतो W च्या c⁻ determinant मधून (C-rows, सम j);
  - L(W′, 5) (विषम s) येतो c⁺ determinant मधून (C-rows, विषम j).
  - ⇒ Scholl-चित्रातली rational structure सुसंगत आहे.
- **BSD-प्रकारचा मुद्दा [अंदाज]:** L(W′, s) ला center s = 3 वर विषम order चा zero आहे. Bloch–Kato conjecture (BSD चं सर्वसाधारण रूप) नुसार H¹_f(Q, W′(3)) ≠ 0 असायला हवं, म्हणजे "rank ≥ 1" चा analogue.
  - Beilinson–Bloch नुसार L′(W′, 3) हा एखाद्या algebraic cycle च्या height शी जोडलेला असावा. हा Gross–Zagier चा analogue आहे.
  - **हे सिद्ध नाही, आणि इथे तपासलेलंही नाही.** L′ ची गणना N16 मध्ये केली आहे.
## ३ Central derivative L′(W′, 3) (N16)
- **Closed form:** J_m(Y) = ∫_Y^∞ y^{2m+1}K₀ ln y dy साठी integration-by-parts recursion वापरली. त्यामुळे quadrature न करता derivative काढता येतो.
- **D1:** t₀ = 1 आणि 1.1 वर 75.1 अंक जुळले. **L′(W′, 3) = 2.4782486597862839737116318146978566156781118923558…** (≠ 0 ⇒ center वरचा zero simple आहे) [संख्यात्मक].
- **D2:** J-recursion ची थेट quadrature शी तुलना: 81 अंक. PASS.
- **D3 (negative control):**
  - **Run 1:** माझ्या script मध्ये float-filter नंतरची high-precision पडताळणी नव्हती. त्यामुळे खोटे "hits" आले. तो output `N16_output_run1_D3_unverified.txt` मध्ये जपला आहे.
  - **Run 2 (दुरुस्त):** **एकही hit नाही.** म्हणजे L′(W′,3) हा noncongruence period-determinants चा साधा rational × π-घात गुणक नाही. Beilinson–Bloch च्या अपेक्षेशी हे सुसंगत आहे: तिथे Deligne period नाही, तर height/regulator येतो [ज्ञात conjecture].
- **पुढचा (कठीण) प्रश्न [अंदाज]:** L′(W′,3) ला जबाबदार असलेलं "Heegner-प्रकारचं" algebraic cycle शोधणं. हा Gross–Zagier चा analogue आहे, आणि BSD च्या rank-1 पुराव्याची हीच यंत्रणा आहे. सध्या आपल्याकडे यासाठी साधन नाही.

- **LMFDB (दादांचा screenshot, 28 ऑक्टोबर 2026, LMFDB Release 1.2.1):** degree = 4, conductor = 432 या शोधावर **"No matches"**.
  - ⇒ W′ हा LMFDB मध्ये नाही [ज्ञात database: त्या तारखेपुरतं].
  - मर्यादा: LMFDB ची degree-4 यादी पूर्ण नाही (मुख्यतः genus-2 curves, गुणाकार आणि काही Siegel forms). त्यामुळे "नसणं" म्हणजे "अस्तित्वात नाही" असं नव्हे.
  - W (conductor 1296) साठी L5 मध्ये तपासलं होतं: तिथे weight-5 चा एकच L-function आहे (36.6.b.a), आणि तो वेगळा आहे.
