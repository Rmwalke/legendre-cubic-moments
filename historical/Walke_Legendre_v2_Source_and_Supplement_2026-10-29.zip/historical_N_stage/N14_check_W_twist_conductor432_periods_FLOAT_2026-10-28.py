"""N14 (FLOAT) — CONFIRMATION (criteria fixed from explorations explore_Wtwist2/3/4, before this run):
 the quadratic twist W' := W (x) chi_{-3}.
   a_n(W') = a_m(W) chi_{-3}(m) 3^v  (n = 3^v m), i.e. Euler factor at 3 = (1 - 3T)^{-1}; all other factors = twist of W.
 Criteria:
   T1  functional equation: N = 432 = 2^4 3^3, eps = -1, Gamma_C(s)^2, s <-> 6-s: t0-independence at s = 4, 5 >= 60 digits (dps 70);
       the alternatives eps = +1 and N in {144, 1296, 3888} (same Euler data) must fail (< 10 digits).
   T2  hence L(W', 3) = 0 (forced by eps = -1)  [an ODD order of vanishing at the centre: the Bloch-Kato analogue of rank >= 1].
   T3  periods (N11 v2 machinery): L(W',4) = pi^6 muC(2,4)/69984  and  L(W',5) = pi^8 muC(1,3)/1679616   >= 60 digits.
   T4  Deligne's twist rule: chi_{-3} is odd, so the parity swaps — W' at s = 4 uses the c^- determinant of W (C, even j),
       at s = 5 the c^+ determinant (C, odd j). (Bookkeeping check of T3.)
 [numerical]. Not a proof.
Usage: python -I N14_...py H13_output_data_laptop_p_upto_4999.txt
"""
import sys, math
data = sys.argv[1]
n2 = open('N2_check_LW_critical_ratio_FLOAT_2026-10-28.py').read().split('# ================================================================ main')[0]
ns = {'__name__': 'n2'}; exec(compile(n2, 'n2', 'exec'), ns)
AW, NM, _ = ns['w_coefficients'](data); chi3 = lambda n: (0, 1, -1)[n % 3]
A = [0] * (NM + 1)
for n in range(1, NM + 1):
    v, m = 0, n
    while m % 3 == 0: m //= 3; v += 1
    A[n] = AW[m] * chi3(m) * 3 ** v
ns['set_dps'](70); Dn = ns['D']; dg = ns['digits']
fe = lambda N, e: min(dg(ns['Lam'](A, N, e, s, 4, Dn(1)), ns['Lam'](A, N, e, s, 4, Dn('1.1'))) for s in (4, 5))
t1 = fe(432, -1); alts = [fe(432, 1)] + [fe(N, e) for N in (144, 1296, 3888) for e in (1, -1)]
print(f'T1 FE N=432 eps=-1: {t1:.1f} digits; alternatives max {max(alts):.1f}')
Lt = {s: ns['L_of'](A, 432, -1, s, 4) for s in (3, 4, 5)}
print('T2 L(W\',3) =', format(Lt[3], '.5g'), ' L(W\',4) =', format(Lt[4], '.40g'), ' L(W\',5) =', format(Lt[5], '.40g'))
# periods (N11 v2)
src = open('N11_check_W_Deligne_period_determinant_FLOAT_2026-10-28.py').read().split('mu = lambda A, B')[0]
pn = {}; exec(src, pn)
V, PI, D, dig = pn['V'], pn['PI'], pn['D'], pn['dig']
mu = lambda X, Y, j1, j2: V[(X, j1)] * V[(Y, j2)] - V[(X, j2)] * V[(Y, j1)]
t3 = [dig(PI ** 6 * mu('C2/3', 'C1/3', 2, 4) / 69984, D(str(Lt[4]))), dig(PI ** 8 * mu('C2/3', 'C1/3', 1, 3) / 1679616, D(str(Lt[5])))]
print('T3 periods -> L(W\',4), L(W\',5): digits', [round(x, 1) for x in t3])
ok = t1 >= 60 and max(alts) < 10 and abs(Lt[3]) < Dn(10) ** (-50) and min(t3) >= 60
print('VERDICT:', 'PASS' if ok else 'FAIL')
